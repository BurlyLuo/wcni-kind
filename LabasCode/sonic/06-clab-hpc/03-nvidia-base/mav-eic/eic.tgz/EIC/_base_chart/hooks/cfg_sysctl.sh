#! /bin/bash

ctlfile=/etc/sysctl.d/sysctl.conf

cat  > $ctlfile <<EOF
# 
# Note that changes to this file can up immediately put into effect by:
# sysctl -p
#
# To modify/test values temporarily:
# sysctl -w variable=value
#
# To display all values:
# sysctl -a
#

# Basic configuration

# Controls IP packet forwarding
net.ipv4.ip_forward = 0

# Controls source route verification
net.ipv4.conf.default.rp_filter = 1

# Do not accept source routing
net.ipv4.conf.default.accept_source_route = 0

# Enable SysRq key processing
kernel.sysrq = 1

# Message Queue limits
#     Posix Q limits (max Qs in system, max msg's per Q, and max size of single msg in Q)
fs.mqueue.queues_max = 512
fs.mqueue.msg_max = 1024
fs.mqueue.msgsize_max = 16777215
#     SysV Q limits (max msg's per Q, max size of single msg in Q, and max total size of Q)
kernel.msgmni = 512
kernel.msgmax = 26194304
kernel.msgmnb = 263886080

# System open file limit
fs.file-max = 5242880
fs.nr_open = 5242880

# Core IO processing limits
net.unix.max_dgram_qlen = 65535
net.core.message_burst = 256
net.core.netdev_max_backlog = 8192
net.core.rmem_default = 16777216
net.core.rmem_max = 16777216
net.core.somaxconn = 1024
net.core.wmem_default = 16777216
net.core.wmem_max = 16777216

# UDP/TCP port allocation range for client connections
net.ipv4.ip_local_port_range = 25000 65000

# TCP Flood defense
net.ipv4.tcp_syncookies = 1

# TCP KeepAlive optimization
net.ipv4.tcp_keepalive_intvl = 50
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_keepalive_time = 300

# Improve responsiveness
net.ipv4.tcp_retries1 = 5
net.ipv4.tcp_max_syn_backlog = 1024
net.ipv4.tcp_rmem = 4096   87380   4194304
net.ipv4.tcp_wmem = 4096   87380   4194304

# Reduce TCP overhead
net.ipv4.tcp_timestamps = 1
net.ipv4.tcp_tw_recycle = 0
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_sack = 1
net.ipv4.tcp_no_metrics_save = 1
net.ipv4.tcp_fin_timeout = 60
net.ipv4.xfrm4_gc_thresh= 4194304

net.ipv4.neigh.default.unres_qlen = 2048

net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.send_redirects =0 
net.ipv4.conf.all.log_martians=0
net.ipv4.conf.default.log_martians=0
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.conf.all.arp_filter=1
net.ipv4.conf.default.arp_filter=1
net.ipv4.conf.default.arp_ignore=2

net.netfilter.nf_conntrack_max = 262144

# Controls whether core dumps will append the PID to the core filename.
kernel.core_uses_pid = 1
kernel.core_pattern = /data/storage/corefiles/core.%e.%p.%s.%t.%h
fs.suid_dumpable=2

# support ipv6
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_ra = 0
net.ipv6.conf.default.accept_ra_defrtr = 0
net.ipv6.conf.default.accept_ra_pinfo = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv6.conf.default.autoconf = 0
net.ipv6.neigh.default.unres_qlen = 16
net.ipv6.xfrm6_gc_thresh = 4194304
net.ipv6.route.max_size = 8388608

# vm config
vm.max_map_count = 131072

# overcommit memory
vm.overcommit_memory = 0
vm.overcommit_ratio = 50

#
kernel.printk =  4 4 1 7

# sctp
net.sctp.sndbuf_policy = 1
net.sctp.rcvbuf_policy = 1
net.sctp.hb_interval=100

# 
kernel.unknown_nmi_panic=1
kernel.panic_on_unrecovered_nmi=1
kernel.pid_max = 65534

EOF

echo "kiroya2" > /var/log/kiroya2
mkdir -p /data/storage/corefiles/
sysctl -p $ctlfile >/dev/null  2>&1

exit 0;
