cp /config/init/*.zone /var/named/
cp /config/init/named.conf /etc/
