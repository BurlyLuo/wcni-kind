#!/usr/bin/env python

# version: 0.3.13

import sys
import os.path
import logging
import time
import pprint

sys.path.append(r"/usr/IMS/current/tools/")
import ip_util

if sys.version.startswith("3."):
    import subprocess as commands
else:
    import commands

logger = None


class LivenessLog:
    @staticmethod
    def info(msg):
        logger.info("{}".format(msg))
    @staticmethod
    def warn(msg):
        logger.warn("{}".format(msg))
    @staticmethod
    def error(msg):
        logger.error("{}".format(msg))


def setup_logger():
    """
    Set up the logger, set the log level to DEBUG, and add a rotating file handler to the logger.
    The log file is rotated every 10M and only keep 2 log files at most.
    :return: None
    """
    logger = logging.getLogger("LivenessLog")
    logger.setLevel(logging.DEBUG)
    handle = logging.handlers.RotatingFileHandler(
        filename="/data/storage/log/liveness_check.log",
        maxBytes=1024 * 1024 * 10,
        backupCount=1
    )
    formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', datefmt="%Y-%m-%d %H:%M:%S")
    handle.setFormatter(formatter)
    logger.addHandler(handle)
    return logger


def update_check_status(status, faulure = 0):
    # success_threshold = 1
    failure_threshold = int(os.getenv("liveness_cnf_failure") or "3")
    timeout_seconds = int(os.getenv("liveness_cnf_timeout") or "1")
    period = int(os.getenv("liveness_cnf_period") or "10")
    if os.path.exists("/tmp/_liveness_stat"):
        start_time, curr_status, count_failure = open("/tmp/_liveness_stat").read().split(",")[:3]
        if curr_status == "unknow":
            if status == "unknow" and faulure > 0:
                count_failure = int(count_failure) + faulure
                LivenessLog.warn(
                    "[WARN]: liveness_check failed: {}/{}".format(count_failure, failure_threshold)
                )
            else:
                start_time = time.time()
                curr_status = status
                count_failure = 0
                LivenessLog.info(" liveness_check status changes to '{}'".format(status))
        else:
            if curr_status != status:
                start_time = time.time()
                curr_status = status
                LivenessLog.info(" liveness_check status changes to '{}'".format(status))
            return
    else:
        start_time = time.time()
        curr_status = status
        count_failure = 0

    open("/tmp/_liveness_stat", "w").write(
        "{},{},{},{},{}".format(start_time, curr_status, count_failure, timeout_seconds, period)
    )


def _run_cli_cmd(cmd):
    LivenessLog.info("  run confd cli cmd: {}".format(cmd))
    stat, out = commands.getstatusoutput("echo -e '{}' | cli".format(cmd))
    if stat:
        LivenessLog.error(" run the cli command failed.")
        return []
    lines = out.split("\n")
    start = end = 0
    for i, line in enumerate(lines):
        if "---" in line:
            start = i + 1
        elif "match" in line:
            start = i + 1
        if "[ok]" in line:
            end = i

    LivenessLog.info("  output: {}".format(pprint.pformat(lines[start:end], indent=2)))
    return lines[start:end]


def is_ims_running():
    """
    Check IMS status
    :return: None
    """
    try:
        update_check_status("unknow")
        vnf_type = _run_cli_cmd("show table sys platform product")[0].split()[1]
        LivenessLog.info("check IMS status: (vnf type: {})".format(vnf_type))
        stat, out = commands.getstatusoutput(
            '/usr/IMS/current/bin/readShm | grep "vnfcHAMode" | grep STANDBY'
        )
        if stat == 0:
            LivenessLog.info("  output: {}".format(out))
            update_check_status("standby")
            LivenessLog.info("Success")
            exit(0)
        else:
            stat, out = commands.getstatusoutput(
                '/usr/IMS/current/bin/readShm | grep "Process State" | grep STATE_INS_ACTIVE'
            )
            LivenessLog.info("  output: {}".format(out))
            if stat == 0:
                update_check_status("active")
                return True
    except Exception as e:
        LivenessLog.error(
            "get an error when checking ims state, maybe confd is not running: {}".format(
                e
            )
        )
    return False


def audit_confd_and_etcd():
    """
    Audit local peer-vnf/peer-ip tables in confd vs. etcd entries in SM
    :return: None
    """
    status, _ = commands.getstatusoutput("curl http://localhost:8008")
    if status != 0:
        status, _ = commands.getstatusoutput("curl -k https://localhost:8888")
        if status != 0:
            update_check_status("unknow", 1)
            LivenessLog.error("confd does not work over HTTP(8008)/HTTPS(8888).")
            exit(2)

    status, _ = commands.getstatusoutput("curl http://localhost:8008")
    if status != 0:
        status, _ = commands.getstatusoutput("curl https://localhost:8888")
        if status != 0:
            update_check_status("unknow", 1)
            LivenessLog.error("confd does not work over HTTP(8008)/HTTPS(8888).")
            exit(2)


def _ping_test(src_ip, dst_ip, count):
    for _ in range(count):
        peer_ips_out = _run_cli_cmd(
            "set screen length 2000\nshow table sys platform peer_ip"
        )
        if dst_ip not in map(lambda x: x.split()[2], peer_ips_out):
            return True
        cmd = "ping -c 1 -W 1 {} -I {}".format(dst_ip, src_ip)
        if ":" in src_ip:
            if os.path.exists("/usr/bin/ping6"):
                cmd = "ping6 -c 1 -W 1 {} -I {}".format(dst_ip, src_ip)
            else:
                cmd = "ping -6 -c 1 -W 1 {} -I {}".format(dst_ip, src_ip)
        status, _ = commands.getstatusoutput(cmd)
        if status == 0:
            return True
    return False


def unicode_str(string):
    res = string
    if sys.version.startswith("2."):
        res = unicode(string)
    return res


def _format_ip(ip):
    bitlist = ip.split(":")
    if len(bitlist) == 16:
        ip_str = unicode_str(
            ":".join(map(lambda x: x[0] + x[1], zip(bitlist[::2], bitlist[1::2])))
        )
    elif len(bitlist) <= 8:
        ip_str = unicode_str(ip)
    else:
        LivenessLog.error(" Invalid IP: {}, ".format(ip))
        return None
    return ip_util.ip_address(ip_str)


def check_tunnel():
    """
    Verify tunnel remote endpoint, which is the FE IP, is correctly assigned for the GRE tunnel
    :return: None
    """
    maps = list(
        map(lambda x: x.split()[2], _run_cli_cmd("show table sys platform tunnelMap"))
    )
    if not maps:
        return
    LivenessLog.info("check tunnel.")
    peer_ips_out = _run_cli_cmd(
        "set screen length 2000\nshow table sys platform peer_ip"
    )
    peer_ips_list = []
    for m in maps:
        filter_out = filter(lambda x: x.split()[1] == m, peer_ips_out)
        peer_ips_list.extend(map(lambda x: x.split()[2], filter_out))
    LivenessLog.info("  peer_ips_list: {}".format(peer_ips_list))
    if not peer_ips_list:
        LivenessLog.warn(" lack of necessary peer ip information.")
        return
    _, ipa_out = commands.getstatusoutput("ip a")
    LivenessLog.info("  ipconfig: {}".format(ipa_out))
    peer_ips_out_list = map(
        lambda x: _format_ip(x.split()[x.split().index('peer')+1]),
        filter(lambda x: "peer " in x, ipa_out.split("\n")),
    )
    for peer_ip in peer_ips_list:
        peer_ip_obj = _format_ip(peer_ip)
        if not peer_ip_obj:
            update_check_status("unknow", 1)
            exit(3)
        if peer_ip_obj not in peer_ips_out_list:
            LivenessLog.error(" the peer ip: {} is not added".format(peer_ip))
            update_check_status("unknow", 1)
            exit(3)
    tunnels_config = _run_cli_cmd("show table sys platform tunnel_config")
    for config in tunnels_config:
        tunnel_intf, src_ip, dst_ip = config.split()[:3]
        # Try up to 3 times
        if not _ping_test(src_ip, dst_ip, 3):
            LivenessLog.error(
                "The tunnel network ({}) is unreachable from {} to {} ".format(
                    tunnel_intf, src_ip, dst_ip
                )
            )
            update_check_status("unknow", 1)
            exit(3)


# ! This check is not enabled by default, it needs to be specified in the "liveness_check" ENV.
def check_timeout():
    import subprocess

    check_timeout_file = "/tmp/liveness_podstatus_check.py"

    try:
        # if will make the script execute only once.
        subprocess.check_output(["pgrep", "-f", "liveness_podstatus_check.py"])
        return
    except Exception:
        pass

    content = """#!/usr/bin/env - python
import time
import os

while True:
    in_serice_timeout = int(os.getenv("IN_SERVICE_TIMEOUT") or 300)
    start_time_str, status = open("/tmp/_liveness_stat").read().split(',')[:2]
    if 'unknow' in status:
        if time.time() - float(start_time_str) >= in_serice_timeout:
            os.system("echo '[ERROR] trigger in_service_timeout, it will reboot the pod' | tee /data/storage/log/liveness_check.log")
            os.system("/usr/IMS/current/bin/reboot")
    time.sleep(2)

"""
    if not os.path.exists(check_timeout_file):
        with open(check_timeout_file, "w") as fd:
            fd.write(content)
    subprocess.Popen(["python", "/tmp/liveness_podstatus_check.py"])


if __name__ == "__main__":
    logger = setup_logger()
    default_features = "tunnel,audit_confd_and_etcd"
    check_list = "{}, {}".format(
        default_features, os.getenv("liveness_checklist") or ""
    ).split(",")
    check_list = list(map(lambda x: x.strip(), check_list))
    features = {
        e.replace("-", "").replace("+", ""): (False if e.startswith("-") else True)
        for e in check_list
    }
    if features.get("timeout", False):
        check_timeout()
    if is_ims_running():
        if features.get("tunnel", False):
            check_tunnel()
            if features.get("audit_confd_and_etcd", False):
                if vnf_type != "SM":
                    audit_confd_and_etcd()
        LivenessLog.info("Success!")
    exit(0)
