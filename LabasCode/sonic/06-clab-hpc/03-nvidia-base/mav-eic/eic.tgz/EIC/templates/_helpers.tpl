{{/*
********************************************
define the global name
*/}}
{{- define "ct.name" -}}
{{- default .Release.Name .Values.name | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
get namespace
*/}}
{{- define "ct.namespace" -}}
{{- if not $.Values.global.isGitOps }}
{{- .Values.global.namespace.name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
********************************************
all hook scripts are in directory 'hooks'.
this definition is only used by sub-charts.
if one sub-chart wants to use the hooks, the definition should be used in yaml of the sub-chart.
*/}}
{{- define "get_hook_from_parent" -}}
{{- if .Values.hooks }}
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: {{ include "ct.namespace" . }}
  name: {{ .Chart.Name }}-hooks
data:
{{- range .Values.hooks.postStart }}
  {{ . }}: |
  {{ $.Files.Get (cat "../../hooks/" . | nospace) | nindent 4 }}
{{- end }}
{{- range .Values.hooks.preStop }}
  {{.}}: |
  {{ $.Files.Get (cat "../../hooks/" . | nospace) | nindent 4 }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ct.fullname" -}}
{{- $name := (include "ct.name" .) }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ct.serviceAccount" -}}
{{- if .Values.global.ServiceAccount }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.global.ServiceAccount }}
  namespace: {{ include "ct.namespace" . }}
{{- end }}
{{- end }}

{{/*
Create rbac
*/}}
{{- define "ct.rbac" -}}
{{- if .Values.global.rbac }}
kind: Role
#kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: {{ .Chart.Name }}
  namespace: {{ include "ct.namespace" . }}
rules:
{{- range $key, $value := .Values.global.scc | default dict }}
  - apiGroups: ["security.openshift.io"]
    resources: ["securitycontextconstraints"]
    resourceNames: [{{ $key | quote }}]
    verbs: ["use"]
{{- end }}
{{- if .Values.global.rbac.rules }}
{{- .Values.global.rbac.rules | toYaml | nindent 2 }}
{{- else }}
  - apiGroups: [""]
    resources: ["pods", "pods/log","configmaps","pods/labels"]
    verbs: ["get", "list", "delete", "patch", "create", "watch", "update"]
  - apiGroups: ["apps"]
    resources: ["statefulsets", "statefulsets/scale"]
    verbs: ["get", "list", "delete", "watch", "update", "patch", "create"]  
  - apiGroups: ["apps.kruise.io"]
    resources: ["clonesets", "clonesets/scale"]
    verbs: ["get", "list", "delete", "watch", "update", "patch", "create"] 
{{- end }}
---
{{- if .Values.global.ServiceAccount }}
kind: RoleBinding
#kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: {{ .Chart.Name }}
  namespace: {{ include "ct.namespace" . }}
subjects:
  - kind: ServiceAccount
    name: {{ .Values.global.ServiceAccount }}
    namespace: {{ include "ct.namespace" . }}
roleRef:
  kind: Role
  #kind: ClusterRole
  name: {{ .Chart.Name }}
  apiGroup: rbac.authorization.k8s.io
{{- end }}
{{- end }}
{{- end }}
