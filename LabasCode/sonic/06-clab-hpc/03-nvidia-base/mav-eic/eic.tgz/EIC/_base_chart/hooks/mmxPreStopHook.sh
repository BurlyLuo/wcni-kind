/bin/sh -c /usr/IMS/current/bin/reboot >/dev/null 2>&1
# FRN-7213
# Prestop hook invoke msgSender to send specific stop MX msg to serviceAgent interface
# sendMxMsg -m $msg_id -i $interface -d $data
# /usr/IMS/current/bin/sendMxMsg   -m 58377 -i 756 -d '{"period":180,"scope":"vnfc","method":"graceful"}'
