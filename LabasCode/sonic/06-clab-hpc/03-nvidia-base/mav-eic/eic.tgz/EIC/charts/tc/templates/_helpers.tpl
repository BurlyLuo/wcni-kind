{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "tc.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
get namespace
*/}}
{{- define "tc.namespace" -}}
{{- if not $.Values.global.isGitOps }}
{{- if .Values.namespace}}
{{- .Values.namespace | trunc 63 | trimSuffix "-" }}
{{- else}}
{{- .Values.global.namespace.name | trunc 63 | trimSuffix "-" }}
{{- end}}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
tc.updatestrategy
*/}}
{{- define "tc.updatestrategy" -}}
{{- if eq .Values.kind "CloneSet" }}
  updateStrategy:
    maxUnavailable: 1
    type: InPlaceIfPossible
    inPlaceUpdateStrategy:
      gracePeriodSeconds: 10
    priorityStrategy:
      weightPriority:
      - weight: 50
        matchSelector:
          matchLabels:
            ha-mode: standby
      - weight: 30
        matchSelector:
          matchLabels:
            ha-mode: active
{{- end }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "tc.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
****************************************************************************
define service.
*/}}
{{- define "tc.serviceConf" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ .Chart.Name }}-service
  namespace: {{ include "tc.namespace" . }}
  labels:
    app: {{ .Chart.Name }}
{{- $spec := set .Values.service "selector" (dict "app" (include "tc.name" .)) }}
spec:
  {{- $spec | toYaml | nindent 2 }}
{{- end -}}

{{/*
****************************************************************************
volumes
*/}}
{{- define "tc.volumes" -}}
volumes:
  {{- $sidecars := $.Values.global.sidecars | default (dict) }}
  {{- $vtapObj := $sidecars.vtap | default (dict) }}
  {{- $vtapSecrets := $vtapObj.secrets | default (dict) }}
  {{- $chartName := .Chart.Name }}
  {{- $secObj := index $vtapSecrets $chartName | default list }}
  {{- if or (not (hasKey $vtapObj "createSecrets")) $vtapObj.createSecrets }}
  - name: vtap
    secret:
      secretName: vtap-{{ $chartName }}
  {{- else }}
  {{- if $secObj }}
  {{- range $secitem := $secObj }}
  - name: {{ $secitem }}
    secret:
      secretName: {{ $secitem }}
  {{- end }}
  {{- end }}
  {{- end }}
  - name: coredump
    hostPath:
      path: /var/lib/systemd/coredump
  {{- range $k := $.Values.global.secrets }}
  - name: {{ $k }}
    secret:
      secretName: {{ $k }}
  {{- end }}
  - name: probe-{{ .Chart.Name }}-configmap
    configMap:
      name: probe-{{ .Chart.Name }}-configmap
  - name: livenessprobe-{{ .Chart.Name }}-configmap
    configMap:
      name: livenessprobe-{{ .Chart.Name }}-configmap
  - name: {{ .Chart.Name }}-extra-configmap
    configMap:
      name: {{ .Chart.Name }}-extra-configmap
  - name: {{ .Chart.Name }}-configmap
    configMap:
      name: {{ .Chart.Name }}-configmap
  - name: {{ .Chart.Name }}-binary-configmap
    configMap:
      name: {{ .Chart.Name }}-binary-configmap
  {{- if .Values.hooks }}
  - name: {{ .Chart.Name }}-hooks
    configMap:
      name: {{ .Chart.Name }}-hooks
  {{- end }}
  {{- if .Values.sriovEnable }}
  - name: sriov
    hostPath:
      path: /var/lib/cni/sriov
  {{- end }}
  #- name: sys
  #  hostPath: {"path":"/sys"}
  #- name: rootssh
  #  hostPath: {"path":"/home/test123457"}
  {{- if $.Values.netinfoEnable }}
  - name: netinfo
    downwardAPI:
      items:
      - path: annotations
        fieldRef:
          fieldPath: metadata.annotations
  {{- end }}
  - name: podinfo
    downwardAPI: {"items":[{"fieldRef":{"fieldPath":"metadata.labels"},"path":"labels"},{"fieldRef":{"fieldPath":"metadata.uid"},"path":"poduid"}]}
  #- name: mem
  #  hostPath: {"path":"/var/lib/lxcfs/proc/meminfo"}
  #- name: cpu
  #  hostPath: {"path":"/var/lib/lxcfs/proc/cpuinfo"}
  #- name: stat
  #  hostPath: {"path":"/var/lib/lxcfs/proc/stat"}
  #- name: uptime
  #  hostPath: {"path":"/var/lib/lxcfs/proc/uptime"}
  #- name: swaps
  #  hostPath: {"path":"/var/lib/lxcfs/proc/swaps"}
  #- name: zoneinfo
  #  hostPath: {"path":"/usr/share/zoneinfo"}
  - name: shm
    emptyDir: {"sizeLimit": "8Gi", "medium": "Memory"}
  - name: devnet
    emptyDir: {}

{{- end }}

{{/*
****************************************************************************
mount volumes
*/}}
{{- define "tc.mount_volums" }}
  volumeMounts:
    {{- range $k := $.Values.global.secrets }}
    {{- $s_list := regexSplit "-" $k -1 }}
    - name: {{ $k }}
      mountPath: {{ printf "/etc/secrets/%s/%s" (first $s_list) (slice $s_list 1 | join "-") }}
      readOnly: true
    {{- end }}
    - name: coredump
      mountPath: /data/coredump
    {{- if .Values.sriovEnable }}
    - name: sriov
      mountPath: /var/lib/cni/sriov
    {{- end }}
    #- name: sys
    #  mountPath: /sys
    #- name: rootssh
    #  mountPath: /root/.ssh/authorized_keys
    #  readOnly: true
    {{- if $.Values.netinfoEnable }}
    - name: netinfo
      mountPath: /etc/netinfo
    {{- end }}
    - name: podinfo
      mountPath: /etc/podinfo
    #- name: mem
    #  mountPath: /proc/meminfo
    #- name: cpu
    #  mountPath: /proc/cpuinfo
    #- name: stat
    #  mountPath: /proc/stat
    #- name: uptime
    #  mountPath: /proc/uptime
    #- name: swaps
    #  mountPath: /proc/swaps
    #- name: zoneinfo
    #  mountPath: /usr/share/zoneinfo
    - name: shm
      mountPath: /dev/shm
    - name: devnet
      mountPath: /dev/net
    - name: probe-{{ .Chart.Name }}-configmap
      mountPath: /data/configmap/probe
      readOnly: false
    - name: {{ .Chart.Name }}-binary-configmap
      mountPath: /data/configmap/binary
      readOnly: false
    - name: livenessprobe-{{ .Chart.Name }}-configmap
      mountPath: /data/configmap/livenessprobe
      readOnly: false
    - name: {{ .Chart.Name }}-configmap
      mountPath: /data/configmap
      readOnly: false
    - name: {{ .Chart.Name }}-extra-configmap
      mountPath: /data/configmap/extra-configmap
      readOnly: false
    {{- if .Values.hooks }}
    - name: {{ .Chart.Name}}-hooks
      mountPath: /hooks
      readOnly: false
    {{- end }}
    {{- range $k, $v := .Values.volumes }}
    - name: {{ $k }}
      mountPath: {{ $v.mountPath }}
      readOnly: {{ $v.readOnly | default false }}
    {{- end }}
{{- end }}

{{/*
****************************************************************************
set tc.template.spec
*/}}
{{- define "tc.template.spec.cnf" -}}

  {{- $dot := . }}
  {{- $secKeyDict := dict "fsGroup" 0 "fsGroupChangePolicy" 0 "seLinuxOptions" 0 "seccompProfile" 0 "supplementalGroups" 0 "sysctls" 0 "windowsOptions" 0}}
  {{ include "tc.volumes" $dot }}
  {{- $podKeys := list "securityContext" "activeDeadlineSeconds" "affinity" "automountServiceAccountToken" "dnsConfig" "dnsPolicy" "enableServiceLinks" "ephemeralContainers" "hostAliases" "hostIPC" "hostNetwork" "hostPID" "hostname" "imagePullSecrets" "nodeName" "nodeSelector" "overhead" "preemptionPolicy" "priority" "priorityClassName" "readinessGates" "restartPolicy" "runtimeClassName" "schedulerName" "shareProcessNamespace" "setHostnameAsFQDN"  "subdomain" "terminationGracePeriodSeconds" "topologySpreadConstraints"}}
  {{- range $key := $podKeys }}
  {{- if hasKey $dot.Values $key }}
  {{- if eq "securityContext" $key }}
  securityContext:
  {{- $secValues := get $dot.Values $key }}
  {{- range $k, $v :=  $secValues }}
    {{- if hasKey $secKeyDict $k }}
    {{ $k }}: {{ $v | toYaml | nindent 6 }}
    {{- end }}
  {{- end }}
  {{- else }}
  {{ $key }}: {{ pluck $key $dot.Values | first | toYaml | nindent 4 }}
  {{- end }}

  {{- end }}
  {{- end }}
  {{- if $.Values.global.ServiceAccount }}
  serviceAccount: {{ $.Values.global.ServiceAccount }}
  serviceAccountName: {{ $.Values.global.ServiceAccount }}
  {{- end }}
  {{- if $dot.Values.customTolerationsNeeded | default false }}
  tolerations:
  - key: "node.kubernetes.io/unreachable"
    operator: "Exists"
    effect: "NoExecute"
    tolerationSeconds: {{ $dot.Values.tolerationSeconds | default 300 }}
  - key: "node.kubernetes.io/not-ready"
    operator: "Exists"
    effect: "NoExecute"
    tolerationSeconds: {{ $dot.Values.tolerationSeconds | default 300 }}
  {{- else if hasKey $dot.Values "tolerations" }}
  tolerations: {{ $dot.Values.tolerations | toYaml | nindent 2 }}
  {{- end }}
  {{- $initContainerConf := deepCopy ($.Values.global.initContainer | default dict) | merge ($.Values.initContainer | default dict) }}
  {{- if $initContainerConf }}
  {{- if empty ($initContainerConf.image | default "") }}
    {{ printf "Error: 'initContainer.image' is required" | fail }}
  {{- end }}
  initContainers:
  - name: init
    {{- if hasKey $.Values.global "image" }}
    {{- $imagefullname := printf "%s/%s" $.Values.global.image.repository $initContainerConf.image}}
    {{- if not (contains ":" $imagefullname) }}
    {{- $imagefullname = printf "%s/%s:%s" $.Values.global.image.repository $initContainerConf.image $.Values.global.image.tag }}
    {{- end }}
    image: {{ $imagefullname | replace "//" "/" }}
    imagePullPolicy: {{ $initContainerConf.imagePullPolicy | default ($.Values.global.image.pullPolicy |default "Always") }}
    {{- else }}
    image: {{ $initContainerConf.image }}
    imagePullPolicy: {{ $initContainerConf.imagePullPolicy | default "Always" }}
    {{- end }}
    command: ["/bin/sh"]
    {{- if $initContainerConf.args }}
    args: {{ $initContainerConf.args | toYaml | nindent 8 }}
    {{- else }}
    args: ['-c', '/etc/mavenir/cfg_sysctl.sh']
    {{- end }}
    {{- if $initContainerConf.resources }}
    resources: {{ $initContainerConf.resources | toYaml | nindent 8 }}
    {{- else }}
    resources:
      limits:
        cpu: 50m
        memory: 50Mi
      requests:
        cpu: 50m
        memory: 50Mi
    {{- end }}
    {{- if $initContainerConf.securityContext }}
    securityContext: {{ $initContainerConf.securityContext | toYaml | nindent 6 }}
    {{- else }}
    securityContext:
      privileged: true
    {{- end }}
    env:
    {{- range $key, $value := $initContainerConf.env }}
    - name: {{ $key }}
    {{- if kindIs "string" $value }}
      {{- if regexMatch "<.*>" (print $value) }}
      valueFrom:
        fieldRef:
          fieldPath: {{trimPrefix "<" $value|trimSuffix ">"|quote}}
      {{- else }}
      value: {{$value}}
      {{- end }}
    {{- else if kindIs "map" $value }}
      {{- if hasKey $value $.Chart.Name }}
      value: {{ get $value $.Chart.Name }}
      {{- else}}
      value: {{ upper $.Chart.Name }}
      {{- end}}
    {{- else }}
      value: {{ $value | quote }}
    {{- end}}
    {{- end}}
  {{- end }}

{{- end }}

{{/*
****************************************************************************
set tc.metadata
*/}}
{{- define "tc.metadata.cnf" -}}
  {{- $dot := . }}
  {{- $annt := list }}
  {{- range $interface, $subnet := $dot.Values.networks }}
  {{- $annt = append $annt (dict "name" $subnet "interface" $interface) }}
  {{- end }}
  annotations:
    {{- if $annt }}
      {{- if not (hasKey (default $.Values.annotations dict) "robin.io/networks" )}}
    k8s.v1.cni.cncf.io/networks: {{ toJson $annt | squote}}
      {{- end }}
    {{- end }}
    {{- range $k, $v := $.Values.annotations }}
    {{ $k }} : {{ $v | squote }}
    {{- end }}
    {{- if $dot.Values.vault_inject }}
    vault.hashicorp.com/agent-inject: "true"
    vault.hashicorp.com/role: {{ $dot.Values.global.ServiceAccount }}
    vault.hashicorp.com/agent-init-first: "true"
    {{- $id := 0 }}
    {{- range $secret := $dot.Values.vault_inject }}
    {{- $basename := splitList "/" $secret.path | last }}
    {{- $path := $secret.path | replace $basename "" }}
    {{- $id = add1 $id }}
    vault.hashicorp.com/agent-inject-secret-name{{ $id }}: {{ $secret.data | quote }}
    vault.hashicorp.com/secret-volume-path-name{{ $id }}: {{ $path | quote }}
    vault.hashicorp.com/agent-inject-file-name{{ $id }}: {{ $basename }}
    vault.hashicorp.com/agent-inject-template-name{{ $id }}: |
            {{`{{- with secret "`}}{{ $secret.data }}{{`" -}}`}}
            {{`{{ index .Data.data `}}{{ $secret.data_key |quote }}{{` }}`}}
            {{`{{- end -}}`}}
    {{- end }}
    {{- end }}
  labels:
    app: {{ $.Chart.Name }}
    mavrole: mav-{{ include "tc.fullname" $dot}}
    {{- range $k, $v := $.Values.labels }}
    {{$k}}: {{$v}}
    {{- end }}
{{- end }}

{{/*
****************************************************************************
set tc.spec
*/}}
{{- define "tc.spec.conf" -}}
  {{- $dot := .}}
  {{- if ne $dot.Values.kind "CloneSet" }}
  serviceName: {{ .Chart.Name }}-service
  {{- $specKeys := list "podManagementPolicy" "revisionHistoryLimit"  }}
  {{- range $key :=  $specKeys }}
  {{- if hasKey $dot.Values $key }}
  {{ $key }}: {{ pluck $key $dot.Values | first | toYaml | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- else }}
  {{- $specKeys := list "lifecycle" "revisionHistoryLimit" "scaleStrategy" }}
  {{- range $key :=  $specKeys }}
  {{- if hasKey $dot.Values $key }}
  {{ $key }}: {{ pluck $key $dot.Values | first | toYaml | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
  replicas: !!int {{ $dot.Values.replicas | default "1" }}
  selector:
    matchLabels:
      app: {{ .Chart.Name }}
{{- end }}

{{/*
****************************************************************************
set tc.volumeClaimTemplates
*/}}
{{- define "tc.pvc" -}}
  {{ $dot := . }}
  volumeClaimTemplates:
  {{- range $k, $v := .Values.volumes }}
  {{- if hasKey $v "class" }}
    - metadata:
        name: {{ $k }}
        namespace: {{ include "tc.namespace" $dot }}
        annotations:
          reclaimspace.csiaddons.openshift.io/schedule: "@midnight"
      spec:
        accessModes: 
          - ReadWriteOnce
        resources: {{ $v.resources | toYaml | nindent 10 }}
        {{- if $v.class }}
        storageClassName: {{ $v.class }}
        {{- end }}
  {{- end }}
  {{- end }}
{{- end }}

{{- define "tc.hooks" -}}
  {{- if .Values.hooks }}
  lifecycle:
    {{- if .Values.hooks.postStart }}
    {{- $postcmd := .Values.hooks.postStart | join ";" }}
    postStart:
      exec:
        command: [ "/bin/sh", "-c", {{ printf "/bin/bash /hooks/%s" $postcmd | quote }} ]
    {{- end }}
    {{- if .Values.hooks.preStop}}
    {{- $precmd := .Values.hooks.preStop | join ";" }}
    preStop:
      exec:
        command: [ "/bin/sh", "-c", {{ printf "/bin/bash /hooks/%s" $precmd | quote }} ]
    {{- end }}
  {{- end }}
{{- end }}


{{- define "tc.container.conf" -}}
  {{- $dot := . }}
  {{- $secKeyDict := dict "allowPrivilegeEscalation" 0 "capabilities" 0 "privileged" 0 "procMount" 0 "readOnlyRootFilesystem" 0 "runAsGroup" 0 "runAsNonRoot" 0 "runAsUser" 0 "seLinuxOptions" 0 "seccomProfile" 0 "windowsOptions" 0}}
  command: [ "/bin/sh" ]
  {{- if $dot.Values.entrypoint }}
  args: [ "-c", {{ $dot.Values.entrypoint | squote }} ]
  {{- else}}
  args: [ "-c", "/usr/IMS/current/tools/cfginit" ]
  {{- end }}
  {{- if hasKey $dot.Values.global "image" }}
  {{- $imagefullname := printf "%s/%s" ($dot.Values.global.image.repository) $dot.Values.image }}
  {{- if not (contains ":" $imagefullname) }}
  {{- $imagefullname = printf "%s/%s:%s" ($dot.Values.global.image.repository) $dot.Values.image $dot.Values.global.image.tag }}
  {{- end }}
  image: {{ $imagefullname | replace "//" "/" }}
  imagePullPolicy: {{ $dot.Values.imagePullPolicy | default ($dot.Values.global.image.pullPolicy |default "Always") }}
  {{- else }}
  image: {{ $dot.Values.image }}
  imagePullPolicy: {{ $dot.Values.imagePullPolicy | default "Always" }}
  {{- end }}
  {{- $containerKeys := list "securityContext" "resources" "ports" "startupProbe" "stdinOnce" "volumeDevices" "workingDir" }}
  {{- range $key :=  $containerKeys }}
  {{- if hasKey $dot.Values $key }}
  {{- if eq "securityContext" $key }}
  securityContext:
    {{- $secValues := get $dot.Values $key}}
    {{- range $k, $v :=  $secValues }}
      {{- if hasKey $secKeyDict $k }}
    {{ $k }}: {{ $v | toYaml | nindent 6 }}
      {{- end }}
    {{- end }}
  {{- else }}
  {{ $key }}: {{ pluck $key $dot.Values | first | toYaml | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
  {{- if $dot.Values.readinessProbe }}
  readinessProbe:
    {{- $dot.Values.readinessProbe | toYaml| nindent 4 }}
  {{- end }}
  {{- if $dot.Values.livenessProbe }}
  livenessProbe:
    {{- $dot.Values.livenessProbe | toYaml| nindent 4 }}
  {{- end }}
  stdin: {{ $dot.Values.stdin | default "true" }}
  tty: {{ $dot.Values.tty | default "true" }}
  terminationMessagePath: {{ $dot.Values.terminationMessagePath | default "/dev/termination-log" }}
  terminationMessagePolicy: {{ $dot.Values.terminationMessagePolicy | default "File" }}

{{- end }}
{{- define "tc.sidecars" }}
        {{- range $car, $conf := $.Values.global.sidecars }}
        {{- if has $.Chart.Name  $conf.inject }}
        - name: {{ $car }}
          {{- if hasKey $.Values.global "image" }}
          {{- $imagefullname := printf "%s/%s" ($.Values.global.image.repository) $conf.image }}
          image: {{ $imagefullname | replace "//" "/" }}
          imagePullPolicy: {{ $conf.imagePullPolicy | default ($.Values.global.image.pullPolicy |default "Always") }}
          {{- else }}
          image: {{ $conf.image }}
          imagePullPolicy: {{ $conf.imagePullPolicy | default "Always" }}
          {{- end }}
          {{- if $conf.securityContext }}
          securityContext: {{ $conf.securityContext | toYaml |nindent 12 }}
          {{- else }}
          securityContext:
            privileged: true
            procMount: Default
          {{- end }}
          volumeMounts:
            {{- $sidecars := $.Values.global.sidecars | default (dict) }}
            {{- $vtapObj := $sidecars.vtap | default (dict) }}
            {{- $vtapSecrets := $vtapObj.secrets | default (dict) }}
            {{- $chartName := $.Chart.Name }}
            {{- $secObj := index $vtapSecrets $chartName | default list }}
            {{- if $secObj }}
            {{- if or (not (hasKey $vtapObj "createSecrets")) $vtapObj.createSecrets }}
            - name: vtap
              mountPath: /etc/vtap/secrets
              readOnly: true
            {{- else }}
            {{- range $secitem := $secObj }}
            - name: {{ $secitem }}
              mountPath: /etc/vtap/secrets
              readOnly: true
            {{- end }}
            {{- end }}
            {{- end }}
          resources:
            {{- $conf.resources | toYaml | nindent 12 }}
          env:
            {{- range $key, $value := $conf.env }}
            - name: {{ $key }}
            {{- if kindIs "string" $value }}
              {{- if regexMatch "<.*>" (print $value) }}
              valueFrom:
                fieldRef:
                  fieldPath: {{trimPrefix "<" $value|trimSuffix ">"|quote}}
              {{- else }}
              value: {{$value}}
              {{- end }}
            {{- else if kindIs "map" $value }}
              {{- if hasKey $value $.Chart.Name }}
              value: {{ get $value $.Chart.Name }}
              {{- else}}
              value: {{ upper $.Chart.Name }}
              {{- end}}
            {{- else }}
              value: {{ $value | quote }}
            {{- end}}
            {{- end}}
        {{- end }}
        {{- end }}

{{- end }}

{{/*
********************************************
userdata and eipmap are in directory 'userdata'.
*/}}

{{- define "tc.confmap" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: {{ include "tc.namespace" . }}
  name: probe-{{ .Chart.Name }}-configmap
data:
  readiness_check.py: |
  {{- $.Files.Get "probe/readiness_check.py" | nindent 4 }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: {{ include "tc.namespace" . }}
  name: livenessprobe-{{ .Chart.Name }}-configmap
data:
  liveness_check.py: |
  {{- $.Files.Get "livenessprobe/liveness_check.py" | nindent 4 }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: {{ include "tc.namespace" . }}
  name: {{ .Chart.Name }}-configmap
data:
  {{- range $k, $v := .Values.configmap }}
  {{- if kindIs "string" $v }}
  {{- if not (regexMatch ":b$" $v) }}
  {{ $k }}: |
  {{- $.Files.Get $v | nindent 4 }}
  {{- end }}
  {{- else if kindIs "slice" $v }}
  {{- range $j := $v }}
  {{- if not (regexMatch ":b$" $j) }}
  {{ splitList "/" $j | last }}: |
  {{- $.Files.Get (printf "%s/%s" $k $j) | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
  {{- end }}
  {{- if .Values.extra_user_data }}
  extra_user_data: |
    {{- .Values.extra_user_data | toYaml | nindent 4 }}
  {{- end }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: {{ include "tc.namespace" . }}
  name: {{ .Chart.Name }}-binary-configmap
binaryData:
  {{- range $k, $v := .Values.configmap }}
  {{- if kindIs "string" $v }}
  {{- if regexMatch ":b$" $v }}
  {{ $k }}: |
  {{- $name := splitList ":" $v | first }}
  {{- $.Files.Get $name | b64enc  | nindent 4 }}
  {{- end }}
  {{- else if kindIs "slice" $v }}
  {{- range $j := $v }}
  {{- if regexMatch ":b$" $j }}
  {{- $name := splitList ":" (splitList "/" $j | last) | first }}
  {{ $name }}: |
  {{- $.Files.Get (printf "%s/%s" $k $name) | b64enc  | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
  {{- end }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: {{ include "tc.namespace" . }}
  name: {{ .Chart.Name }}-extra-configmap
data:
  {{- if .Values.networking }}
  {{- if .Values.networking.ipPools }}
    {{- if gt (len ( get .Values.networking "ipPools")) 1024 }}
      {{- fail "The number of IP Pools exceeds the maximum (1024)." }}
    {{- end }} 
    {{- $ippool := dict }}
    {{- range $_, $v := .Values.networking.ipPools }}
      {{- $ippool = set $ippool $v.name $v.addresses }}
    {{- end }}
  network-ip-pools: |
    {{- toYaml $ippool | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- if .Values.cmsIPAddresses }}
    {{- $config := dict }}
    {{- $ip_list := list }}
    {{- range $_, $v := .Values.cmsIPAddresses }}
      {{- if regexMatch ".*:.*:" $v }}
        {{- if hasSuffix "]" $v }} 
          {{- $v = printf "%s:4334" $v }}
        {{- else if not (contains "]:" $v) }}
          {{- $v = printf "[%s]:4334" $v }}
        {{- end }}
      {{- else }}
        {{- if not (contains ":" $v) }}
          {{- $v = printf "%s:4334" $v }}
        {{- end }}
      {{- end }}
      {{- $ip_list = append $ip_list $v }}
    {{- end }}
    {{- $config = set $config "CMS_IP_ADDRESSES" $ip_list }}
  config: |
    {{- toYaml $config | nindent 4 }}
  {{- end }}
---
{{- if .Values.hooks }}
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: {{ include "tc.namespace" . }}
  name: {{ .Chart.Name }}-hooks
data:
{{- range .Values.hooks.postStart }}
  {{.}}: |
  {{ $.Files.Get (cat "hooks/" . | nospace) | nindent 4 }}
{{- end}}
{{- range .Values.hooks.preStop }}
  {{.}}: |
  {{ $.Files.Get (cat "hooks/" . | nospace) | nindent 4 }}
{{- end }}
{{- end }}
{{- end }}
