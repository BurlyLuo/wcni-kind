# coding=utf-8

# Branch: plat-r7
# Author: kefei.zhang@mavenir.com
# derived from cfginit.py by Xianfeng Shao
# Version: v 1.1.26 2023-03-16 17:42:06

import pprint
import os
import sys
import stat
import re
import json
import time
import glob
import yaml
import logging
import xml.dom.minidom as dom
from lxml import etree as ET
import netifaces
import base64

sys.path.append(r"../")
import ip_util

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s [%(levelname)s] %(message)s', datefmt="%Y-%m-%d %H:%M:%S",
                    filename="/var/log/cfginit.log", filemode="w")
console = logging.StreamHandler()
console.setLevel(logging.INFO)
console.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
logging.getLogger().addHandler(console)

if sys.version.startswith("3."):
    import subprocess
    commands = subprocess
else:
    import commands
    commands = commands

def unicodeStr(string):
    res = string
    if sys.version.startswith("2."):
        return unicode(string)
    return str(res)

if os.path.exists('/etc/sudoers.d/mav_sudo'):
    sudofile='/etc/sudoers.d/mav_sudo'
else:
    sudofile='/etc/sudoers'

class Cfginit(object):
    debug = False
    isContainer = True
    vcloud_info = {}
    traffic_info = {}
    vdu = {}
    net_pools = {}
    intf_data = {}
    doorbell_info = {}
    sssd_dict = {}
    ldap_list = []
    ssh_status = None
    https_status = None
    ldap_status = None
    ldap_cert = ""
    ldap_basedn = ""
    ssh_public_key = None
    dhcp_intfs = {}
    network_info = {}
    pod_intf_data = {}
    sdns_auth = None

    doc = dom.Document()

    dns_info = {"server": [], "search": []}

    def handleErr(self, messages=None):
        if messages:
            logging.error(messages)
        if os.path.exists(r"/etc/init.d/IMS"):
            os.system("chkconfig IMS off")
        exit(1)

    def isInNet(self, ip, net):
        if not ip:
            return True
        ipaddr = ip_util.ip_address(unicodeStr(ip))
        try:
            if ipaddr in net:
                return True
        except (Exception):
            return False

    def isInContainer(self):
        return self.isContainer

    def isAWSContainer(self):
        self.aws_region = os.getenv('AWS_REGION')
        if self.aws_region:
            if os.path.exists(os.path.join(os.path.dirname(__file__), '../tools/vpcIpv4.py')):
                commands.getstatusoutput('ln -s ../tools/vpcIpv4.py /usr/IMS/current/bin/vpcIpv4.py 2>/dev/null')
            if os.path.exists(os.path.join(os.path.dirname(__file__), '../tools/vpcIpv6.py')):
                commands.getstatusoutput('ln -s ../tools/vpcIpv6.py /usr/IMS/current/bin/vpcIpv6.py 2>/dev/null')
            commands.getstatusoutput('ln -s ../tools/vpcIp /usr/IMS/current/bin/vpcIp 2>/dev/null')
            commands.getstatusoutput('ln -s ../tools/addVip.sh /usr/IMS/current/bin/addVip.sh 2>/dev/null')
            commands.getstatusoutput('ln -s ../tools/rmVip.sh /usr/IMS/current/bin/rmVip.sh 2>/dev/null')
            commands.getstatusoutput(r" sed -i 's/_region_name_/{0}/' /usr/IMS/current/tools/addVip.sh".format(self.aws_region))
            commands.getstatusoutput(r" sed -i 's/_region_name_/{0}/' /usr/IMS/current/tools/rmVip.sh".format(self.aws_region))

            # add Pip
            commands.getstatusoutput('ln -s ../tools/assignVpcAddr.sh /usr/IMS/current/bin/assignVpcAddr.sh 2>/dev/null')
            commands.getstatusoutput(r" sed -i 's/_region_name_/{0}/' /usr/IMS/current/tools/assignVpcAddr.sh".format(self.aws_region))
            commands.getstatusoutput('ln -s ../tools/unassignVpcAddr.sh /usr/IMS/current/bin/unassignVpcAddr.sh 2>/dev/null')
            commands.getstatusoutput(r" sed -i 's/_region_name_/{0}/' /usr/IMS/current/tools/unassignVpcAddr.sh".format(self.aws_region))

    def get_namespace(self, file_name):
        status, out = commands.getstatusoutput("cat {0}".format(file_name))
        if status == 0:
            return re.findall(r'\s+namespace\s+"(.*)";', out)[0]
        return None

    def vm_fill_vcloud_info(self, env, intf_map):
        root = env
        mac_list = [e.items()[0][1] for s in root if "EthernetAdapterSection" in s.tag for e in s]
        # initialize self.vcloud_info['ethX']
        for i, mac in enumerate(mac_list):
            ifname = "eth{i}".format(i=i)
            self.vcloud_info[ifname] = {"V4": ['', '', 0, ''], "V6": ['', '', 0, ''], "MTU": 9000, "MAC": mac}

    def op_fill_vcloud_info(self, if_suffix_list):
        """
        fill vcloud_info basing on network_data.json.

        Returns:
            A dict:
        """
        # parse Json
        network_data = None
        if os.path.exists(network_data_file):
            with open(network_data_file) as fd:
                network_data = json.load(fd)
        if network_data:
            taps = [link.get("id") for link in network_data.get("links")]
            mtus = [link.get("mtu") for link in network_data.get("links")]
            mac_list = [link.get("ethernet_mac_address") for link in network_data.get("links")]
            # interfaces = os.listdir("/sys/class/net/")

            # initialize self.vcloud_info['ethX']
            for i, mac in enumerate(mac_list):
                mtu = mtus[i]
                self.vcloud_info["eth{i}".format(i=i)] = {"V4": ['', '', 0, ''], "V6": ['', '', 0, ''], "MTU": mtu, "MAC": mac}

            # [ type, ip, prefix, gw ]
            if network_data.get("networks"):
                tmp_tap_info = [{net.get("link"): [net.get("type", ""), net.get("ip_address", ""), ip_util.prefix_from_netmask_string(net.get("netmask", "0.0.0.0")), net.get("routes", "")]} for net in network_data.get("networks")]
                for i, tap in enumerate(taps):
                    for info_dict in tmp_tap_info:
                        info_list = info_dict.get(tap, None)
                        if info_list:
                            if info_list and info_list[-1]:
                                info_list[-1] = info_list[-1][0].get("gateway", None)
                            if "ipv4" in info_list[0]:
                                self.vcloud_info["eth{i}".format(i=i)]["V4"] = info_list
                            elif "ipv6" in info_list[0]:
                                self.vcloud_info["eth{i}".format(i=i)]["V6"] = info_list
        else:
            for i in if_suffix_list:
                with open('/sys/class/net/eth{i}/mtu'.format(i=i)) as fp:
                    mtu = int(fp.read().replace('\n', ''))
                with open('/sys/class/net/eth{i}/address'.format(i=i)) as fp:
                    mac = fp.read().replace('\n', '')
                self.vcloud_info["eth{i}".format(i=i)] = {"V4": ['', '', 0, ''], "V6": ['', '', 0, ''], "MTU": mtu, "MAC": mac}

    def get_info_from_vcloud_info(self, info):
        """
        give the iterface name to get some information from self.vcloud_info.

        Args:
            info: a intem of self.traffic_info;
        Returns:
            return a tuple:
            (mtu, mac, proto, ip_info, ipv6_info)
        """
        def _get_v6_prefix_gw(info, net_info):
            ipaddr_v6 = None
            prefix_v6 = info.get('PREFIX', None)
            gateway_v6 = info.get("IPV6_DEFAULTGW", None)
            if "IPV6ADDR" in info:
                 tlist = info.get("IPV6ADDR").split(r"/")+[prefix_v6]
                 ipaddr_v6, prefix_v6 = tlist[0], tlist[1]
            if net_info:
                prefix_v6 = prefix_v6 or net_info['V6'][2] or '128'
                gateway_v6 = gateway_v6 or net_info['V6'][3] or None
            prefix_v6 = prefix_v6 or '128'
            return ipaddr_v6, prefix_v6, gateway_v6
        
        def _get_v4_prefix_gw(info, net_info):
            intf = info.get('IFNAME')
            ipaddr_v4 = info.get("IPADDR", None)
            prefix_v4 = info.get("PREFIX", '32')
            if int(prefix_v4) > 32 and intf in self.pod_intf_data:
                prefix_v4 = self.pod_intf_data.get(intf, {}).get('mask', None) or '32'
            gateway_v4 = info.get("GATEWAY", None)
            if net_info:
                prefix_v4 = prefix_v4 or net_info['V4'][2] or '32'
                gateway_v4 = gateway_v4 or net_info['V4'][3] or None
            prefix_v4 = prefix_v4 or '32'
            return ipaddr_v4, prefix_v4, gateway_v4

        def _is_in_network(ip, prefix, gw, iptype):
                ip_network = None
                if gw and ip and prefix:
                    ip_network = ip_util.ip_interface(unicodeStr("{ip}/{prefix}".format(ip=ip, prefix=prefix))).network
                    if not self.isInNet(gw, ip_network):
                        self.handleErr("the ip: {ip}/{prefix} and the gateway: {gw} are not in the same subnet.\n".format(ip=ip, prefix=prefix, gw=gw))

        ifname = info["IFNAME"].replace("fp", "")
        ip_prefix_gw_v4_str = ip_prefix_gw_v6_str = None

        net_info = self.vcloud_info.get(ifname, None)

        ipaddr_v4, prefix_v4, gateway_v4 = _get_v4_prefix_gw(info, net_info)
        ipaddr_v6, prefix_v6, gateway_v6 = _get_v6_prefix_gw(info, net_info)
        _is_in_network(ipaddr_v4, prefix_v4, gateway_v4, 'v4')
        _is_in_network(ipaddr_v6, prefix_v6, gateway_v6, 'v6')

        if not net_info:
            if info["TYPE"] == "bond":
                mtu = min([self.vcloud_info.get(s.replace('fp', ''), {}).get('MTU', 1500) for s in info.get('SUBPORT', info.get('SLAVE', '')).split(',')])
                prefix = info.get("PREFIX", None) or max([self.vcloud_info.get(s.replace('fp', ''), {}).get('V4', [0] * 4)[2] for s in info.get('SUBPORT', info.get('SLAVE', '')).split(',')])
                ip_prefix_gw_v4_str = "{ip}/{pr}/{gw}".format(ip=info.get("IPADDR", None), pr=prefix, gw=gateway_v4)
                prefix_v6 = prefix_v6 or max([self.vcloud_info.get(s.replace('fp', ''), {}).get('V6', [0] * 4)[2] for s in info.get('SUBPORT', info.get('SLAVE', '')).split(',')])
                ip_prefix_gw_v6_str = "{ip}/{pr}/{gw}".format(ip=ipaddr_v6, pr=prefix_v6, gw=gateway_v6)
                return (info.get("MTU", 0) or mtu, None, "static", ip_prefix_gw_v4_str, ip_prefix_gw_v6_str)
            elif info["TYPE"] == "vRouter":
                ip_prefix_gw_v4_str = "{ip}/{pr}/{gw}".format(ip=ipaddr_v4, pr=prefix_v4, gw=gateway_v4)
                ip_prefix_gw_v6_str = "{ip}/{pr}/{gw}".format(ip=ipaddr_v6, pr=prefix_v6, gw=gateway_v6)
                return (info.get("MTU", 1500), None, "static", ip_prefix_gw_v4_str, ip_prefix_gw_v6_str)
            elif 'fpeth' in info["IFNAME"]:
                # if the cfginit ran after eth is taken by fpeth, would fall into here
                logging.info("%s cannot find corresponding eth in container, read information from user-data", info["IFNAME"])
                ip_prefix_gw_v4_str = "{ip}/{pr}/{gw}".format(ip=ipaddr_v4, pr=prefix_v4, gw=gateway_v4)
                ip_prefix_gw_v6_str = "{ip}/{pr}/{gw}".format(ip=ipaddr_v6, pr=prefix_v6, gw=gateway_v6)
                return (info.get("MTU", None), None, "static", ip_prefix_gw_v4_str, ip_prefix_gw_v6_str)
            else:
                self.handleErr("invalid interface. interface: {intf}\n".format(intf=ifname))

        # get mtu and proto
        mac = net_info.get("MAC")
        mtu = info.get("MTU", None) or net_info.get("MTU", None)
        proto = "ipv4_dhcp"

        # if net_info.get("V4") and len(net_info.get("V4")):
        #     if prefix_v4:
        #         prefix_v4 = max(int(prefix_v4), int(net_info.get("V4")[2]))
        #     else:
        #         prefix_v4 = net_info.get("V4")[2]

        # if (not ipaddr_v4) and (not ipaddr_v6) and net_info.get("V4") and len(net_info.get("V4")):
        #     ipaddr_v4 = net_info.get("V4")[1] or None
        # if (not ipaddr_v4) and (not ipaddr_v6) and net_info.get("V6") and len(net_info.get("V6")):
        #     ipaddr_v6 = net_info.get("V6")[1] or None

        ip_prefix_gw_v4_str = "{ip}/{pr}/{gw}".format(ip=ipaddr_v4, pr=prefix_v4, gw=gateway_v4)
        ip_prefix_gw_v6_str = "{ip}/{pr}/{gw}".format(ip=ipaddr_v6, pr=prefix_v6, gw=gateway_v6)
        if ipaddr_v4 or ipaddr_v6:
            proto = "static"
        elif "dhcp" in net_info.get("V6")[0]:
            proto = "ipv6_dhcp"

        return (mtu, mac, proto, ip_prefix_gw_v4_str, ip_prefix_gw_v6_str)

    def fill_intf_data(self):
        """
        fill intf_data basing on self.vcloud_info and self.traffic_info.
        """
        types = set(['bond', 'vRouter', 'Ethernet'])
        for traffic, info in self.traffic_info.items():
            if info['TYPE'] not in types:
                self.handleErr("Unsupported type.")
            
            mtu, mac, proto, ip_info, ipv6_info = self.get_info_from_vcloud_info(info)

            gateway = info.get("GATEWAY") or info.get("IPV6_DEFAULTGW")
            defaultgw = info.get("DEFAULTGW")
            if not defaultgw:
                defaultgw = "no"
            else:
                defaultgw = "yes"

            # traffic_info is from user_data, vcloud_info is the container's interface information
            # if interface in traffic_info does not in container vcloud_info, 2 possibilities:
            # 1. the user-data is wrong, defined an un-exist interface
            # 2. the fpeth interfaces, they are initilzed as ethx, but in user-data they are fpethx
            #    this is by design, the DP mgr would change the name when it starts
            # so we need to handle both cases here
            if self.isInContainer() and ("BondEthernet" in info["IFNAME"] or "fpbond" in info["IFNAME"]):
                if info["IFNAME"] not in self.intf_data:
                    self.intf_data[info["IFNAME"]] = {"IPS": set(), "PROPTO": "", "TRAFFIC": {
                        traffic: {"IPS": set(),
                                "RE": set(),
                                "DEFAULTGW": defaultgw,
                                "TYPE": "bond",
                                "SUBPORT": info.get("SUBPORT", info.get('SLAVE', '')) or '',
                                "OPTS": info.get("OPTS", None),
                                "GATEWAY": gateway}}}
            # elif self.isInContainer() and (('fpeth' not in info["IFNAME"] and not self.vcloud_info.get(info["IFNAME"])) or info['TYPE'] != 'vRouter') :
            #     continue

            # if 'VLAN' in info:
            #     info['IFNAME'] = "{intf}.{sub}".format(intf=info["IFNAME"], sub=info['VLAN'])
                # if 'fpeth' in info['IFNAME'] and 'IFMAP' in info:
                #     info['IFMAP'] = "{intf}.{sub}".format(intf=info["IFMAP"], sub=info['VLAN'])

            # initialize self.intf_data
            if info["IFNAME"] not in self.intf_data:
                self.intf_data[info['IFNAME']] = {"IPS": set(), "PROPTO": "", "TRAFFIC": {
                    traffic: {"IPS": set(), "RE": set(), "DEFAULTGW": defaultgw, "GATEWAY": gateway}}}
            self.intf_data[info['IFNAME']]["DEFAULTGW"] = defaultgw
            self.intf_data[info['IFNAME']]["TYPE"] = info.get("TYPE")
            if self.intf_data[info['IFNAME']]["TYPE"] == "bond":
                self.intf_data[info['IFNAME']]["SUBPORT"] = info.get("SUBPORT", info.get('SLAVE', '')) or ''
                self.intf_data[info['IFNAME']]["OPTS"] = info.get("OPTS", None)
            self.intf_data[info['IFNAME']]["MTU"] = mtu
            if (not info['IFNAME'].startswith('fp')) and info['TYPE'] == 'Ethernet':
                mtu_from_dev = self.vcloud_info.get(info['IFNAME']).get('MTU')
                if mtu_from_dev != mtu:
                    logging.warn("will update the device %s's MTU from %s to %s", info['IFNAME'], mtu_from_dev, mtu)
                    os.system('ip link set dev {} mtu {}'.format(info['IFNAME'], mtu))

            if traffic not in self.intf_data[info['IFNAME']]["TRAFFIC"]:
                self.intf_data[info['IFNAME']]["TRAFFIC"][traffic] = {"IPS": set(), "DEFAULTGW": defaultgw}
            self.intf_data[info['IFNAME']]["TRAFFIC"][traffic]["IPS"].add(ip_info)
            self.intf_data[info['IFNAME']]["TRAFFIC"][traffic]["IPS"].add(ipv6_info)
            self.intf_data[info['IFNAME']]["MAC"] = mac
            self.intf_data[info['IFNAME']]["PROPTO"] = proto
            self.intf_data[info['IFNAME']]["PORTTYPE"] = info.get("PORTTYPE", None)
            self.intf_data[info['IFNAME']]["SPEED"] = info.get("SPEED", 1000)
            if 'VLAN' not in self.intf_data[info['IFNAME']]:
                self.intf_data[info['IFNAME']]['VLAN'] = self.intf_data[info['IFNAME']].get('VLAN', set())
            if info.get("VLAN", None):
                self.intf_data[info['IFNAME']]['VLAN'].add(info.get("VLAN"))
            # FE-internal
            if "RE" in self.intf_data[info['IFNAME']]["TRAFFIC"][traffic]:
                self.intf_data[info['IFNAME']]["TRAFFIC"][traffic]["RE"].add(info.get("REMOTE_TRAFFIC_TYPE"))
            self.intf_data[info['IFNAME']]["IPS"] |= self.intf_data[info['IFNAME']]["TRAFFIC"][traffic]["IPS"]
            if "dhcp" in self.intf_data[info['IFNAME']]["PROPTO"]:
                self.dhcp_intfs.setdefault(info['IFNAME'], {"ipv4": None, "ipv6": None})

    def parse_ovfEnv(self):
        if self.debug:
            # ###### just for self.debug ##################
            tree = ET.parse(out_xml)
            root = tree.getroot()
            # ######### self.debug end ####################
        else:
            try_again = False
            if os.path.exists(r"/var/lib/cfginit_ovfEnv"):
                with open(r"/var/lib/cfginit_ovfEnv") as fd:
                    if not fd.read():
                        try_again = True
            else:
                try_again = True
            if try_again:
                status, vm_net = commands.getstatusoutput(r'vmtoolsd --cmd="info-get guestinfo.ovfEnv" >/var/lib/cfginit_ovfEnv')
                if status != 0:
                    self.handleErr("fail to execute vmtoolsd.")
            tree = ET.parse(r"/var/lib/cfginit_ovfEnv")
            root = tree.getroot()
        return root

    def vm_fill_traffic_info(self, env):
        """
        fill self.traffic_info and some global structs basing a user_data

        Returns:
            The self.traffic_info.
            Notice:
            TYPE: Ethernet/bond/vRouter
        """
        root = env
        key_value_dict = dict([[e.items()[0][1], e.items()[1][1]] for s in root if "PropertySection" in s.tag for e in s if "vnfmUserData." in e.items()[0][1]])

        def _parse(prefix):
            res = {}
            for m, n in key_value_dict.items():
                for e in m.split('.')[::-1]:
                    n = {e: n}
                tmp_res = res
                while(n):
                    k, v = n.popitem()
                    if k in tmp_res:
                        tmp_res = tmp_res.get(k)
                        n = v
                    else:
                        if isinstance(v, str):
                            if v.lower() == 'yes' or v.lower() == 'true':
                                v = True
                            elif v.lower() == 'no' or v.lower() == 'false':
                                v = False
                        tmp_res.setdefault(k, v)
            return res.pop(prefix, {})

        data = _parse('vnfmUserData')
        self.traffic_info = data.get('network', {})
        self.doorbell_info = data.get('config', {})
        self.vdu = data.get('vdu', {}) or {}
        self.net_pools = {k: v.split(',') for k, v in (data.get("network-ip-pools", {}) or {}).items()}
        vmname = data.pop('vm', {}).get('vmname', '')
        self.doorbell_info['vmname'] = vmname

        for m, n in key_value_dict.items():
            if "vCloud_dns1" in m and n not in self.dns_info["server"]:
                self.dns_info["server"].append(n)

        if vmname:
            self.doorbell_info["SYSTEM_ID"] = vmname
        if len(self.doorbell_info) <= 1:
            self.doorbell_info = {}

    def op_fill_traffic_info(self):
        """
        fill self.traffic_info and some global structs basing a user_data

        Returns:
            The self.traffic_info.
            Notice:
            TYPE: Ethernet/bond/vRouter
        """
        # parse YAMl

        with open(user_data_file) as fd:
            user_data = yaml.load(fd, Loader=yaml.FullLoader)
        self.traffic_info = user_data.get("network")

        self.net_pools = user_data.get("network-ip-pools", {}) or {}

        # for doorbell, timezone, vnfmInfo
        if user_data.get("config"):
            config = user_data.get("config")
            self.doorbell_info = config
            if self.doorbell_info:
                if self.isInContainer():
                    self.doorbell_info["SYSTEM_ID"] = os.getenv("MY_POD_UID")
                    self.doorbell_info["VNFC_INSTANCE_ID"] = os.getenv("MY_POD_NAME")
                else:
                    with open(meta_data_file) as fd:
                        meta_data = json.load(fd)
                        self.doorbell_info.setdefault("SYSTEM_ID", meta_data.get("uuid"))
                        self.doorbell_info.setdefault('vmname', meta_data.get("name"))
                        self.doorbell_info.setdefault('keys', meta_data.get("keys", []))
            if len(self.doorbell_info) <= 1:
                self.doorbell_info = {}

        # for vdu
        self.vdu = user_data.get("vdu", {}) or {}

        # for runcmd
        if user_data.get("runcmd"):
            # comment out debugging
            # logging.info("runcmd :\n%s", user_data.get("runcmd"))
            with open(tmp_cmd_file, "w") as fd:
                fd.write(user_data.get("runcmd"))

    def generate_ifcfg(self, conf_dir):
        gateway_v4_intf = None
        gateway_v6_intf = None
        slaves = ""
        # remove old ifcfg files
        old_ifcfg_files = glob.glob(r"/etc/sysconfig/network-scripts/ifcfg-*")
        for ifcfg_file in old_ifcfg_files:
            if "lo" in ifcfg_file:
                continue
            os.remove(ifcfg_file)

        for intf, data in self.intf_data.items():
            if data.get("TYPE") == "vRouter":
                continue
            index_ipv4 = 1
            index_ipv6 = 1
            ipv6_sec_ips = ""
            if intf in slaves:
                continue
            if "fp" not in intf:
                defaultgw = data["DEFAULTGW"]
                proto = None
                # v6init = None
                # autoconf = None
                if not data.get("PROPTO"):
                    proto = "none"
                elif "ipv4_dhcp" in data.get("PROPTO"):
                    proto = "dhcp"
                    if defaultgw == "yes":
                        gateway_v4_intf = intf
                ifcfg = """# generate by mav-cfginit
TYPE={type}
NAME={dev}
DEVICE={dev}
BOOTPROTO={proto}
USERCTL=no
ONBOOT=yes
BONDING_OPTS="{opts}"
MTU={mtu}
ETHTOOL_OPTS="{eth_ops}"
""".format(type=data.get("TYPE"), dev=intf, proto=proto, opts=data.get("OPTS"), mtu=data.get("MTU"), eth_ops=data.get("ETHTOOL_OPTS", ""))
                if "dhcp" in data.get("PROPTO"):
                    ifcfg += "PEERDNS=no\n"

                # for bond
                if "bond" in intf:
                    if data.get("TYPE") != "bond":
                        self.handleErr("the TYPE ('{tp}') is incorrect for bond interface.".format(tp=data.get("TYPE")))
                    slaves = ""
                    if data.get("SUBPORT"):
                        slaves = data.get("SUBPORT").split(",")
                    for slave in slaves:
                        slave_ifcfg = """# generate by mav-cfginit
DEVICE={slave}
BOOTPROTO=none
ONBOOT=yes
MASTER={bond}
SLAVE=yes
USERCTL=no
MTU={mtu}
""".format(slave=slave, bond=intf, mtu=data.get("MTU"))
                        slave_ifcfg = re.sub(".*None.*\n", "", slave_ifcfg)
                        logging.info("slave ifcfg ----> %s:\n %s", slave, slave_ifcfg)
                        if not self.debug:
                            with open(r"{conf_dir}/ifcfg-{name}".format(conf_dir=conf_dir, name=slave), "w") as fd:
                                fd.write(slave_ifcfg)
                # add IP
                if "ipv6_dhcp" in data.get("PROPTO"):
                    commands.getoutput(r"sed -i '/net.ipv6.conf.{intf}.accept_ra/d' /etc/sysctl.conf".format(intf=intf))
                    commands.getoutput(r"echo 'net.ipv6.conf.{intf}.accept_ra=1' >> /etc/sysctl.conf".format(intf=intf))
                    commands.getoutput("sysctl -p")
                    ifcfg += "IPV6INIT=yes\nIPV6_AUTOCONF=no\nDHCPV6C=yes\n"
                    if defaultgw == "yes":
                        gateway_v6_intf = intf
                    if "ipv4_dhcp" not in data.get("PROPTO"):
                        ifcfg = re.sub(r"BOOTPROTO=.*\n", "", ifcfg)
                for ip_prefix_gw in data["IPS"]:
                    if ip_prefix_gw:
                        ip, prefix, gw = ip_prefix_gw.split(r"/")
                        if ip != 'None':
                            ipaddr = ip_util.ip_address(unicodeStr(ip))
                            if isinstance(ipaddr, ip_util.IPv4Address):
                                ifcfg += "IPADDR{id}={ip}\nPREFIX{id}={pr}\n".format(id=index_ipv4, ip=ip, pr=prefix)
                                # set gw
                                if defaultgw == "yes" and gw:
                                    if not gateway_v4_intf:
                                        ifcfg += "GATEWAY={gw}\n".format(gw=gw)
                                    if gateway_v4_intf and gateway_v4_intf != intf:
                                        self.handleErr(
                                            "Failure adding gw to {name}, an IPv4 gateway has set on other interface".format(
                                                name=gateway_v4_intf))
                                    gateway_v4_intf = intf
                                index_ipv4 += 1
                            elif isinstance(ipaddr, ip_util.IPv6Address):
                                if index_ipv6 == 1:
                                    ifcfg += "IPV6INIT=yes\nIPV6_AUTOCONF=no\nIPV6ADDR={ip}/{pr}\n".format(ip=ip, pr=prefix)
                                else:
                                    ipv6_sec_ips += "{ip}/{pr} ".format(ip=ip, pr=prefix)
                                if defaultgw == "yes" and gw:
                                    if not gateway_v6_intf:
                                        ifcfg += "IPV6_DEFAULTGW={gw}\n".format(gw=gw)
                                    if gateway_v6_intf and gateway_v6_intf != intf:
                                        self.handleErr(
                                            "Failure adding gw to {name}, an IPv6 gateway has set on other interface".format(
                                                name=gateway_v6_intf))
                                    gateway_v6_intf = intf
                                index_ipv6 += 1

                if re.findall(r"IPADDR\d=", ifcfg).__len__() == 1:
                    ifcfg = re.sub(r"IPADDR\d=", r"IPADDR=", ifcfg)
                    ifcfg = re.sub(r"PREFIX\d=", r"PREFIX=", ifcfg)
                if ipv6_sec_ips:
                    ifcfg += 'IPV6ADDR_SECONDARIES="{ips}"\n'.format(ips=ipv6_sec_ips.strip())
                ifcfg = re.sub(r".*None.*\n", r"", ifcfg)
                logging.info("interface ifcfg ----> %s:\n %s", intf, ifcfg)
                if not self.debug:
                    with open(r"/etc/sysconfig/network-scripts/ifcfg-{name}".format(name=intf), "w") as fd:
                        fd.write(ifcfg)
        with open(r"/etc/sysconfig/network", "r+") as fd:
            content = fd.read()
            content = re.sub(r"\nGATEWAYDEV=.*", "", content)
            content = re.sub(r"\nGATEWAY=.*", "", content)
            gw_dev = gateway_v4_intf or gateway_v6_intf
            if gw_dev:
                content += "GATEWAYDEV={dev}\n".format(dev=gw_dev)
                logging.info("update /etc/sysconfig/network: gateway dev = %s", gw_dev)
            if not self.debug:
                fd.seek(0)
                fd.truncate()
                fd.write(content)
        if not self.debug:
            logging.info("restart network service.")
            out = commands.getoutput("service network restart")
            logging.info("output: \n%s", out)

        # get dhcp interface ip
        for intf in self.dhcp_intfs.keys():
            out = commands.getoutput("ip a s {intf}".format(intf=intf))
            m = re.search(r"inet (\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}/\d{1,2})\D+", out)
            if m:
                self.dhcp_intfs[intf]["ipv4"] = m.group(1)
            m = re.findall(r"inet6 (.*?)\s+", out)
            for ipv6 in m:
                if ipv6[0:4] != "fe80":
                    self.dhcp_intfs[intf]["ipv6"] = ipv6

    def set_ssh(self):
        if self.ssh_status is None:
            return
        logging.info("Will set SSH: %s", self.ssh_status)
        if self.ssh_status:
            logging.info("Will set SSH")
            if self.ssh_public_key:
                try:
                    if not os.path.exists(ssh_dir):
                        logging.info("mkdir %s", ssh_dir)
                        os.mkdir(ssh_dir)
                        os.chmod(ssh_dir, stat.S_IRWXU)
                    os.chdir(ssh_dir)
                    with open("{dir}/authorized_keys".format(dir=ssh_dir), "a+") as fd:
                        fd.write(self.ssh_public_key)
                        if self.debug:
                            logging.info("ssh_public_key:\n{key}".format(key=self.ssh_public_key))
                except Exception:
                    self.handleErr("ssh configuration failed")
            commands.getstatusoutput("chown -R admin:admin {dir}".format(dir=ssh_dir))
            logging.info("enable SSH")
            ################################################
            cf_file = "/opt/confd/confdInstallDir/var/confd/cdb/confd_dyncfg_init.xml"
            tree = ET.parse(cf_file)
            node = tree.find("{*}*/{*}aaa/{*}sshPubkeyAuthentication")
            if node.text != "system":
                node.text = "system"
                with open(cf_file, "w") as fd:
                    fd.write(ET.tostring(tree.getroot()).decode())
            # cmd = r"/bin/bash -c '/opt/confd/confdSetInitialConfig.sh  [SSH=enabled]'"
            # logging.info("command:\n{cmd}".format(cmd=cmd))
            ################################################
            # if not self.debug:
            #     commands.getstatusoutput(cmd)
        else:
            logging.info("diable SSH")
            ################################################
            # cmd = r"/bin/bash -c '/opt/confd/confdSetInitialConfig.sh  [SSH=disabled]'"
            # logging.info("command:\n{cmd}".format(cmd=cmd))
            ################################################
            # if not self.debug:
            #     commands.getstatusoutput(cmd)

    def set_https_netconf_weui(self, namespace):
        key = self.doorbell_info.get('VNFC_NETCONF_IP_TRAFFIC_TYPE', '')
        oam_ip_v4 = self.traffic_info.get(key, {}).get('IPADDR', '')
        oam_ip_v6 = self.traffic_info.get(key, {}).get('IPV6ADDR', '').split('/')[0]

        _, ipv6info = commands.getstatusoutput("ip -6 a")

        if not (self.https_status or oam_ip_v4 or oam_ip_v6):
            return
        oam_ip_v4 = oam_ip_v4 or '127.0.0.1'
        if ipv6info:
            oam_ip_local = set(['127.0.0.1', '::1'])
        else:
            oam_ip_local = set(['127.0.0.1'])
        oam_ip_local = oam_ip_local - set([oam_ip_v4, oam_ip_v6])
        oam_ip_v6 = oam_ip_v6 or '::1'
        logging.info("Will set https_netconf_weui. https_status=({}), oam_ip_v4=({}), oam_ip_v6=({})".format(self.https_status, oam_ip_v4, oam_ip_v6))

        tree = ET.parse("/opt/confd/confdInstallDir/var/confd/cdb/confd_dyncfg_init.xml")
        conf_node = tree.find("{*}confdConfig")
        old_web_node = conf_node.find("{*}webui")
        netconf_ssh_node = conf_node.find("{*}netconf/{*}transport/{*}ssh")
        netconf_tcp_node = conf_node.find("{*}netconf/{*}transport/{*}tcp")

        with open("/opt/confd/utilities/webuiHttpsConfig.xml") as fd:
            buf = fd.read()
        root_web_node = ET.fromstring("<webui>" + buf + "</webui>")
        tcp_node = root_web_node.find("transport/tcp")
        ssl_node = root_web_node.find("transport/ssl")

        tcp_enable_node = root_web_node.find("transport/tcp/enabled")
        ssl_enable_node = root_web_node.find("transport/ssl/enabled")

        if self.https_status:
            logging.info("enable HTTPS.")
            ####################################
            tcp_enable_node.text = "false"
            ssl_enable_node.text = "true"
            # cmd = r"/bin/bash -c '/opt/confd/confdSetInitialConfig.sh  [HTTPS=enabled]'"
            # logging.info("command:\n{cmd}".format(cmd=cmd))
            ####################################
        else:
            logging.info("disable HTTPS.")
            ####################################
            tcp_enable_node.text = "true"
            ssl_enable_node.text = "false"
            # cmd = r"/bin/bash -c '/opt/confd/confdSetInitialConfig.sh  [HTTPS=disabled]'"
            # logging.info("command:\n{cmd}".format(cmd=cmd))
            ####################################

        tcp_ip_node = root_web_node.find("transport/tcp/ip")
        ssl_ip_node = root_web_node.find("transport/ssl/ip")
        netconf_ssh_ip_node = netconf_ssh_node.find('{*}ip')
        netconf_tcp_ip_node = netconf_tcp_node.find('{*}ip')

        # ipc_address_node = None
        # ipc_address_node = ET.fromstring('\n<confdIpcAddress>\n<ip>[{}]</ip>\n<port>4565</port>\n</confdIpcAddress>\n'.format(address1))
        # ipc_address_node = ET.fromstring('\n<confdIpcAddress>\n<ip>{}</ip>\n<port>4565</port>\n</confdIpcAddress>\n'.format(address1))
        node = ET.fromstring("<ip>{}</ip>".format(oam_ip_v4))
        if netconf_ssh_ip_node is not None:
            netconf_ssh_node.replace(netconf_ssh_ip_node, node.__copy__())
        else:
            netconf_ssh_node.append(node.__copy__())
        if netconf_tcp_ip_node is not None:
            netconf_tcp_node.replace(netconf_tcp_ip_node, node.__copy__())
        else:
            netconf_tcp_node.append(node.__copy__())
        if tcp_ip_node is not None:
            tcp_node.replace(tcp_ip_node, node.__copy__())
        else:
            tcp_node.append(node.__copy__())
        if ssl_ip_node is not None:
            ssl_node.replace(ssl_ip_node, node)
        else:
            ssl_node.append(node)

        tcp_extra_nodes = root_web_node.findall("transport/tcp/extraIpPorts")
        ssl_extra_nodes = root_web_node.findall("transport/ssl/extraIpPorts")
        netconf_ssh_extra_nodes = netconf_ssh_node.findall('{*}extraIpPorts')
        netconf_tcp_extra_nodes = netconf_tcp_node.findall('{*}extraIpPorts')
        for n in tcp_extra_nodes:
            tcp_node.remove(n)
        for n in ssl_extra_nodes:
            ssl_node.remove(n)

        for n in netconf_ssh_extra_nodes:
            netconf_ssh_node.remove(n)
        for n in netconf_tcp_extra_nodes:
            netconf_tcp_node.remove(n)

        if ipv6info:
            node = ET.fromstring("\n<extraIpPorts>[{}]</extraIpPorts>\n".format(oam_ip_v6))
            netconf_ssh_node.append(node.__copy__())
            netconf_tcp_node.append(node.__copy__())
            tcp_node.append(node.__copy__())
            ssl_node.append(node)

        for item in oam_ip_local:
            if ':' in item:
                node = ET.fromstring("\n<extraIpPorts>[{}]</extraIpPorts>\n".format(item))
            else:
                node = ET.fromstring("\n<extraIpPorts>{}</extraIpPorts>\n".format(item))
            netconf_ssh_node.append(node.__copy__())
            netconf_tcp_node.append(node.__copy__())
            tcp_node.append(node.__copy__())
            ssl_node.append(node)

        buf = ET.tostring(root_web_node).decode().replace("<webui>", "").replace("</webui>", "")
        with open("/opt/confd/utilities/webuiHttpsConfig.xml", "w") as fd:
            fd.write(buf)

        if old_web_node is not None:
            conf_node.replace(old_web_node, root_web_node)
        else:
            conf_node.insert(0, root_web_node)

        with open("/opt/confd/confdInstallDir/var/confd/cdb/confd_dyncfg_init.xml", "w") as fd:
            fd.write(ET.tostring(tree.getroot()).decode())
        tree = ET.parse("/opt/confd/confdInstallDir/etc/confd/confd.conf")
        conf_node = tree.getroot()
        ipc_node = conf_node.find('{*}confdIpcAddress')
        ipc_extr_node_list = conf_node.findall('{*}confdIpcExtraListenIp')
        new_ipc_node = ET.fromstring('''
                             <confdIpcAddress>
    <ip>127.0.0.1</ip>
    <port>4565</port>
</confdIpcAddress>''')
        if ipc_node is not None:
            conf_node.replace(ipc_node, new_ipc_node)
        else:
            conf_node.insert(0, new_ipc_node)
        for i in ipc_extr_node_list:
            conf_node.remove(i)
        if ipv6info and oam_ip_v6 != '::1':
            node = ET.fromstring('<confdIpcExtraListenIp>{}</confdIpcExtraListenIp>'.format(oam_ip_v6))
            conf_node.insert(1, node)
        if oam_ip_v4 != '127.0.0.1':
            node = ET.fromstring('<confdIpcExtraListenIp>{}</confdIpcExtraListenIp>'.format(oam_ip_v4))
            conf_node.insert(1, node)
        with open("/opt/confd/confdInstallDir/etc/confd/confd.conf", "w") as fd:
            fd.write(ET.tostring(tree.getroot()).decode())

        if not self.debug:
            # commands.getstatusoutput(cmd)
            # "vnfmIntf.https=True" for notifyMgr
            system_static_xml = glob.glob("/opt/confd/confdInstallDir/var/confd/cdb/*_system_static_config_data.xml")
            if not system_static_xml:
                self.handleErr("system static config xml is nonexistent")
            with open(system_static_xml[0]) as fd:
                content = fd.read()
                content = re.sub(r"<config\s+.*>", r"<config>", content)
                content = re.sub(r"<sys\s+.*>", r"<sys>", content)
            root = ET.fromstring(content)
            if self.https_status:
                node = root.find("*/*/vnfmIntf/https")
                if node is None:
                    self.handleErr("table vnfmIntf is not defined in system static config xml")
                node.text = "TRUE"
            result = ET.tostring(root).decode()
            result = re.sub(r'<config>', r'<config xmlns="http://tail-f.com/ns/config/1.0">', result)
            result = re.sub(r'<sys>', r'<sys xmlns="' + namespace + r'">', result)
            with open(system_static_xml[0], "w") as fd:
                fd.write(result)

    def set_ldap(self):
        if self.ldap_basedn and self.ldap_list:
            logging.info("Will set LDAP.")
            if self.ldap_cert:
                try:
                    TLS_CACERTDIR = ""
                    TLS_CACERT = ""
                    tls_cacertdir = ""
                    tls_cacertfile = ""
                    commands.getoutput(r"if ! grep -q '^[[:space:]]*bind_timelimit' {file}; then echo 'bind_timelimit 30' >> {file};fi".format(file=ldap_conf_nslcd))
                    commands.getoutput(r"if ! grep -q '^[[:space:]]*timelimit' {file}; then echo 'timelimit 30' >> {file};fi".format(file=ldap_conf_nslcd))
                    commands.getoutput(r"if ! grep -q '^[[:space:]]*idle_timelimit' {file}; then echo 'idle_timelimit 3600' >> {file};fi".format(file=ldap_conf_nslcd))
                    commands.getoutput(r"sed -i 's/^[[:space:]]*\(bind_timelimit\) .*/\1 30/' {file}".format(file=ldap_conf_nslcd))
                    commands.getoutput(r"sed -i 's/^[[:space:]]*\(timelimit\) .*/\1 30/' {file}".format(file=ldap_conf_nslcd))
                    commands.getoutput(r"sed -i 's/^[[:space:]]*\(idle_timelimit\) .*/\1 3600/' {file}".format(file=ldap_conf_nslcd))
                    with open(ldap_conf_ldap) as fd:
                        for line in fd:
                            if re.search(r"^\s*TLS_CACERTDIR", line):
                                TLS_CACERTDIR = line.split()[1]
                            elif re.search(r"^\s*TLS_CACERT", line):
                                TLS_CACERT = line.split()[1]
                    with open(ldap_conf_nslcd) as fd:
                        for line in fd:
                            if re.search(r"^\s*tls_cacertdir", line):
                                tls_cacertdir = line.split()[1]
                            elif re.search(r"^\s*tls_cacertfile", line):
                                tls_cacertfile = line.split()[1]
                    logging.info("\nTLS_CACERTDIR=%s, TLS_CACERT=%s\ntls_cacertdir=%s, tls_cacertfile=%s", TLS_CACERTDIR, TLS_CACERT, tls_cacertdir, tls_cacertfile)
                    if (not TLS_CACERTDIR) or TLS_CACERTDIR != tls_cacertdir or TLS_CACERT != tls_cacertfile:
                        self.handleErr("ca cert directory/file in {conf1} and {conf2} are different or undefined".format(
                            conf1=ldap_conf_ldap, conf2=ldap_conf_nslcd))
                    logging.info("write ca cert into ldap configuration files.")
                    if not os.path.exists(TLS_CACERTDIR):
                        os.mkdir(TLS_CACERTDIR)
                    if not self.debug:
                        if TLS_CACERT:
                            file_name = TLS_CACERT
                        else:
                            file_name = "{dir}/CA_cert.pem".format(dir=TLS_CACERTDIR)
                        with open(file_name, "w") as fd:
                            logging.info(file_name)
                            fd.write(self.ldap_cert)
                except Exception:
                    self.handleErr("set ldap failed")

            cmd = '''authconfig --disablesssd --disablesssdauth --enableldap --enableldapauth \
    --ldapserver={0} --ldapbasedn="{1}" --enablemkhomedir --update'''.format(','.join(self.ldap_list), self.ldap_basedn)
            logging.info("command:\n{cmd}".format(cmd=cmd))
            if not self.debug:
                status, out = commands.getstatusoutput(cmd)
                logging.info("status: %s\nout:\n%s", status, out)
                if status != 0:
                    self.handleErr("authconfig failed")
            #############################################
            # cmd = r"/bin/bash -c '/opt/confd/confdSetInitialConfig.sh  [LDAP=enabled]'"
            # logging.info("command:\n{cmd}".format(cmd=cmd))
            #############################################
            if not self.debug:
                commands.getstatusoutput("service nslcd restart")

    def dict2XmlNodes(self, data):
        '''
        Convert Dict or JSON to xml node(s):
            If the Dict object only has only one top entry, like:
                {"e1":{...}}
            It will return a list with only one xml node.
            If the Dict object has more than one entries, like:
                {"e1":{...}, "e2":{...},...}
            It will return a list containing more xml nodes.

        :param data: a Dict or JSON object
        :return: the xml nodes' list
        '''
        nodeList = []

        def _insert(node, childList):
            for child in childList:
                node.appendChild(child)
            nodeList.append(node)

        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, list):
                    for e in v:
                        _insert(self.doc.createElement(k), self.dict2XmlNodes(e))
                    continue

                if isinstance(v, dict):
                    childList = self.dict2XmlNodes(v)
                else:
                    childList = [self.doc.createTextNode(unicodeStr(v))]
                _insert(self.doc.createElement(k), childList)
        elif isinstance(data, tuple):
            for k, v in data:
                _insert(self.doc.createElement(k), [self.doc.createTextNode(unicodeStr(v))])
        return nodeList

    def insertXmlNodes(self, parent, childrens):
        '''
        insert some XML nodes in parent.

        :param parent: the parent node of all childrens nodes.
        :param childrens: a list with XML nodes
        :return: None
        '''
        if isinstance(parent, dom.Element):
            for child in childrens:
                parent.appendChild(child)

    def generate_network_xml(self, namespace, xml_file):
        sys_tbls = {'sm': ['vipPool', 'callHome', 'smCluster', 'peerConfd', 'configMgr'],
                    'fpath': ['dpPhysicalPort', 'dpBond', 'dpVlanConfig'],
                    'platform': ['ext_ip',
                                 'ext_ip_intf',
                                 'tunnelMap',
                                 'vipProfile',
                                 'vnf',
                                 'sdns',
                                 'vnfmAddr',
                                 'ext_rule',
                                 'smAgent',
                                 'doorbell',
                                 'ext_dynamic_route',
                                 'ext_dynamic_route_ProtGrp_map',
                                 'plat_features']
                    }

        def _create_sys(sys_tbls):
            top_info = {}
            tbls = {}
            for k, v in sys_tbls.items():
                top_info[k] = ({k: {}}, {i: list() for i in v})
                tbls.update(top_info[k][1])
            return top_info, tbls

        top_info, tbls = _create_sys(sys_tbls)

        #########################################################################
        rule_index = 1
        ext_dynamic_route_id = 0
        tunnelMap_index = 1
        config = self.doc.createElement("config")
        sys = self.doc.createElement("sys")

        config.appendChild(sys)

        # for plat_features
        if self.vdu.get('PROGRAM_SECURITY', False):
            tbls['plat_features'].append((('name', 'PROGRAM_SECURITY'), ('enabled', 'TRUE')))

        if self.isInContainer():
            tbls['plat_features'].append((('name', 'CONTAINER'), ('enabled', 'TRUE')))

        if self.aws_region:
            tbls['plat_features'].append((('name', 'AWS'), ('enabled', 'TRUE')))

        if self.sdns_auth:
            tbls['peerConfd'].append(self.sdns_auth)
        if 'ENABLECDR' in self.vdu:
            tbls['configMgr'].append((('name', 'configMgr'), ('enableCDR', str(self.vdu.get('ENABLECDR')).upper())))
        # for vipPool
        # isV6 = False
        for key, value in self.net_pools.items():
            id = 0
            for v in value:
                ip, size = v, 1
                if '%' in v:
                    ip, size = v.split('%')
                inst = (('id', '{0}-{1}'.format(key, id)), ('VirtualLink', key), ('PoolIP', ip), ('PoolSize', size))
                tbls['vipPool'].append(inst)
                id += 1
                # ipaddr = ip_util.ip_address(unicodeStr(ip))
                # if not isinstance(ipaddr, ip_util.IPv4Address): isV6 = True
            # sm.setdefault('vipPool', vipPool)

        # for vipProfile and pipProfile
        # in the case serveral traffic types share one physical interface, and there is PIP defined for this interface
        # we only allow one PIP configured into vipProfile table, or there would be causing each traffic type occupy one physical IP
        # we use a simple dict to remove duplicate
        pipConfigured = {}
        for key, value in self.traffic_info.items():
            vlan = value.get('VLAN', None)
            if 'IFNAME' in value and ('VIRTUAL_LINK_ID' in value or 'PIP_VIRTUAL_LINK_ID' in value):
                intf = value.get('IFNAME')
                # if user_data define some non-existed eth, skip it
                # if 'fp' not in intf and intf not in self.pod_intf_data:
                #     logging.info(intf + " not exist ")
                #     continue
                # if 'fpeth' in intf and 'IFMAP' in value:
                #     intf = value['IFMAP']

                mask = 0
                if 'IPV6ADDR' in value or 'IPV6_DEFAULTGW' in value:
                    mask = (value.get('IPV6ADDR', '0').split('/')+[''])[1]
                    mask = mask or value.get('PREFIX', 128)
                elif 'PREFIX' in value:
                    mask = value.get('PREFIX', 32)

                if 'VIRTUAL_LINK_ID' in value and value.get('VIRTUAL_IP_REQUIRED', False):
                    vlink = value.get('VIRTUAL_LINK_ID')
                    tbls['vipProfile'].append((
                        ('trafficType', key),
                        ('virtualLink', vlink),
                        ('interface', '{0}.{1}'.format(intf, vlan) if vlan else intf),
                        ('maskSize', mask)))

                if 'PIP_VIRTUAL_LINK_ID' in value:
                    plink = value.get('PIP_VIRTUAL_LINK_ID')
                    if pipConfigured.get(plink, '') != key:
                        tbls['vipProfile'].append((
                            ('trafficType', key + '-static'),
                            ('virtualLink', plink),
                            ('ip_config_type', 'EXT_IP_PHYSICAL'),
                            ('interface', '{0}.{1}'.format(intf, vlan) if vlan else intf),
                            ('maskSize', mask)))
                        pipConfigured[plink] = key

        # for sm_enabled
        if self.vdu.pop("SM_ENABLED", False):
            tbls['smAgent'].append((('id', 0), ('enabled', 'TRUE')))

        # doorbell
        if self.doorbell_info:
            vnfmAddr_info = {}
            if "VNFM_IP_ADDRESSES" in self.doorbell_info:
                vnfmAddr_info["IpPortList"] = self.doorbell_info.pop("VNFM_IP_ADDRESSES", [])
            if "VNFM_FQDN" in self.doorbell_info:
                vnfmAddr_info["FQDN"] = self.doorbell_info.pop("VNFM_FQDN", None)
            if "VNFM_PORT" in self.doorbell_info:
                vnfmAddr_info["PORT"] = self.doorbell_info.pop("VNFM_PORT", None)
            if "VNFM_TTL" in self.doorbell_info:
                vnfmAddr_info["TTL"] = self.doorbell_info.pop("VNFM_TTL", None)
            # vnfmAddr

            if vnfmAddr_info:
                tbls['vnfmAddr'].append((('name', "Name1"),
                                         ('IpPortList', ", ".join(str(x) for x in vnfmAddr_info.get("IpPortList", ""))),
                                         ('fqdn', vnfmAddr_info.get("FQDN", "")),
                                         ('port', vnfmAddr_info.get("PORT", "")),
                                         ('ttl', vnfmAddr_info.get("TTL", "60"))))

            # for table vnfc
            if 'VNF_ID' in self.doorbell_info:
                tbl = [('systemId', self.doorbell_info.get('SYSTEM_ID')),
                       ('lvnId', self.doorbell_info.get('VNF_ID'))]
                if 'VNFC_INSTANCE_ID' in self.doorbell_info:
                    tbl.append(('vnfcInstanceId', self.doorbell_info.get('VNFC_INSTANCE_ID')))
                if 'VNF_TYPE' in self.doorbell_info:
                    tbl.append(('vnfType', self.doorbell_info.get('VNF_TYPE')))
                if 'NSD_ID' in self.doorbell_info:
                    tbl.append(('nsId', self.doorbell_info.get('NSD_ID')))
                if 'NSD_VERSION' in self.doorbell_info:
                    tbl.append(('nsVersion', self.doorbell_info.get('NSD_VERSION')))
                if 'VNFC_NETCONF_IP_TRAFFIC_TYPE' in self.doorbell_info:
                    tbl.append(('netconfIPAddress', self.doorbell_info.get('VNFC_NETCONF_IP_TRAFFIC_TYPE') + '-static'))
                tbl += [('vnfmLCMIPAddress', '127.0.0.1'),
                        ('vnfmLCMPort', '9090'),
                        ('vnfmLCMEventURI', '/vnfm/event'),
                        ('vnfmMonitorIPAddress', '127.0.0.1'),
                        ('vnfmMonitorPort', '9090'),
                        ('smnfId', self.doorbell_info.get('SM_NF_ID', '')),
                        ('smns', self.doorbell_info.get('SM_NAMESPACE', '')),
                        ('vnfmMonitorURI', '/vnfm/monitor')]
                tbls['vnf'].append(tuple(tbl))

            # for table smCluster
            tbl = []
            sm_adv = ''

            def _check_aiptt(aiptt):
                adv_traffics = [key for key in self.traffic_info.keys() if aiptt in key]
                if aiptt in adv_traffics:
                    return aiptt
                if len(adv_traffics) == 1:
                    return adv_traffics[0]
                self.handleErr('Can not set smCluster. There is no taffrictType named "{0}"'.format(aiptt))

            if 'SM_ADVERTISED_IP_TRAFFIC_TYPE' in self.doorbell_info:
                sm_adv = _check_aiptt(self.doorbell_info.get("SM_ADVERTISED_IP_TRAFFIC_TYPE"))
                tbl.append(('advertiseIP', '{0}-static'.format(sm_adv)))
            if 'SM_CLUSTER_SIZE' in self.doorbell_info:
                if not sm_adv:
                    sm_adv = _check_aiptt('OAM')
                    tbl.append(('advertiseIP', '{0}-static'.format(sm_adv)))
                tbl.append(('size', self.doorbell_info.get("SM_CLUSTER_SIZE")))
            if tbl:
                tbl.insert(0, ('name', 'smclusterconfig'))
                tbl.append(('simplex', str(self.vdu.get('SIMPLEX', False)).upper()))
                tbls['smCluster'].append(tuple(tbl))

            # for table sdns
            if self.doorbell_info.get("SDNS_IP_PORTS", []):
                for ip, port in zip(self.doorbell_info.get("SDNS_IP_ADDRESSES", []), self.doorbell_info.get("SDNS_IP_PORTS", [])):
                    tbls['sdns'].append((('ipAddr', ip), ('port', port)))
            else:
                for ip in self.doorbell_info.get("SDNS_IP_ADDRESSES", []):
                    tbls['sdns'].append((('ipAddr', ip),))

            # for table callHome
            if self.doorbell_info.get("CMS_IP_PORTS", []):
                for ip, port in zip(self.doorbell_info.get("CMS_IP_ADDRESSES", []), self.doorbell_info.get("CMS_IP_PORTS", [])):
                    tbls['callHome'].append((('ipAddr', ip), ('port', port)))
            else:
                for ip in self.doorbell_info.get("CMS_IP_ADDRESSES", []):
                    tbls['callHome'].append((('ipAddr', ip),))

            _doorbell = []
            if self.doorbell_info.get("SYSTEM_ID"):
                _doorbell.append(('systemId', self.doorbell_info.get("SYSTEM_ID")))
            if self.doorbell_info.get("VNFM_URI"):
                _doorbell.append(('vnfmURI', self.doorbell_info.get("VNFM_URI")))
            if self.doorbell_info.get("CLOUD_PROFILE_ID"):
                _doorbell.append(('cloudProfId', self.doorbell_info.get("CLOUD_PROFILE_ID")))
            if self.doorbell_info.get("VNFD_ID"):
                _doorbell.append(('vnfdId', self.doorbell_info.get("VNFD_ID")))
            if self.doorbell_info.get("VNFD_VERSION"):
                _doorbell.append(('vnfdVer', self.doorbell_info.get("VNFD_VERSION")))
            if self.doorbell_info.get("VDU_NAME"):
                _doorbell.append(('vduName', self.doorbell_info.get("VDU_NAME")))
            if self.doorbell_info.get("NSD_ID"):
                _doorbell.append(('nsId', self.doorbell_info.get("NSD_ID")))
            if self.doorbell_info.get("NSD_VERSION"):
                _doorbell.append(('nsdVer', self.doorbell_info.get("NSD_VERSION")))
            if self.doorbell_info.get("META_DATA"):
                _doorbell.append(('metaData', self.doorbell_info.get("META_DATA")))
            if self.doorbell_info.get("VNFM_IP_ADDRESS1"):
                _doorbell.append(('vnfmIPAddress1', self.doorbell_info.get("VNFM_IP_ADDRESS1")))
            if self.doorbell_info.get("VNFM_PORT1"):
                _doorbell.append(('vnfmPort1', self.doorbell_info.get("VNFM_PORT1")))
            if self.doorbell_info.get("VNFM_IP_ADDRESS2"):
                _doorbell.append(('vnfmIPAddress2', self.doorbell_info.get("VNFM_IP_ADDRESS2")))
            if self.doorbell_info.get("VNFM_PORT2"):
                _doorbell.append(('vnfmPort2', self.doorbell_info.get("VNFM_PORT2")))
            if self.doorbell_info.get("CMS_IP_ADDRESS1"):
                _doorbell.append(('cmsIPAddress1', self.doorbell_info.get("CMS_IP_ADDRESS1")))
            if self.doorbell_info.get("CMS_PORT1"):
                _doorbell.append(('cmsPort1', self.doorbell_info.get("CMS_PORT1")))
            if self.doorbell_info.get("CMS_IP_ADDRESS2"):
                _doorbell.append(('cmsIPAddress2', self.doorbell_info.get("CMS_IP_ADDRESS2")))
            if self.doorbell_info.get("CMS_PORT2"):
                _doorbell.append(('cmsPort2', self.doorbell_info.get("CMS_PORT2")))

            if _doorbell:
                tbls['doorbell'].append(tuple(_doorbell))

        # IPs
        for intf, data in self.intf_data.items():
            # if 'fpeth' in intf and 'IFMAP' in self.traffic_info[data['TRAFFIC'].keys()[0]] and 'fpeth' in self.traffic_info[data['TRAFFIC'].keys()[0]]['IFMAP']:
            #     intf = self.traffic_info[data['TRAFFIC'].keys()[0]]['IFMAP']
            for vlan in data.get('VLAN', set()):
                tbls['ext_ip_intf'].append((('intf', '{0}.{1}'.format(intf, vlan)),))
                tbls['dpVlanConfig'].append((('name', vlan),
                                            ('compType', 'AM'),
                                            ('vlanTag', vlan),
                                            ('fkPhysicalPort', intf.replace('fp', '')),
                                            ))
            else:
                tbls['ext_ip_intf'].append((('intf', intf),))

            def _createDpPhysicalPort(intf):
                arr = [('name', intf.replace('fp', '')),
                       ('compType', 'AM'),
                       ('isInFastPath', str(intf.startswith('fp')).upper()),
                       ('speed', data.get('SPEED', 1000)),
                       ('mtu', data.get('MTU', None) or 1500)]
                if data.get('PORTTYPE', None):
                    arr.append(('type', data.get('PORTTYPE')))
                tbls['dpPhysicalPort'].append(tuple(arr))
            if 'fp' in intf:
                _createDpPhysicalPort(intf)
            if 'BondEthernet' in intf or "fpbond" in intf:
                option = {x.split('=')[0]: x.split('=')[1] for x in data.get('OPTS', '').split()}
                miimon = option.pop('miimon', 100)
                if option.get('lacpRate', '-') in '01':
                    lacpRate = option.pop('lacpRate')
                else:
                    lacpRate = 1 if 'fast' == option.pop('lacpRate', '') else 0

                slaves = set(map(lambda x: x.strip(), data.get('SUBPORT').split(','))) - set([''])
                slaves = list(slaves)
                if str(option.get('mode', '-')) in '0123456':
                    mode = option.pop('mode')
                else:
                    mode = 'BOND_MODE_' + option.pop('mode', 'balance-rr').replace('-', '_').upper()
                if str(option.get('xmit_hash_polic', '-')) in '01234':
                    xmitHash = option.pop('xmit_hash_polic')
                else:
                    _xmit_hash_polic_str = '_'.join(map(lambda x: x[:-1] + '_' + x[-1] if x[0].isalpha() else x, option.pop('xmit_hash_polic', 'layer2').upper().split('+')))
                    xmitHash = 'XMIT_HASH_P_' + _xmit_hash_polic_str
                failOverMac = option.pop('fail_over_mac', 'FAIL_OVER_MAC_ACTIVE')
                if failOverMac == 'none' or failOverMac == '0':
                    failOverMac = 'FAIL_OVER_MAC_NONE'
                if failOverMac == 'active' or failOverMac == '1':
                    failOverMac = 'FAIL_OVER_MAC_ACTIVE'
                if failOverMac == 'follow' or failOverMac == '2':
                    failOverMac = 'FAIL_OVER_MAC_FOLLOW'
                if failOverMac == 'max' or failOverMac == '3':
                    failOverMac = 'FAIL_OVER_MAC_MAX'
                arpInterval = option.pop('arp_interval', 800)
                arpIPtarget = option.pop('arp_ip_target', '')
                customOptions = ' '.join(['{0}={1}'.format(k, v) for k, v in option.items()])
                entry = [('name', intf),
                         ('fkBondName', intf.replace('fp', '')),
                         ('bondMode', mode),
                         ('miimon', miimon),
                         ('xmitHash', xmitHash),
                         ('failOverMac', failOverMac),
                         ('arpInterval', arpInterval),
                         ('arpIPtarget', arpIPtarget),
                         ('customOptions', customOptions),
                         ('lacpRate', lacpRate)]
                for i, s in enumerate(slaves):
                    _createDpPhysicalPort(s)
                    field_prefix = 'fkSlave'
                    cmd = r'egrep "^\s+leaf fkSlave[0-9]+ {\s*$" /usr/IMS/current/yangFiles/*.yang'
                    stat, _ = commands.getstatusoutput(cmd)
                    if stat:
                        field_prefix = 'fkSubPort'
                    entry.append(("{0}{1}".format(field_prefix, i), s.replace('fp', '')))
                tbls['dpBond'].append(tuple(entry))

            for traffic, traffic_value in data["TRAFFIC"].items():
                defaultgw = traffic_value.get("DEFAULTGW")
                traffic_gw = traffic_value.get("GATEWAY")
                if self.dhcp_intfs.get(intf):
                    for entry in self.dhcp_intfs.get(intf).values():
                        if entry:
                            traffic_value["IPS"].add("{ip_prefix}/".format(ip_prefix=entry))
                # tunnelMap
                if traffic_value.get("RE"):
                    fe_res = traffic_value["RE"] - set([None, ''])
                    if fe_res:
                        # disbale re_filter and enable ip forwarding
                        commands.getoutput("echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter")
                        commands.getoutput("echo 0 > /proc/sys/net/ipv4/conf/default/rp_filter")
                        # commands.getoutput("echo 1 > /proc/sys/net/ipv4/ip_forward")
                        # commands.getoutput("echo 1 > /proc/sys/net/ipv6/conf/all/forwarding")
                        for fe_re in fe_res:
                            tbls['tunnelMap'].append((('mapName', 'Map{0}'.format(tunnelMap_index)),
                                                      ('local_traffic_type', traffic),
                                                      ('remote_traffic_type', fe_re)))
                            tunnelMap_index += 1
                # add ext_ip
                ip_sum = len([i for i in traffic_value["IPS"] - set([None, '']) if not i.startswith('None')])
                for ip_prefix_gw in traffic_value["IPS"]:
                    traffic_name = "{name}".format(name=traffic)
                    if ip_prefix_gw:
                        ip, prefix, gw = ip_prefix_gw.split(r"/")
                        # prefix_r = '32'
                        if ip != 'None':
                            ipaddr = ip_util.ip_address(unicodeStr(ip))
                            if ip_sum == 2:
                                if isinstance(ipaddr, ip_util.IPv6Address):
                                    traffic_name = "{name}-v6".format(name=traffic)
                                    # prefix_r = '128'
                            ext_ip_intf = intf
                            if 'VLAN' in self.traffic_info[traffic]:
                                ext_ip_intf = '{}.{}'.format(intf, self.traffic_info[traffic].get('VLAN'))

                            tbls['ext_ip'].append((('name', traffic_name + "-static"),
                                                   ('ip_addr', ip),
                                                   ('maskSize', prefix),
                                                   ('fk_ext_ip_intf', ext_ip_intf),
                                                   ('ip_config_type', 'EXT_IP_PHYSICAL'),
                                                   ('fkprot_grp', 'ADM'),
                                                   ('fkcomponent', 'ADM-a')))

                        # ext_rule
                        defaultgw = traffic_value.get("DEFAULTGW")
                        traffic_gw = traffic_value.get("GATEWAY", None)
                        if defaultgw != "yes" and traffic_gw and gw != "None":
                            timeStamp = time.time()
                            rulename = "rule" + str(rule_index)
                            if traffic_name in self.traffic_info and 'VIRTUAL_IP_REQUIRED' in self.traffic_info[traffic_name] and self.traffic_info[traffic_name]['VIRTUAL_IP_REQUIRED'] is False:
                                traffic_name = traffic_name + '-static'
                            tbls['ext_rule'].append((('ruleName', rulename),
                                                     ('fkext_ip', traffic_name),
                                                     ('maskSize', prefix),
                                                     ('table_id', rule_index),
                                                     ('timeStamp', timeStamp)))

                            # ext_dynamic_route
                            desc = r'0.0.0.0'
                            if ':' in gw:
                                desc = r'::0'
                            tbls['ext_dynamic_route'].append((('id', ext_dynamic_route_id), ('destination', desc), ('maskSize', 0), ('gateway', gw), ('interface', intf), ('fkext_rule', rulename)))

                            # ext_dynamic_route_ProtGrp_map
                            tbls['ext_dynamic_route_ProtGrp_map'].append((('id', ext_dynamic_route_id), ('fkext_dynamic_route', ext_dynamic_route_id), ('fkprot_grp', 'ADM'), ('timeStamp', timeStamp)))

                            ext_dynamic_route_id += 1
                            rule_index += 1

        # for On-Demand VIP
        # for traffic, info in self.traffic_info.items():
        #    vipadds = [('V4', info.get('VIPADDR', None)), ('V6', info.get('VIPV6ADDR', None))]
        #    vip_name = traffic
        #    for vip_type, vip_value in vipadds:
        #        if vip_value:
        #            if vip_type == 'V4':
        #                ip = vip_value
        #                prefix = max(info.get('PREFIX', 0), self.vcloud_info[info['IFNAME']][vip_type][2])
        #            else:
        #                ip, prefix = vip_value.split('/')
        #                prefix = max(int(prefix), self.vcloud_info[info['IFNAME']][vip_type][2])
        #            if ip and prefix:
        #                tbls['ext_ip'].append((('name', vip_name),
        #                               ('ip_addr', ip),
        #                               ('maskSize', prefix),
        #                               ('fk_ext_ip_intf', info['IFNAME']),
        #                               ('ip_config_type', 'EXT_IP_VIRTUAL'),
        #                               ('fkprot_grp', 'ADM'),
        #                               ('fkcomponent', 'ADM-a')))
        #            vip_name = '{0}-v6'.format(traffic)

        ############################################################
        for name, (top, tbls) in top_info.items():
            for key, value in tbls.items():
                if value:
                    top[name].setdefault(key, value)
            if top[name]:
                self.insertXmlNodes(sys, self.dict2XmlNodes(top))

        result = config.toprettyxml()
        result = re.sub(r'<config>', r'<config xmlns="http://tail-f.com/ns/config/1.0">', result)
        result = re.sub(r'<sys>', r'<sys xmlns="' + namespace + r'">', result)
        repl = lambda x: ">%s</" % x.group(1).strip() if len(x.group(1).strip()) != 0 else x.group(0)
        result = re.sub(r'>\n\s*([^<]+)</', repl, result)

        logging.info("XML :\n%s", result)
        if not self.debug:
            with open(xml_file, "w") as fd:
                fd.write(result)

    def marshal_interfaces(self):
        pci_order = ['00:00.0'] * 31
        fpIdx = -1

        for trfc, value in self.traffic_info.items():
            if 'vRouter' == value['TYPE']:
                continue
            if 'bond' == value['TYPE']:
                intfs = (value.get('SUBPORT', value.get('SLAVE', '')) or '').split(',')
            else:
                intfs = value['IFNAME'].split(',')
            for intf in intfs:
                if 'fpeth' in intf:
                    fpIdx = int(intf[5:])
                    # use the PCI ID from the virtIO
                    if 'HOSTDEV' in value:
                        virioEthName = '/sys/class/net/' + value['HOSTDEV']
                        logging.info('%s:%s need to put into pci-order at index %d, virtio PCI %s', trfc, intf, fpIdx, virioEthName)
                        if os.path.exists(virioEthName) and os.path.islink(virioEthName):
                            link = os.readlink(virioEthName)
                            if '0000:' in link:
                                info = link.split('/')
                                for item in info:
                                    if re.search('[0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F]+:+[0-9a-fA-F][0-9a-fA-F]+:+[0-9a-fA-F][0-9a-fA-F]+.+[0-9a-fA-F]', item):
                                        pciId = item[5:]
                                        pci_order[fpIdx] = pciId
                            else:
                                logging.ERROR("no valid PCI link found")
                        else:
                            logging.ERROR("pci device does not exist in system")
                    # use the PCI ID pre-defined in the env
                    elif os.system('env | grep -i fpeth') == 0:
                        envoutput = commands.getoutput('env | grep -i fpeth').split('\n')
                        for line in envoutput:
                            fpethName, pciName = line.split('=')
                            if not fpethName or not pciName:
                                logging.ERROR("invliad fpeth ENV")
                            if 'fpeth' in fpethName:
                                fpIdx = int(fpethName.strip()[5:])
                                cmd = 'env | grep -i ' + pciName.strip() + ' | grep -v -i fpeth'
                                if os.system(cmd) == 0:
                                    envoutput = commands.getoutput(cmd).split('\n')
                                    if len(envoutput) == 1:
                                        fpname, pciId = envoutput[0].split('=')
                                        pciIdStrip = pciId.strip()[5:]
                                        pci_order[fpIdx] = pciIdStrip
                                        logging.info('read PCI ID from pre-defined ENV  %s at index %d', pciIdStrip, fpIdx)
                                    else:
                                        logging.ERROR("duplicate PCI ID for " + fpethName)
                                else:
                                    logging.ERROR("cannot find PCI ID for " + fpethName)
                            else:
                                logging.ERROR("invliad fpeth name")
                    # use the PCI ID from the mount dir /var/lib/cni/sriov
                    else:
                        try:
                            cmd = r"awk '/hostname /{print$4}' /proc/1/task/1/mountinfo | awk -F/ '{i=1; while(i<=NF){if(length($i)>40){print$i};i++} }'"
                            status, containerID = commands.getstatusoutput(cmd)                            
                            if status != 0 or containerID is None:
                                raise Exception("cannot read container ID from mountinfo")
                            else:
                                found_PCI = False
                                cmdStr_eth = "cat /var/lib/cni/sriov/%s-eth%d" % (containerID, fpIdx)
                                status_eth, sriovStr_eth = commands.getstatusoutput(cmdStr_eth)
                                if status_eth != 0 or sriovStr_eth is None or 'deviceID' not in sriovStr_eth:
                                    raise Exception("cannot read PCI ID from sriov eth config")
                                else:
                                    found_PCI = True
                                    sriovInfo = json.loads(sriovStr_eth)
                                    # pci_order[fpIdx] = sriovInfo['deviceID'][5:].encode('raw_unicode_escape')
                                    pci_order[fpIdx] =  unicodeStr(sriovInfo['deviceID'][5:])
                                    logging.info('read PCI ID from sriov info %s need to put into pci-order at index %d', cmdStr_eth, fpIdx)

                                if found_PCI is False:
                                    cmdStr_fpeth = "cat /var/lib/cni/sriov/%s-fpeth%d" % (containerID, fpIdx)
                                    status_fpeth, sriovStr_fpeth = commands.getstatusoutput(cmdStr_fpeth)
                                    if status_fpeth != 0 or sriovStr_fpeth is None or 'deviceID' not in sriovStr_fpeth:
                                        raise Exception("cannot read PCI ID from sriov fpeth config")
                                    else:
                                        found_PCI = True
                                        sriovInfo = json.loads(sriovStr_fpeth)
                                        # pci_order[fpIdx] = sriovInfo['deviceID'][5:].encode('raw_unicode_escape')
                                        pci_order[fpIdx] = unicodeStr(sriovInfo['deviceID'][5:])
                                        logging.info('read PCI ID from sriov info %s need to put into pci-order at index %d', cmdStr_fpeth, fpIdx)
                                self.vcloud_info["fpeth{}".format(fpIdx)] = {"V4": ['', '', 0, ''], "V6": ['', '', 0, ''], "MTU": 1500, "MAC": [{}]}

                        except Exception as e:
                            logging.info(" error happened when reading PCI from sriov config: %s", e.message)
                            pass

        logging.info("generate eth-pci-order file, %s", pci_order)
        with open("/etc/sysconfig/eth-pci-order", "w") as fd:
            for pciID in pci_order:
                fd.write(str(pciID) + "\n")

    def sort_interfaces(self, env=None):
        """
            for the VM the links under /sys/class/net/ are
            ../../devices/virtual/net/eth0->../../devices/pci0000:00/0000:00:03.0/virtio0/net/eth0
            so we can read the virtio PCI number

            for container, there is no virtio, the links are
            eth0 -> ../../devices/virtual/net/eth0
            no PCI number, no need to sort here, we just return the ethX's X value

            sort the interfaces basing on the MAC order defind in network-data or ovfEnv
            and for vmware vm, it will return a old-new interface map.
            generate the eth-pci-order file for fastpath
        Args:
            env: a ET.Element object fro ovfEnv
        Returns:
            a list for old-new interface map like:
                [3, 0, 1, 2]

        """
        intf_map = []
        # for openStak
        mac_list = []
        # for container
        c_intf_list = {}

        if self.isInContainer():
            sysdir = '/sys/class/net/'
            intfs = os.listdir(sysdir)
            for intf in intfs:
                if os.path.islink(sysdir + intf):
                    link = os.readlink(sysdir + intf)
                    info = link.split('/')
                    for item in info:
                        if re.search(r'eth+\d', item):
                            c_intf_list[item] = item[3:]
                            break
            return range(len(c_intf_list))

        if platform == "vmware":
            try:
                nic_nodes = env.find('{*}EthernetAdapterSection').getchildren()
                mac_list = [e.items()[0][1] for e in nic_nodes]
            except Exception:
                pass
            intf_map = list(range(len(mac_list)))
        else:
            if os.path.exists(network_data_file):
                with open(network_data_file) as fd:
                    network_data = json.load(fd)
                if network_data:
                    mac_list = [v.get("ethernet_mac_address") for v in network_data.get("links")]
        if mac_list:
            interface_list = os.listdir("/sys/class/net/")
            for i, mac in enumerate(mac_list):
                for j, intf in enumerate(interface_list):
                    if "bond" in intf:
                        continue
                    with open("/sys/class/net/{intf}/address".format(intf=intf)) as fd:
                        new_name = "eth{i}".format(i=i)
                        if mac in fd.read() and intf != new_name:
                            if new_name in interface_list:
                                cmd = "ip link set dev {old} down; ip link set dev {new} down; ip link set dev {new} name {new}_9; ip link set dev {old} name {new}; ip link set dev {new}_9 name {old}; ip link set dev {old} up; ip link set dev {new} up;".format(old=intf, new=new_name)
                            else:
                                cmd = "ip link set dev {old} down; ip link set dev {old} name {new}; ip link set dev {new} up".format(old=intf, new=new_name)
                            logging.info(cmd)
                            os.system(cmd)
            for i, mac in enumerate(mac_list):
                os.system("ip addr flush dev eth{i}".format(i=i))
        else:
            # if mac_list is None, re-name the interfacs base on the original order. the prefix of the new name should be "eth"
            intfs_dict = {}
            sysdir = '/sys/class/net/'
            intfs = os.listdir(sysdir)
            for intf in intfs:
                if os.path.islink(sysdir + intf):
                    link = os.readlink(sysdir + intf)
                    if '0000:' in link:
                        info = link.split('/')
                        for item in info[::-1]:
                            if re.search(r'\d+:\d+:\d+\.\d+', item):
                                intfs_dict[item] = info[-1]
                                break
            pci_sorted = sorted(intfs_dict)
            logging.info(pci_sorted)
            with open("/etc/sysconfig/eth-pci-order", "w") as fd:
                new_index = 0
                for pci in pci_sorted:
                    old = intfs_dict.get(pci)
                    new = 'eth' + str(new_index)
                    cmd = "ip link set dev {old} down; ip link set dev {old} name {new}; ip link set dev {new} up".format(old=old, new=new)
                    # logging.info(cmd)

                    # comment this out for container, the container get the default gateway "169.254.1.1"
                    # the default route is set by calico, this command would earse the default route
                    # and it is not needed by container, so remove it for now
                    # os.system(cmd)

                    new_index += 1
                    fd.write(pci + "\n")
                intf_map = range(len(pci_sorted))
                logging.info(intf_map)
            return intf_map
        # generate eth-pci-order file
        logging.info("generate eth-pci-order file.")
        # new_interface_list = os.listdir("/sys/class/net/")
        with open("/etc/sysconfig/eth-pci-order", "w") as fd:
            for i in range(len(mac_list)):
                out = commands.getoutput("ethtool -i eth{i}".format(i=i))
                pci_info = re.search(r"bus-info:\s+(.*)", out).group(1).replace("0000:", "")
                fd.write(pci_info + "\n")

        logging.info("sort interfaces done.")
        return intf_map

    def set_dns(self):
        content = ""
        # with open(r"resolv.conf") as fd:
        if os.path.exists(r"/etc/resolv.conf.default"):
            fd = open(r"/etc/resolv.conf.default")
            logging.info("/etc/resolv.conf.default")
        else:
            fd = open(r"/etc/resolv.conf")
            logging.info("/etc/resolv.conf")
        for line in fd:
            logging.info("\t %s", line)
            tmp = line.split()
            if "nameserver" in line and len(tmp) == 2 and tmp[1] not in self.dns_info["server"]:
                self.dns_info["server"].append(tmp[1])
            elif "search" in line and line not in self.dns_info["search"]:
                self.dns_info["search"].append(line)
        fd.close()
        for entry in self.dns_info["search"]:
            content += entry
        for entry in self.dns_info["server"]:
            if entry:
                content += "nameserver {entry}\n".format(entry=entry)

        logging.info("DNS resolv.conf:\n%s", content)
        if os.path.exists(r"/etc/resolv.conf.default"):
            os.remove(r"/etc/resolv.conf.default")
        if not self.debug:
            with open(r"/etc/resolv.conf", "w") as fd:
                fd.write(content)

    def _decode(self, text, prefix=''):
        if not text:
            return text
        mavcrypt = r'{0}/../bin/mavcrypt'.format(script_dir)
        if not os.path.exists(mavcrypt):
            self.handleErr('mavcrypt does not exist.')
        if prefix:
            text = text[len(prefix):]
        status, res = commands.getstatusoutput(r'{0} d {1}'.format(mavcrypt, text))
        if (status != 0) or (not res):
            self.handleErr('fail to decode the text.')
        return res

    def merge_xml(self):
        logging.info("start merge_xml")
        sys_xml_path = "/opt/confd/confdInstallDir/var/confd/cdb"
        xml_dir = "/tmp/merge_dir"
        _type = self.vdu.pop("vnf-type", {})
        vnf_type = _type.get("service-type", None)
        sub_type = _type.get("sub-type", None)
        try:
            import shutil
            systemxml = glob.glob("/usr/*/current/config/xml/*_system_static_config_data.xml")[0]
            if not vnf_type:
                logging.info("no vnf_type defined")
                # shutil.copy(systemxml, sys_xml_path)
                return
            # The operation will be done in the temporary directory.
            _vnfxml = glob.glob("/usr/*/current/config/xml/vnfType_{0}_*.xml".format(vnf_type))
            if sub_type:
                _vnfxml = glob.glob("/usr/*/current/config/xml/vnfType_{0}{1}_*.xml".format(vnf_type, sub_type))
            _vnfcommonxml = glob.glob("/usr/*/current/config/xml/vnfType_common_*.xml")
            bn_sysxml = os.path.basename(systemxml)
            product = bn_sysxml.replace("_system_static_config_data.xml", "")
            if os.path.exists(xml_dir):
                shutil.rmtree(xml_dir)
            os.mkdir(xml_dir)
            shutil.copy(systemxml, xml_dir)
            if _vnfcommonxml:
                vnfcommonxml = _vnfcommonxml[0]
                shutil.copy(vnfcommonxml, xml_dir)
            if _vnfxml:
                vnfxml = _vnfxml[0]
                shutil.copy(vnfxml, xml_dir)
            # invoke merge script to generate new system xml
            cmd = '''python {0}/confd_xml_merge.py {1} {2} {3}/{4} {5} {6} "" "" "" "" True'''.format(script_dir, yang_files_dir, xml_dir, sys_xml_path, bn_sysxml, product, vnf_type.upper())
            logging.info("merge xml:\n\tvnf_type: %s\n\tcmd: %s", vnf_type, cmd)
            status, out = commands.getstatusoutput(cmd)
            if status != 0:
                self.handleErr("execute confd_xml_merge.py failed: {0}".format(out))
        except Exception as e:
            self.handleErr(unicodeStr(e))
        finally:
            if os.path.exists(xml_dir):
                shutil.rmtree(xml_dir)

    def set_sssd(self):
        LDAP_SERVERS = self.sssd_dict.get('LDAP_SERVERS')
        USER_GROUPS = self.sssd_dict.get('USER_GROUPS')
        LDAP_BASEDN = self.sssd_dict.get('LDAP_BASEDN')
        LDAP_USER_SEARCH_BASE = self.sssd_dict.get('LDAP_USER_SEARCH_BASE')
        LDAP_BIND_DN = self.sssd_dict.get('LDAP_BIND_DN')
        LDAP_GROUP_SEARCH_BASE = self.sssd_dict.get('LDAP_GROUP_SEARCH_BASE')
        LDAP_AUTHTOK = self.sssd_dict.get('LDAP_AUTHTOK')
        CA_CERT = self.sssd_dict.get('CA_CERT')

        if LDAP_SERVERS and LDAP_BASEDN and LDAP_USER_SEARCH_BASE and LDAP_BIND_DN and LDAP_GROUP_SEARCH_BASE and LDAP_AUTHTOK and USER_GROUPS:
            # do sth
            logging.info("Will set SSSD.")
            logging.info('LDAP_SERVERS: %s', LDAP_SERVERS)
            logging.info('USER_GROUPS: %s', USER_GROUPS)
            logging.info('LDAP_BASEDN: %s', LDAP_BASEDN)
            logging.info('LDAP_USER_SEARCH_BASE: %s', LDAP_USER_SEARCH_BASE)
            logging.info('LDAP_BIND_DN: %s', LDAP_BIND_DN)
            logging.info('LDAP_GROUP_SEARCH_BASE: %s', LDAP_GROUP_SEARCH_BASE)
            logging.info('LDAP_AUTHTOK: %s', LDAP_AUTHTOK)
            logging.info('CA_CERT: %s', CA_CERT)
            if CA_CERT:
                open('/etc/pki/ca-trust/source/anchors/CACert.pem', 'w').write(CA_CERT)
                commands.getstatusoutput('update-ca-trust extract')
            # update conf file
            conf_file = "/etc/sssd/sssd.conf"
            conf_dir = "/etc/sssd"
            try:
                if not os.path.exists(conf_dir):
                    os.mkdir(conf_dir)
                    os.chmod(conf_dir, stat.S_IRWXU)
            except Exception:
                self.handleErr("sssd configuration failed")
            content = '''[domain/default]
id_provider = ldap
auth_provider = ldap
chpass_provider = ldap
cache_credentials = False
ldap_search_base = {0}
ldap_group_search_base = {1}
ldap_group_member = uniqueMember
ldap_user_search_base = {2}
access_provider = simple
simple_allow_groups = {3}
ldap_uri = {4}
ldap_id_use_start_tls = False
ldap_schema = rfc2307bis
ldap_tls_reqcert = allow
ldap_tls_cacertdir = /etc/ssl/certs
ldap_tls_cacert = /etc/ssl/certs/ca-bundle.crt
ldap_default_bind_dn = {5}
ldap_default_authtok_type = password
ldap_default_authtok = {6}

krb5_realm = #

[sssd]
domains = default
services = nss, pam
config_file_version = 2
reconnection_retries = 3
sbus_timeout = 30

[nss]
homedir_substring = /home
default_shell = /bin/bash

[pam]

[sudo]

[autofs]

[ssh]

[pac]

[ifp]
'''.format(LDAP_BASEDN, LDAP_GROUP_SEARCH_BASE, LDAP_USER_SEARCH_BASE, ','.join([x.split(',')[0] for x in USER_GROUPS]), ','.join(LDAP_SERVERS), LDAP_BIND_DN, LDAP_AUTHTOK)
            open(conf_file, 'w').write(content)
            os.chmod(conf_file, stat.S_IRWXU)
            commands.getstatusoutput('systemctl restart sssd')
            # add USER_GROUPS
            for g in USER_GROUPS:
                gname, gid, role = g.split(',')
                # logging.info(commands.getstatusoutput('groupadd -g{0} {1}'.format(gid, gname)))
                if 'admin' == role:
                    cmd = "sed -i '/^[[:blank:]]*%{0} /d' {1}".format(gname, sudofile)
                    commands.getstatusoutput(cmd)
                    cmd = "echo '%{0} ALL=(ALL) ALL' >> {1}".format(gname, sudofile)
                    commands.getstatusoutput(cmd)
            # update ssh
            logging.info(commands.getstatusoutput(r"sed -i 's/^[#]*[[:blank:]]*PasswordAuthentication[[:blank:]]\+.*$/PasswordAuthentication yes/' /etc/ssh/sshd_config"))
            logging.info(commands.getstatusoutput(r"sed -i 's/^[#]*[[:blank:]]*PermitRootLogin[[:blank:]]\+.*$/PermitRootLogin no/' /etc/ssh/sshd_config"))
            logging.info(commands.getstatusoutput(r"sed -i 's/^[#]*[[:blank:]]*UseDNS[[:blank:]]\+.*$/UseDNS no/' /etc/ssh/sshd_config"))
            logging.info(commands.getstatusoutput(r"sed -i '/^[[:blank:]]*ciphers[[:blank:]]\+/d' /etc/ssh/sshd_config"))
            logging.info(commands.getstatusoutput("echo 'ciphers blowfish-cbc,aes256-cbc,aes256-ctr' >> /etc/ssh/sshd_config"))
            logging.info(commands.getstatusoutput("service sshd restart"))
            cmd = "authconfig --enablesssd --enablesssdauth --enablelocauthorize --enableldap --enableldapauth --ldapserver={0} --disableldaptls --ldapbasedn='{1}' --enablerfc2307bis --enablemkhomedir --update".format(','.join(LDAP_SERVERS), LDAP_BASEDN)
            logging.info(cmd)
            logging.info(commands.getstatusoutput(cmd))
            # update confd.conf
            try:
                root = dom.parse('/opt/confd/confdInstallDir/etc/confd/confd.conf')
                aaa = root.getElementsByTagName('aaa')[0]
                lc_auth = aaa.getElementsByTagName('localAuthentication')[0]
                lc_auth_enabled = lc_auth.getElementsByTagName('enabled')[0]
                lc_auth_enabled.firstChild.data = 'false'
                with open('/opt/confd/confdInstallDir/etc/confd/confd.conf', 'w') as fd:
                    root.writexml(fd, indent='', addindent='', newl='', encoding='UTF-8')
                #  All users and groups shall be removed from the aaa_init.xml file
                root = dom.parse('/opt/confd/confdInstallDir/var/confd/cdb/aaa_init.xml')
                auth = root.getElementsByTagName('authentication')[0]
                auth.childNodes = []
                with open('/opt/confd/confdInstallDir/var/confd/cdb/aaa_init.xml', 'w') as fd:
                    root.writexml(fd, indent='', addindent='', newl='', encoding='UTF-8')
            except Exception:
                pass
        else:
            return

    def _do(self, platform):
        if platform == 'vmware':
            env = self.parse_ovfEnv()
            intf_map = self.sort_interfaces(env)
            self.vm_fill_vcloud_info(env, intf_map)
            self.vm_fill_traffic_info(env)
        else:
            if not self.isInContainer():
                # container has its interface initialized when pod startup
                # we don't go the sort interface way unless fp is intrduced in future
                intf_map = self.sort_interfaces()
                self.op_fill_vcloud_info(intf_map)
            self.op_fill_traffic_info()
            self.marshal_interfaces()

        def _split_ip_port(name):
            ips = []
            ports = []
            data = self.doorbell_info.get(name, [])
            if isinstance(data, str):
                data = data.split(',')
            if data:
                for ip_port in data:
                    if ':' in ip_port:
                        ips.append(ip_port[:ip_port.rfind(':')].replace('[', '').replace(']', ''))
                        ports.append(ip_port[ip_port.rfind(':') + 1:])
                    else:
                        ips.append(ip_port)
            return ips, ports

        self.doorbell_info['SDNS_IP_ADDRESSES'], ports = _split_ip_port('SDNS_IP_ADDRESSES')
        if ports:
            self.doorbell_info['SDNS_IP_PORTS'] = ports

        self.doorbell_info['CMS_IP_ADDRESSES'], ports = _split_ip_port('CMS_IP_ADDRESSES')
        if ports:
            self.doorbell_info['CMS_IP_PORTS'] = ports

        if "VNFM_IP_ADDRESSES" in self.doorbell_info and isinstance(self.doorbell_info['VNFM_IP_ADDRESSES'], str):
            self.doorbell_info['VNFM_IP_ADDRESSES'] = self.doorbell_info['VNFM_IP_ADDRESSES'].split(',')

        # for self.dns_info
        for info in self.traffic_info.values():
            dns_list = []
            if 'DNS' in info and info.get("DNS") not in dns_list:
                dns_list.append(info.get("DNS"))
            if 'DNS1' in info and info.get("DNS1") not in dns_list:
                dns_list.append(info.get("DNS1"))
            if 'DNS2' in info and info.get("DNS2") not in dns_list:
                dns_list.append(info.get("DNS2"))
            self.dns_info["server"] += dns_list

    def _mergeUserData(self, dst, src):
        if isinstance(src, dict):
            for k, v in src.items():
                if isinstance(v, dict):
                    dv = dst.get(k, None)
                    if not dv:
                        dst[k] = {}
                    self._mergeUserData(dst.get(k), v)
                else:
                    dst[k] = v

    def _do_for_vdu(self):
        # set hostname
        logging.info("\n======================= _do_for_vdu =====================\n")
        hostname = self.doorbell_info.pop('vmname', '')
        if hostname and self.vdu.pop("HOSTNAME", True):
            logging.info("reset hostname to {name}.".format(name=hostname))
            commands.getoutput(r'hostnamectl set-hostname --static "{name}"'.format(name=hostname))

        # set for mount_volume
        try:
            if 'volumes' in self.vdu:
                mount_parms = []
                for vol in self.vdu['volumes'].values():
                    mount_parms.append(':'.join([vol['VOLUME_UUID'][:20], vol['MOUNT_POINT']]))
                if mount_parms:
                    cmd = "{0}/mount_volume.sh {1}".format(os.path.dirname(__file__), ' '.join(mount_parms))
                    logging.info(cmd)
                    os.system(cmd)
                    time.sleep(10)
        except Exception:
            logging.error("get an error when mount volumes.")
        _confd_user, _confd_pwd = 'admin', 'admin'
        if self.vdu.get("security", {}):
            # set confd user and password
            _confd_user = self.vdu.get("security").get("CONFD_USERNAME", '$4fc5ee3c8d6d964b7475ea60473eda92')
            _confd_pwd = self.vdu.get("security").get("CONFD_PASSWORD", '$4fc5ee3c8d6d964b7475ea60473eda92')
            if _confd_user.startswith('$'):
                _confd_user = self._decode(_confd_user, prefix='$')
            if _confd_pwd.startswith('$'):
                _confd_pwd = self._decode(_confd_pwd, prefix='$')

            # set sdns user and password
            _sdns_user = self.vdu.get("security").get("SDNS_USERNAME", '')
            _sdns_pwd = self.vdu.get("security").get("SDNS_PASSWORD", '')
            if _sdns_user.startswith('$'):
                _sdns_user = self._decode(_sdns_user, prefix='$')
            if _sdns_pwd.startswith('$'):
                _sdns_pwd = self._decode(_sdns_pwd, prefix='$')
            if _sdns_user and _sdns_pwd:
                self.sdns_auth = (('name', 'peerConfd'), ('sdns_user', _sdns_user), ('sdns_psw', _sdns_pwd))
                logging.info("add user for sdns: %s", _sdns_user)
        logging.info("add user for confd: %s", commands.getstatusoutput("useradd -d /home/{u} -m -s /sbin/nologin {u}".format(u=_confd_user)))
        logging.info(commands.getstatusoutput("echo '{p}' | passwd --stdin {u}; usermod -s /sbin/nologin {u}".format(p=_confd_pwd, u=_confd_user)))

        cf_file = "/opt/confd/utilities/aaa_groups.xml"
        tree = ET.parse(cf_file)
        grp_root = tree.getroot()
        # old_grp = tree.find("group")
        # node = tree.find("*/user-name")
        # if not node:
        #     node = ET.Element("user-name")
        # node.text = _confd_user
        # grp_root.append(node)
        with open(cf_file, "w") as fd:
            fd.write(ET.tostring(grp_root).decode())
        cf_file = "/opt/confd/confdInstallDir/var/confd/cdb/aaa_init.xml"
        tree = ET.parse(cf_file)
        node = tree.find("{*}nacm")
        old_grp = node.find("{*}groups")
        if old_grp is not None:
            node.remove(old_grp)
        node.insert(1, grp_root)
        with open(cf_file, "w") as fd:
            fd.write(ET.tostring(tree.getroot()).decode())
        # logging.info(commands.getstatusoutput("/bin/bash /opt/confd/confdSetInitialConfig.sh  [CONFD_USERNAME={u}]".format(u=_confd_user)))
        ####################################
        if os.path.exists('/opt/confd/confdInstallDir/etc/confd/ssh/authorized_keys'):
            logging.info(commands.getstatusoutput("mkdir -p /home/{u}/.ssh 2>/dev/null;cp -rf /opt/confd/confdInstallDir/etc/confd/ssh/authorized_keys /home/{u}/.ssh/".format(u=_confd_user)))
        else:
            logging.error("/opt/confd/confdInstallDir/etc/confd/ssh/authorized_keys does not exist.")
        # set timezone file
        timezone = self.vdu.pop("TIMEZONE", None) or self.doorbell_info.pop("TIMEZONE", None)
        if timezone:
            logging.info("reset timezone to {zone}.".format(zone=timezone))
            commands.getoutput(r"ln -sf /usr/share/zoneinfo/{zone} /etc/localtime".format(zone=timezone))
        # set zone file
        if self.vdu.get('SIMPLEX', False) and 'SDNS_IP_ADDRESSES' in self.doorbell_info:
            logging.info("update zone file for named.")
            dnsName = '{0}.sm'.format(self.doorbell_info.get('VNF_ID'))
            dnsIp = self.doorbell_info.get('SDNS_IP_ADDRESSES')[0]
            # for ipv6
            if ':' in dnsIp:
                aRecord = '{name} IN AAAA {ip}\n'.format(name=dnsName, ip=dnsIp)
            else:
                aRecord = '{name} IN A {ip}\n'.format(name=dnsName, ip=dnsIp)
            content = open('/var/named/mavenir1.zone', 'r').readlines()
            for line in content:
                if re.search(r'^\s*{0}\s+'.format(dnsName), line):
                    content.remove(line)
            open('/var/named/mavenir1.zone', 'w').write(''.join(content + [aRecord]))

            content = open('/etc/named.conf', 'r').readlines()
            for i in range(len(content)):
                if ':' in dnsIp:
                    if re.search(r'\s*listen-on-v6\s+port\s+', content[i]):
                        if dnsIp in content[i]:
                            continue
                        content[i] = re.sub('}', '{0}; }}'.format(dnsIp), content[i])
                        content[i] = re.sub(r'^\s*//\s*', '', content[i])
                        continue
                else:
                    if re.search(r'\s*listen-on\s+port\s+', content[i]):
                        if dnsIp in content[i]:
                            continue
                        content[i] = re.sub('}', '{0}; }}'.format(dnsIp), content[i])
                        content[i] = re.sub(r'^\s*//\s*', '', content[i])
                        continue
                if re.search(r'^\s*allow-query\s+', content[i]):
                    if ':' in dnsIp:
                        if '::/0' in content[i]:
                            continue
                        content[i] = re.sub('}', '::/0; }', content[i])
                    else:
                        if '0.0.0.0/0' in content[i]:
                            continue
                        content[i] = re.sub('}', '0.0.0.0/0; }', content[i])
            open('/etc/named.conf', 'w').write(''.join(content))
            os.system('service named restart')
        # set vdu security
        if self.vdu.get("security", None):
            logging.info("security: %s", json.dumps(self.vdu.get("security"), indent=1))
            # # do for ROOT_LOGIN_DISABLED
            # if self.vdu.get("security").get("ROOT_LOGIN_DISABLED", None) == False:
            #    os.system("sed -i 's/^[#]*PermitRootLogin .*$/PermitRootLogin yes/p' /etc/ssh/sshd_config")
            #    os.system("service sshd restart")
            # else:
            #    os.system("sed -i 's/^[#]*PermitRootLogin .*$/PermitRootLogin no/p' /etc/ssh/sshd_config")
            #    os.system("service sshd restart")
            # https
            self.https_status = self.vdu.get("security").get("HTTPS_ENABLED")
            # ssh
            self.ssh_status = self.vdu.get("security").get("SSH_ENABLED")
            if self.ssh_status:
                cmd = "mkdir /home/{u}/.ssh 2>/dev/null;chmod 700 /home/{u}/.ssh; cp /opt/confd/confdInstallDir/etc/confd/ssh/ssh_host_rsa_key.pub /home/{u}/.ssh/authorized_keys".format(u=_confd_user)
                logging.info(commands.getstatusoutput(cmd))
            keys = self.doorbell_info.get('keys', [])
            for key in keys:
                if key.get("type") == "ssh":
                    self.ssh_public_key = key.get("data")

            for index in range(1, 11):
                ip_key = "LDAP_SERVER_ADDR{0}".format(index)
                ldap_ip = self.vdu.get("security").get(ip_key)
                port_key = "LDAP_SERVER_PORT{0}".format(index)
                ldap_port = self.vdu.get("security").get(port_key)
                if ldap_port and ldap_ip:
                    self.ldap_list.append("ldaps://{0}:{1}".format(ldap_ip, ldap_port))
            self.ldap_basedn = self.vdu.get("security").get("LDAP_BASEDN")
            self.ldap_cert = self.vdu.get("security").get("CA_CERT")
            serv_list = []
            grp_list = []
            for index in range(1, 11):
                serv_key = 'LDAP_SERVER{0}'.format(index)
                sssd_serv = self.vdu.get("security").get(serv_key)
                if sssd_serv:
                    serv_list.append(sssd_serv)
                grp_key = 'USER_GROUP{0}'.format(index)
                sssd_grp = self.vdu.get("security").get(grp_key)
                if sssd_grp:
                    grp_list.append(sssd_grp)
            self.sssd_dict['LDAP_SERVERS'] = serv_list
            self.sssd_dict['USER_GROUPS'] = grp_list
            self.sssd_dict['LDAP_BASEDN'] = self.vdu.get("security").get("LDAP_BASEDN")
            self.sssd_dict['LDAP_USER_SEARCH_BASE'] = self.vdu.get("security").get("LDAP_USER_SEARCH_BASE")
            self.sssd_dict['LDAP_BIND_DN'] = self.vdu.get("security").get("LDAP_BIND_DN")
            self.sssd_dict['LDAP_GROUP_SEARCH_BASE'] = self.vdu.get("security").get("LDAP_GROUP_SEARCH_BASE")
            self.sssd_dict['LDAP_AUTHTOK'] = self.vdu.get("security").get("LDAP_AUTHTOK")
            self.sssd_dict['CA_CERT'] = self.vdu.get("security").get("CA_CERT")

    def _secret_confd(self):
        home = '/root'
        user = 'root'
        if os.path.exists('/tmp/_whoami'):
            user = open('/tmp/_whoami').read().replace('\n', '')
            home = '/home/{}'.format(user)
        fname_dic = {
            # netconf-ssh-keys should include at least one key pair
            "netconf-ssh-keys": ["/opt/confd/confdInstallDir/etc/confd/ssh", {
                # ssh_host_rsa_key.pub
                "ssh_host_rsa_key.pub": "cefc6c1349f4d24cba4904d1ffe18557587a4dda2d6326a40281208d0187a6c2426eb19bdda01d8f9624a191367f63550800b398101e7439ed0b1576a5be28c9036c15779c614b4fc20f4f6ecb87f265ec748a691e25d35f520cabba60620948a2541830a190149eab42a6a43edf66d45b03e5f8fb7b2d3d8b0370f0ae2686fe258fb044aa4fa77886df97a0cf16670a86a170a34275bfcef14d44959eff1633894058c8ce29041094d541455d485737cdc26022a4675afa81ec21ef78233b0d37924f4fd8255035caf5b1b9bfd17c959329f0887273cabaf03ad8deb9ce10e3febc1c45d4a371bbfc21260f315efd11b211102ac10025e8363a4e9ed65003872b007191711af009578f489292a607895404f6feb0fe563158cde02f5ed1b5dd04a056f52606a81b7ad5f88ab2682a26ca06151737a3d8dabed3f1a261abca061cbf916dcf30a5e7fd8f68084eb75888a5916eaa8a84ab65a648ace689c3c198075b2578cb20f35fe2f436a497887c46bc1f1f9443cdc84b9e5240d77d2f6428641ef31b9d1b9817476837e07949d612", 
                # ssh_host_rsa_key
                "ssh_host_rsa_key": "d3ddd2c313ed83b17b92fc17985a0f535af948d337fcd08c3d48b646719a39f2abdc833fa743014fe085df0a06ed95beca8b030448472de2ae1269f3bfe308f027c6752a48ab1f0772104ace0a5aab1360f80c4034f1fb7383d0320c6210a66f511154774bd8234a31b02c4ad86bbcd82b781ec0db220c4f576566696d3733352edf0437b6063d47ed81cbff654a25ef33f8266eb566a4b79140574e4af5f3c13c13d2c35744e8322b72f6b6035d6bef617a6f6b363476075fa4e6b496cdfb4fcd1860fe6fcdd9aad4f38dcb5d0afc6fbf14674e149aa16f0448a1a484ad5fe8104b3a2bf3288111b68f6ab4aab1d717fe1265c5699009786653d8ff98992a81faacad66e4e2d0c0476944d2dd8f7b5f80a0ee4626d04fb5ed2b892a5ddc88e22d15ed78f44b292c9292c202ca7defc357e844e73d16fba93932666c2754b048eceb04fc1c259ec3a91cf59c5dbefe71fb74c09771a62087995cda7c23d5c1bc25ae707d6b93e0f8bdc1a75fe5752e0ffec5501fac94044287b570d7921e4fb560b469fcf5dd6f2d0fae4c2f1e453e76d4c2628d6e6147696f5838ed24448ad15e7bb989bd69449df3ba4923e40b5afef75d68b44c677961274355efd8ad4a07eace4e66281801ab91a4b7869e333634c5508638d88a65b2e8fae62083dc8ff67418e24bd79b0f2e21e2b70f0790f4e72184939b83496652577da890aae552592ac5645f2fcad17e3a3978436db7a47a36683f61107db68b0cf8ec3a99708e3ab79df031ffbd595857104dd9a828974c520a4a34aa8105bb0a0a7ab042c6a1a9925e60217fbc89ec4652080ab9bc96d18775d83281df109ebac61ed3b09c3856172f3b77c678ef97458fd77847d4f38bffc7e78351716c046efc6aa75ce7712166d97ab0b268c9b1948a4b344ed36dc2871e292fc489948ef82d9d29652398aa704429898073b26681df0a19c48c4987fe23a1afffdd84cd135fc4a194aef7790e0022239e808683fe7060fc1fdff71bd534dd230c5e928d46b8b24e7198b899edd0dc0ac07e1cb2b472ffde9a669cbb5612afb4c969bb5c7ca684cb6f178b74e6124cadb0282d6737a1f013f234b97505b20bad8939ce4cf0ad91b2089d416b683ebec6a86b8083c289da5559a99e0cc97a4662cd62017030661b28eeef669f846e9829eb67140f78088ba8276575960c281903c3b24b0b2f8cbe183631a4dc65c61ed137724c9791738ac1204e171f0aef6e5d7d32746b6b24953d4c693252db61e33995837ef1c41d680a96e4a243f79be43d9eb4e9c1c9dd074f485ed6e86ad928180d04b46c2cbd937f1276627ab106a976669fa30131371a0e3f998eb03690f2dae88e45e89640c3794364f4a9f77669e2a624e80b1c3ee2f7cb895690f8d67344562044a92c17fabb046b4d8bad006ba737c5c8404cb74b4835940efd075bf27b10eb8ed452588e18b82517dc754d22bfcad99ad0c2aeef32904ab60ebd4d83c168e5fa39f5ddb5bbd15db6911ef64eb4d495f0f7895c3d01440b8d17424d771c9a1df8a3e4f5c253e4572b60b35a6135ca6368afe9a09f166ddb5cdf6f5e37eb1dcfc8cd9e2452654a3f59bba858a56c2eaa43424b7ebdfda3bdfac56514b113cb023ef0374dacd584888146026c208104d4472d29d2e65c84de1c0a73d02bb34b344d76af604b7f988662890d81700d43839dc68840e1ecf91a28f84d6373be546435a79a7acd623c8acb2f0849341a109c86af35a46503151e013243124134c8b58f70f13ac1e76cffb5e7654fb5c90cf5ce80e7106d12bededcc6c81e57567a9c3176a8bfa94b48e3ad770d24465dbba2f3a39d85441a56d6bde28bb80b1b5b9cddf14d0b3805fd5306a85b98e3472960bb8644aece5d077d2981fc8094d16c7fcd3e332b2b58a8e89a44e8af986826fac12091487d789f94b82f158af1bc2b5cf5d9d1ca83b36fb129abfae9a80e70be07c7b853bd17fba6b0dcab7870d1bc086f89186cf43f136b15d526ecf34d9b477a217ee461ee547ab6b4841040bead63a916b467f77457d884341d5c65e4a1e40568795d361ea232959046bc821ea3990b6f5eff4c00be1fb34abc02fc519d69aed947ac3c6acabfda2c95ee56f9605e86cc35d902d3789458d90ae14140b441f0c4eb8e1b468fe33cd11eab7f29b55786d685a9f38c90098d0248586e6da4359959a06865fffa4e7e1acc0664f12f7a327d5ccbc947c749b74077a5e8663d29a2dad078e3179d1e729556835e3bdea2b3bc61df9e34ae4164f7323a404a9ed09f0a6375ac80a9d0045f0865de50b9978a0800ec143ed737b17a994a851d84d88895caad97920c2f2230535de4001d24eeffda37dec1dd49cda3"
                },
                'root'
            ],
            # netconf-ssh-keys should include at least one key pair
            "sshd-ssh-keys": ["{}/.ssh".format(home), {
                # id_rsa.pub
                "id_rsa.pub": "cefc6c1349f4d24cba4904d1ffe18557dce525e3f7bc086603ff9dbf7049ab61547948470cabdd71ec32f3d97e42f2e7db7c373ecf199fdce61dc0d23e9487fb02059515be8f610e8eff84a13891c271e5f4a1760aa31f22257d9c48119486b259f3ab0e814693c8e4bd6a8cdf55ae07b421d50e2137e99f559b5278252af1c643cf185fd6df836c6e119b8da54163b41d3fb2c4efb7ec8f7d579f462d435ec1e6fabd16e6c1b09764d38e88bc8b548a9f8ca01e2d6fab433538e6041a7e4aaac4d161403609215b0f0736bc475c48a1aece12686bebbbd377fbea0dcb1876bb51b608564941035c89a44b5310b0e5bfff8e01d9ba6c638c4ea4f66d3caec9890b57e7ac502bf1bdb69cbd8b4c8e3815ef5ad24ec10cbcf9c285aa517de7f876898e5b3fcbfef98d0489cd6a7626dc4cbee452dc7792b774c7083d415f23c69d82f838a80ca3437679b0ffc113727fc110c04650f01824c3d639d6f9682acc7d5fa883354b6b2c54e60037173c5e614b80517d8cc8730a6da2cb29744fd9d930", 
                # id_rsa
                "id_rsa": "d3ddd2c313ed83b17b92fc17985a0f535af948d337fcd08c3d48b646719a39f2ccf9f8c55a8f3067b21a266d00351996f269080994978510cd7dfe299c15724e3c998584221de9988b10c0ff033eb8d3a8f41d98207398722590841b8b143f94d71444740983ac1891fe74b052e4e3ae6bd3dc4a5e02743817ff5ff6481390ffc3c7f9754fc72b68feda4ef229fc4eed79ae2b6191ec84db639d382b89cbc8d1487eb96451d79b712e7aaf35fe206a81669efea9cd33057f839d05c7628d2c8212febe79f5c6cf04576b0cb675c81132a1d9a1c174560841184836acfc446fb45afb60149376c9cb027af24d1585cb1dbaf6c03799b725fe96c1f1e0373b782780a8acce63d40c3282eb55cbc42898b9de87bc572189348880c88dac6db7fcbad9543a32c8ca55f00febae9b131163a2898e5b3fcbfef98d0489cd6a7626dc4cbee452dc7792b774c7083d415f23c69d82f838a80ca3437679b0ffc113727fc19b3a41426b3bd54a8277b38f07bf577eb47703e49ae8cc540bf8c8770a20a9b3d86a7883e8dff7467d68e4ddf1df4d0f2bb756f26912de4f6791ef371aceaee88b6a5fb717bc138d15ce1b7ca0cfff7faee2561ebb97d8051b53e47dd17e5359b53c0c08f19e1fb60a5c4289b9357dc59a17d6c270a5145f83ccabc627b13bbc53ca556730e41224ad8106f1879b3f5e85384324f188d676d9c3c4b9f40eacde51790fbffc6aa64b249ac54dcdbc72c1cb8fccab7d343e488083d7f007562d57c26d77a77d9c018db29611b258a575d196d152af67f38ed7403b773061c3b5b05f10dfa94718a9b3c5412a8c9d6a81c18261f35cc0cebaae7c77655100666ebb28cf0a5b3187b5c2d5c3cab11cd020b0e8eb54fbc633afa67121a870fbc1b2e9840286279da3b24d8af0b1213e94e3f08b857869fc23614c3331762807eec37b9856ea80d4ee4b0e3ccd12c55a6694d762639aa51efdc96942def3924a5fa6183d3089f8507acb4abf1306ab7701ae7bc8d25b2f225c5c96c8d87f33c0e2c01d13adaecdae6cf2690f5ba73bbe30c77385114fc4556911ae3c032891695e505a33bbf385e7be18c62386e2cb19684f516e8fa7e2facd5466eb1b068d3ef41c361bbc5e0cfda8b7293728460c39a1501053b407167bca45597addaf82c0e6c714bd64e9992c025ad5c7935fc9438ab0c487b332a90b403a6ccf31117495f7e843ce403761b5fce2ea718077692478ce34b359aea64769f813f094bebc5958a2533579ee0ab338424ac94a7dd0535efa8d7aeff6a90c5016a23ec87a7db0293b20209d404ba14a3118efb5b28c2729cc79c45c6158149d7eb966eafe121f6679e35cb9cc9ecb8edd5580f55cab3b60040f547e0ae9a2c0ba594420e66bb2b5e32fcf44965810617e8899b837a0875e9f70d99e98808b6b3dc8f8f386c1313334ebbd097b30794b4644d1b5d4efd7c721649acafa6abf2c0b691696348d1f9d98c1983067beb17e672f7d17335ff6639ded7254b8b8ff9cd8a4b0fcdb0b13752cd1330cfba796168c3489a3fa695dbb9f4231c39fe4c6befef83c50bfa69d29412f21eee4e98a8aabeffa37ddbf989f02d339397858ff9491f98c4695bbd7ee13e502c3f2d12a9f8520e1f537800d6b09fa2c1e4c79e06e55dbdef8abda17081fa7dd894a7583ae5203d89625781199f83d0bbf723bb10434e2a8e418d351b10ca4c7ec0e6adf0650daf1c5f57a7c16e91844f899ea171e01e6c190b897bc7b7af262e70e6236a824f0334654fb3c5da69ee6a8ce5f93beb2010cefee3f3b9da1279fbb6ba3ab5beba3cce84b0441533903f57e6ea03a2b23a93775097e7b4c160cd22222b8f405def98345622685de90224715641d4ddf5edb4959c863cd2cf0ea7e3bb021b8d12aa33b2bba87c4c361cc4701a257c77124f1ff957f800b1ec01e43e74e69b1f60aeb66dcfeee3f140f80b62c16631420045495a70ea7b30d6a2d35c50088eee6d4e8699184f7de1aee45cdb33c5bc7df6c037539dfcf80e521d4730336af7ae2c177186cdeaf4a7446c0f32de007e4ccdd16a575e07b5b83fa4ef141e7f42f6abe635d5db3caa46381f26b7f2bc85f0bd67d5e35b4a8610eb48ce1b931ea6e93cc9cc5ad6bc71b65eec53e0057ab5d4aee81f03f966bdf2e50a66c6c556fa763f996696e828b314acb708e05ac738a0fb869275cab0efc36292b32557d6adcfe1a9f6ded039c96e1c449df3ec09697cd721f16fbec3b3ff311f984d23a96eb23651414b3d09981a3ae41ab5ddab1984158b429f9ecc41f3d6fa4d1ee92812a2f2ae4ab4761a24c08ef49994a851d84d88895caad97920c2f2230535de4001d24eeffda37dec1dd49cda3"
                },
                user
            ]
        } 
        for key, srcdir in SECRET_FILE_DIR.items():
            file_list = glob.glob(os.path.join(srcdir, '*'))
            dctpath = fname_dic[key][0]
            codedtexts = fname_dic[key][1]
            u_user = fname_dic[key][2]

            os.system("mkdir -p {}".format(dctpath))
            if len(file_list) > 0:
                os.system("cp -f {}/* {}".format(srcdir, dctpath))
                os.environ
            else:
                for fname, context in codedtexts.items():
                    fpath = os.path.join(dctpath, fname)
                    with open(os.path.expanduser(fpath), 'w') as fd:
                        fd.write(self._decode(context))
            pub_key_file = glob.glob(os.path.expanduser(os.path.join(dctpath,"*.pub")))
            logging.info("will create the auth file: path:")
            for fname in pub_key_file:
                auth_file = os.path.expanduser(os.path.join(dctpath, "authorized_keys"))
                with open(auth_file, 'w') as fdw:
                    with open(fname, 'r') as fdr:
                        fdw.write(fdr.read())
                os.chmod(auth_file, stat.S_IRUSR|stat.S_IWUSR)
                logging.info("\t create the auth file: {}".format(auth_file))
            os.system('chown -R {0}:{0} {1}'.format(u_user, dctpath))

    def _gen_confd_webui_key(self):
        bcodes = {
            '/opt/confd/confdInstallDir/var/confd/webui/ca_cert/private/ca.key': 'LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQpNSUlKS2dJQkFBS0NBZ0VBdmVUTEF4ZldWaHltdzBYVnBSazRGL2dTbG02QU1RYnBEK0Z0NWZQWHNIaW9xaWJQCkU4OGp0OVhVNU1rYjR3ZGlNYlNrckUzdXNSTTZCSENyLzRNNDRrSDEyYW4zTjUwR2pCKzFybDk1aENXcGJwTVQKWEthcm5vNFFvZnNSV0dvVHBvVzRwVUV0ZWU0NjRJeFl6dUZVQU5ZamJMTlRWYjJvejFlREFvcVluMFQvWE12RwpId3Y0Y0xOY0puZ3FVMDNwT09sdjB1SHFxZ0FzM29hb2hnbHowZTUvVE12V01JN2l6RHNrLzBmNmI5ZUhRcENwCm83dGNiT1d5OXZaV2JUTXJuWFdrUjJwcEdXSGZ6Ui9iMmVyMG9zbVNQMExKWGRtTE9NM1E0dHU2djJFcmdWYk0KKzZnbStnUU5wWUtBc1dIblVjWXh6L2xTVTNFamN4MC85NjNZTEx1YW02M2w1ZTBrbHVHNEs0Wm5uNkRYZEJ6cgpUSW9ySThQMjdGUUs2MXk2Q0I2ci9ra0VoNFdJRnkwWW5lL0tWZXRXalpxL2dpczB1ZVFGc2diU2NLbC9XRCt3Ckp0N1Fua2FpK1lFTDhFYzdRV1dGOVNZVkoxeFZXQ3lla0d0RDVSbXRlaWExUE5LenVwbkJXWXRnL1BTeHVuNUwKOTZNTm1qNEZJd3ZuQnZINHFYamdMRlExWlBuWVplT25wQjJ1R3dLLzd4ZHBqbVRvWjR1RzhoTEpFOWdCeU1KcApkRXdHaGNVS3Fac09NWG42Q01mbDNuYzh5NEExK3dQejZ5MEZlaDI0M3Z6M2RtdmZXeFhHeFZhakJyVnJYSGt3Cm5UM3l6RzNxQm1Eek16NEVPcGM3N1huUWdDanZXVGc0Q0huWlZKdDljVHczdVFPbjEyaThqY3d0ZDBNQ0F3RUEKQVFLQ0FnRUF1a1pWWHhOakRkWE5RSUNnc3ZPcU10a0dZc3JDdFZVeUNvSDRiRHBtdXBXaDNrZHptdHIzRHI2VAp1Rm9QSVFWOUxZVW1oRjl1WmdXV1JBVEN0RUxrNmc0S1BScWRoOUJoTzlOZlJVNGl4WjZzTmV2UWNuS01wMXgwCnRIQzA4eVliWUo2TUlvOXRMTTZrc3VENXZQY01rRVYvT29JdW5VME82MVhORGhFbTVoV282ajU2ZXJvalcycVcKV3FaRjNySHV0Z1ZIekhZUTIvS1FFVG5HMXJVdkNDQU1nQ2owVTIzV3pNQzM2ak9SVjJUMUtqYitNYjc1UzFtSAoxUHFRalU1RTJwRXNOV0lNOXZrcnNPd3ZuZlQ5UlRLMlk1Z0FNQy9XZ2tKalJpYUZhbmJIVm5qdlcyMzN6Z2xyCjJZL0s3alk3MDl1M3dXdXhkbWpsZldhVCtVSnZhc0ZmUlAyeEdIbWxLeEliei96RlF0V0pwVG5pOS9Fb1BmaXQKRFNSbFZsRDRWaFUrWmwxVGl2b1hmVk5HVW5wWG1TVWFKN043eU9UL2YycVBhNFdtVnZ4dzRqekhGNEZEN0RCWgpZU2t2SkcyTi9hYzhQa3lyRk4xQmxVcXpNUWljMkZUVUQwTi9NemVvK2gvMUwvMmpVVkNRY3NaVE1mOCtaczE2CndXUS91ay9qbzNCeXAyRTBXcjFKM2ZrbkRud3c2UngxOGZUb0N5SlVwY1EvaDBScmpWWHpDb0V1dC9xYU42dFgKVmFwR2xMTTZZUXoySWpPdFdnWjNvNXRPeHRHSEpHNG53dEI3TlpDVG4xZ2psaWdTVG5oK3ptWnl1NXhSdkpNRgpSYXlMSWUvdHNXemp1bkpNSXZaVlRFWUNOSW4yZkVMQTh0RW9VM2xJeEtDeUJSQWZ1QUVDZ2dFQkFPTFFmUXZDCmt0UnVtalRTRmlKK1VEUFZseVFDZ3hSd1U4VzZwZmFidWRsazBVMGJzNGM5c0kxVXRtRXV1SWlyb0x6S1o3ak8KZHZjamxRS0dWVHQvVUt4c3BwcjAwcGdaM1QyS0RBMGpIS0xLS3VSTU0vQndoYndrMGt6ZnhLcCtESHBGdmRGaQpaNDlMVzBwYjhPLzFVWk5uWG8zbXoxblpqWVpMVGROU3JsSFhKS1VtVHJ3WEt6Wi95S1NINVdYSktWUUo4RGhuCkxVQVc4a1d4eVl0UHA2MFhNK0VDalVOa3I2Ly9tZitmc2N0QzVuT3hZWHAzeTEwYmlCMzhhaVZMRmd3ZVBXNy8KYWsyQmR2UW1WZ3VmbHpJblh4SHJCWDVPbTJ3QWdVWkNhNGZqK1dhN2xua3ZDRnl0S1ExZnQ5VHYzVlNDNVlGQgo3UFByN1BCWUtBNElzNk1DZ2dFQkFOWlVHT2xJRUFjQ0Nyb2ZyQW04ZFNvdm9WS1Z3dUdJS2ZQZXVIZy9iZk9xCkxmamJYUitXUWROOTlQTm13RkdzRXRwL0dYZklCdDRsNWFNZ2VCdG5wMjZVS2lKMjhxSmFEN1JXSm1iNWR5VFEKZkZ5TkVkWEg3Q01ZUE8vbENuYXV4empucDlucXd6U0RraDRtQTV3OFZhdVN1V0VrMW1lWHpQVURDMEQ4TkYvSgo1bHNYcnlIQmVhazBra2FmUk1JWFFhY3lUbmd6THdZYitHeExYVVNndWdUeEZCbGVoUUZzZjhyU09ZWXFsWi9mCnM5SWpPYXJGdGVWYngwNkN4ZGJlUE4wdTQxWnJONFl1enExR1NZZEFvMVVWbEVGcjhLSGwyQ3dWUVovcGJXSzYKRFpwdm5pVnVTUVhDUGRJWk1tVklQeHZyYkhCT3VQRHBhbDV2Tkt6TForRUNnZ0VCQU1JRjAxSkNDZFNMSUlMYQp6SENKV1JaZU9rSmxtN2ZhTnU5SU1UeDZEa3QzUU13VFRFbitiWThZemtMbjhwZUhLYU1XQ2hBL0hlbGZtTkptCkUzY24rOXpqdk1tRmNMa0lOd2V6bFllUFo2bWlBM3J6N09KYmZ5dG8zRFZDbmp1eVEvNDh0cG5zOGVYVWNxMXoKWlBJQUN0NXJhS2srcmxXUUVzNjBrRWlieTk3YWlkQjBxcG1md0NtSXVoeDAyN2xza1Z3QWZHdmpad1FTSFFHZAppbWtQcE1JZXZSUllXSHMwSUU0UCtxNSs3MXFQU2cvaHh4ODZaczZwQkpHU0lVTHhybFNEY2M0SDArbWxQQnF5CnlKeDgwcHZtcmg3bnl2VTNUU0RnZGJXaWo5WFpJTG5POG5PTDFqMWhLMkx6WkpCVStDS1pMcmFackpja1ZMVnMKMUNiZExyMENnZ0VBZDE0WEViWEUxMkpYdnhsc28yK0dnWnhOYU1WbjZGd0JvWVRsa0hNak5aWU9USTgvNmh1eApSYXpkQThLeVVjcFlKY0NyMm41WTlOaCtjTC9ncE1LeUNYQVRsMlpQOUFQY3d6OUgzQW9NUlVDb1FwTiszMldkCktsNlJjYnBLZlpjUjlhdHZYSHJYaFNQUitXQ0ttalV3TVlKaUpLeHpqUGFLZTlyYUpiTlJLQmcyWjMxbFdKTjgKd3JRNDA0UllzeEJvekVuRVVrV1Bad09rOUF0MVFvZVJrcmNCenE5SnZHVkZOeHltVlFiYWxsUHN2cGhId2NpagphYjRYM3E0T3FZRFV2UXNrS2psRWowTDZjSjY0ek04L0tHQUFWZjliNFk4MU9qZ01lSmQxQ0lzK2tFaWg5NDdZCnRKQmVCZWxxbStZRTMvUGFUU0pLOWtISnNCYVhhN1ZOZ1FLQ0FRRUF1azRzbWdwbVFFR2cvWC9QWXRUaExoa0sKbVEyVnpET2xCUWpGclcwNkFjNFNHbElmV1NjcU9ybDNsaEt3ay9xZ0J4VW5ZNzNIT1VhbGRBLytKc1YyNHF4bAo1Z3cvL2cxMWxiZzR5T2pMYzlKc2ZWK2IrVXdqZzNuVjBicE9sck9uT2wvaG9udUN0STZVVG5NNEdXNThZdEtQCjAwQTM3aG1TdU8rMW9vMTIvU1ZkMDk0QnlFYU5ycVlhUTVISVdONUt0S2UxV25QMXFzamg2ZFppZExtcTMwMWgKaUM5UVEzWGYyeGdBNWp4bHRPY1ZJeHNYTjU0WHZSSnBSbHhvRmd1cHlKM0VrZWVOMWpxVHgzOUVwdUNEcU5hcwo1UWNDdnRuZTJERDR6RWo2bUhHazIwL29IU2d2V0tDclhIYmJkMTY1dmpLSDUzcTlpQ3RqSWVXdEpsY3ovdz09Ci0tLS0tRU5EIFJTQSBQUklWQVRFIEtFWS0tLS0t',
            '/opt/confd/confdInstallDir/var/confd/webui/cert/client.key': 'LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQpNSUlKS1FJQkFBS0NBZ0VBNFpPN0ZnWDA3eUdoVktIM2k3VTA5NUlucEVNL2JwOG42dHBzaWpzYkhNRXJmZWx0ClErRnM3a1lEeGcxTitGSlN5eHpHTFFPcCszL2theHp1SXpBQ1N3SGpVd0lHcERYaDlQTit3STBXSHVwYXlkT1AKSWNwU2UrbW04cDd5L0VNNFo0WGJ4cVhPSG8xdENDWVdTUWpHci9RTi94dFVES0VJUThtOWpTbEprQ1AxNEwraApPdmQ4enlwU2lCUExqenUyWHRRSnhETDZ3QlI0T2hHWUtZMytMQ1hmQmJpOGR6THhmZXh1R0xFODlyN2duQ3dhCk0vTnA2cjJhbER1Zk5wQXVCeGdEcmpQdVJpdG5CWE9vUjdwU202VmRibWZOYWk0L2I0NmtaZHlNUXJ2NitpRlQKeWU2bmVicjFBcVk2Rjc4OTNKaDE1NTZwRjVML0RUYUFzanFOUFFLakhXeHFmNUphREFTN0pQdnk3c1E4SEZNUApWSHl6Q0dML3dvYWRHZkFPRzJoeXhoYW4rSVlRdVVlaVU3MGZqbWExVXlNTmd4TDRMUndVRkc4M2Q3OUErZWJCCkYvcTdsREY0UU9OQzZQam45RUgvUDdyQ09JWkdMY3ZSRG1rNU1QVUI2L2d5T0l5UnVOc3piczdldGU5OU5iVkwKV2JXVUY1OFFPd0NTdEFrR2lxc1g0Y2tFK1hzaGhVdUZJSVE3ekNzSXFhdk5vaStkMy8wM3hCNkd2UllGMENDWQpJOXpodnUxTTNlaTNOdTFhRzFrR1M0ZCt6Kytwb3JWSTNhTTZiMWlGSnFOaC94UW93Snl0aXRyZVc1WHJBVlRuCjdCL3JIMUdjeWJPekFjNytFZkhQQWk5WGswSU1NOTZRUEpIeHE5ZGc5aEd6MHMySjlRdmhKR3lVVUZFQ0F3RUEKQVFLQ0FnRUE0SVJXYUZRamRrTmx2TU84akJ3ZWpPNjJjQUxTeHJxNFUwTjFWcHYvbno0UW1MRFZwUU5nbFVPdwppOVpBTFpGYWdIaXlNcWw3N1N0YzROT1puZ0l4dGhBNS95dDhDc0xxbEJBcXIyRjlpK1c3MlRldE5YZVhZMmVxClY3K21uemdVa3MwamN2TWlWVHgwTWZFZXF6Q0YrU2tUS1Q4OUI1amJqZ1RrbWZSbkdJVUNPK0RmaTc0NlJrT2MKZzM0WVZBYWR2SUtVK2VlM3RhaHFCWG52bGlTU3Y4UXQxeGNJMWljcFB5a3NaMzA0N1dvTVNzU0dqQUNSQWlnWApDOFRQOGRITlRoZ3p5Wlk4YVREWHlCQldoSlhKbE1zaFZEc1NzOFUyTkVXb0VRNVR1RFE3Vit3RjVtMlgyVXdnCmdyT0tESXEyK3JId1lFbUZpVVl3ZnlrcExMdWtTQitEYnpiTXNXa21USHZ6MkRoSzRmNG9VZUdOS0oyVElYUDcKYisvRm5zZUh0R3FYaXRZSWZtQUoyTGp3VmpJQVA3dFhOaTNHUFBUbVFPTm1sczlJaUtlS2UxZkRTeWNSUDVUYwp1VkNJbXFqajVhOGpvZlVJZGZXc2N5cFE4TVFCZzY5U2xOL0w1dVdaTEx1VFJzb1c2RVhWWjUweE5maXMxRDZpCkxBN2VLMHZ2T09Mb3VEcVgzV1lFd0xTZU5JS0tUS3pHRmV2bXRmdmI4YTNiM0lxQkRvM1VweU5QcFFaMThSQTQKRWVUUWF2ckxsZk5oYnVpR1hMM0FDMEM5MjdWaFVSYXhyQms2TWV0ays5SzlEOXk1RVRZbFVPcmRNeUd4M09QdQpVZHQ1MWR3Z3NFWkYzUVdra01IL2VHMkZmRERWL0QyNStiQjlDN3UxZXJGVUpxMk1yVlVDZ2dFQkFQa3E5ejd4CkNCbVRCVFZ0VndiSDBCSTFJdHRXbkJ0NUVvemxQTmc0LzhRdkJDQmlSMnRVbTJoK0pNbHBJbCttLzZyWkxxc08KaGNxaFcyWHkzaUJzUTBQT1BJNW9SNzZkNFJ4NUg4V2hFRG5CelJQZlhrVFZ3b1NTU05FR0psbXVvczNWNWx0SApDVS9SNjZvM0I5V1JmQ1FhUHJMaWJYdnpzRktSbTRGb0xtdkE5U2d4bHJvaXhSdnJhUU5SWVFabXM0UVY4bTNIClBzMXJVR01vZXZyamd0NUNrdjZUZGtQVHFLWmp5QitGRXl6Qit1dWlCLzl1U2tta295cWRJeHFTYkIxRENxT2cKdjNGd25Hc2owRGdRNVBQbjBuMkYvRGdKM0NrYVdaSVJQQk52MTZ5ejJDVjhteGlEVUVMdHNyTHNvV2ZqYm5IQgpOTTB5M0lXSlZEY05qZDhDZ2dFQkFPZkRLMnFGeFFQdEwvQmdJc1M4OEVkU3N6MmlCUDFkZFdEeElSK1hUQU4rCkx4OWJ1SFFMdmRFQmljdWI3NlZTUnhoY0lHNHF5UktYSnhMWDZ6UGFqZk9xeGFnUnlDTUxPMGs1ZE9MVmFtVlIKM3dpUmhxWmJIN2tZYWE4ckhGbE11bEZNUmhmZDJZMStqNTltempXOUFYc2RCYTlwa05Va0dVK0IwYU5Ca3hoVgpwUE5JZGFTanMyeXhJQlJpc3FxMUdoR1Mwb3pKTlNFb295bTNCT05zbjYyTVNFSmx1YVJrdDZSQzVtRjJiZG8rClVmdmF1VTFXMDdGLyt3VjIzN0w4d0dJVTUvOStwSjA1cGtqU3hKLy9LMDUzZHpvQ0Yva0kxd2tOZ1IwenhIb1cKS3VPek54WCs4T1pDL0ZwUlM3c3Q0bGF4azUvZnl6VEx5aEJ4bFJyeWg4OENnZ0VBU3Q4alRuR0ZHcEk0RlhiVwptTDRBQXdpZWdjUkR3bW1lTG1KUDV6VXhmZFVXNjFnODE3Nmp1RUYzY21JNkp2MzZnMjhoZTlzd1R0UXZyN0hNCkYzZ1F1bFpGa2hFNXhjaVJOVW9jUnZsLzg2c05vYlFVRXFFZEExTWx1Rkdkd29NY2ZyZVFzY3Jsdkd0NjRqb0oKQzU3YzY4aExJTnV6UkhUVWZlc3RERFN2QmtnRUl1REx4d0RkcytjSU5pd0UrTFJ4cXZZaFUrVjBOS3ZUaXdoRgo5QS9iYWtnYy9ZeDRGQ2VNM1ByTXp0UGhFQ2oxNmtwVkZ1Y2dRWUxNV09qQS9LSVZCTEg1aDNPdE16eEFkRjFkCm13dFFrUTRQRFJMdTJEUDJTUStXN0xKckYvZ2FtZFdzMUk3ZDEvN1ZabGNneEcwZ2p5UWpNdUY0cVZSb09XUXIKdnlNK2h3S0NBUUIvNXkzbXM3eHUxazlHa1VlZTI4YWZGZnpsWHF6eVJzbW9ubXB4VE1ZZWgxenFLV3c2WHVCNgpvQ2F6djNNYUFiWktzMDBTZjNwSVVESzRLNEVhTk50eVJpU2ZCSEUzSmRPcUxaTmNPL3RqdnpNZlAzRFlEaUlMCnZIVld2cXYrZkdHMnpDbENzcVNGZWZzNU5UdElYTzZjU3dBQU5uby9wcFJ4Vkd1bGRXTUFZd09OWDhmTS9LcmcKcVQvVEFFVXFBSmhLYW9UWVBaS2NvaGlweE45bHcyUzhHbGNtalkxT05HZEV0OGI4c3FjZGNwYzhMeEZrcFM1ZgpId29oa2VFU25ucHRwcXdDVEpuOFN2eUI1QSt2WE50QmlweTUzcjNzS2Z6Q2VqbHZMRXFhTmZHbGlCbzJnV1BoCkw4YWs4WWloM0VpMUgzc2hHQmpGSWxKNWtMV0JFYWZ4QW9JQkFRQ3ZmT1JFQW9Fb3ZzMmt5ZGNrNmwxa2tSM2EKZGpEeXR5MGJBM1RoTHdpWnZqWW9tQ1Y4NzdMdlVBZTJ4WWI0QVkwSk0zQkxUUWFGdEVMYTBueGF2MFI5ZzZsMApNdEg2UkJidE9wTzg1ZXk3ZTN1QnA3b01VYndYejhKcFBnd25HSE9GNUNkQ0RQU01HM3NRZVZxWFk4RTZNczZICjhoNGNjYnlVL1d4OTVDM0tEUDMvWjc3R1cwRmUra0NGNEhhSUVxOWE5ZUNhSzc1ajZFQTlFYTNKWkdXTHlvRXIKS1lpM2tVYTlTY0RDalN1N3dmRHlwVlB1aFhiamNad0RMVXEvK3EyL0ovWllqSEwyY2tCOUZpd0NxN3BFVmJ6YwpkR3ZhL251LzdTK25LSllhVXZjbXg4WmJpbS9vR3d0SFRFNkJXWjYrSmRlVElOVnFCT2hqczdnZld2d1gKLS0tLS1FTkQgUlNBIFBSSVZBVEUgS0VZLS0tLS0=',
            '/opt/confd/confdInstallDir/var/confd/webui/cert/host.key': 'LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQpNSUlKS0FJQkFBS0NBZ0VBM1B1WlFxZ2diZDhqZm4zOUZFRWw4SHR1V2tLNEZHWElrU2tmMjF4bDh2amNoNFo3Cm9ZVTNsZmp4MXVuVG9NRnVNQjIwUzR5UUZzUEtWdnljd05Lek9UZmtodVU0cTg3ZThUSTQxeCtoTldIdmZGRW4KSUJtUXN3dUdnZWlFWUxkMG1Xc1Y2Wmw4cndaRkJGRWRyV3VnZzdxZDV5ajJqM2ExSm9vb2poSGpwUXFTWUtMZApSNWhtbTczdjZiYkRTYmhrMWZKUzVkOEFGTHJac1JUMjFKU0ttNVJXUDQyWHEraVpYU2VjZ1pWOENnbnIxS1IzClBqOEtyd0lZRk1WcngveDQ3NW1kdGw0RkNUOHVnTDdiQUViamw4QnhKVzMzVUFGMjM3YjNUdjRnb2tWUS9sblUKckJCbWc5blhKSkNta2RGUjFsUmw3VVJnMndOOHNXSnlEdTJreFZseXZqQm1JTG50SzF6blRGMWlkN1FmMWRsWQphTk5ic3RmZDdpQU9GZE02TjBocCtjWkNEZmJwazBSbGl5d1hmT3Y5TmY4ZEh5bHNaSmE0RlRUZjVvZktsOWVxCmJzMmMzVUJTdXczeDNVMktiNVBJZXpiVmFCNWVYU2Y2Njd5ZVlWRzFieWJNMnlkSGFqWFhPd09EcXZvdzl5KzEKaktvbXl4M2psZks5VnpiWHlBd1cweGQycHVCSVNvYXUzS25POFpJbkJXOEdPY3BDOHRndmVMT2ZvTEFIZ0VDRAoyZG82c2ViUUxORkpNWGY1aGhBMkJqTFkyR2g5SlAvS1AvaEFEMG1TMnlxYlg5S3pnaVNNdTRsMU9qQS9PWlNsCkhkc3NkdS9SeTFNK0xXSUNycVRYTXlHbDF1ZFVYa2hISkZ6VHZxYXoyOEkwM0w5OVMvZWM5UjNySVZrQ0F3RUEKQVFLQ0FnQndYSEc2SmRpUFpUVWIvUjJ3cmN1SHNvc1MwL2ZiVDBHakphRHdIZFFzcmdNYjJmS0UxMExETzloago2WExVdTJXMmkzUUFNaEdWc2FueGZ2S0pUTmthVCtRZi91OUkxS0FoVGVMKzV6TkYvRzBUN2dPUjI4M3FiQUxSCmpSTzZSYTNBMEdWTTZPRXY4V1VvWThKT1NucE1ZSmduVUhuRnlwc2paSDVvZG9va2dmS1p0bFlETUdlRDZ4alEKNGovNy9Ra3dpODFBMnBtazhMajl4R1laQXdwVFB5SjNvQnd0cWRCSlFIbmduY3g3SWo1S1dmSFRzYVJTQmlPTwpkQzl3ZVZ4WW4raEVNUndvYm5yTHRiK1BMWHhOemVqNkdpYjFCRG1ZV09UNHdsaC9pZlU3enh0Ry9mUFNPUEtlCndmb2dES21xN0RFRGFwQkE3RTM3dDgyODczS21mMjZScU1xeWl2aVU4SHl1N2k3ZW5YSW5zelZ1M1A4SlpmM2UKTHl3bjA0VzE3Y3VuUVhXd2tpemE0Q1BGTnU3WW8wRXZUZ1k2RjNjWGdlN00zc1lWWHJMckQxWHRuR3R4ek1xTQpWTTJqSSt0VUZLK3V5THJkcW1scXpGOTd5eDFOVTB1Z3NOdEwyTFdOc0QyUm1qZ1JyNHFDRkRNc2toUlliVnUzCmJuZ00zNjJDOGtrUkpCM25KUFpYSUxXeUVFZy9oWDlIbDRtY01DZ29IZmZDdWxIQXdtZkRIZ1ZpUnpjaEZUR3oKd1MwRFJ6cUtZQXpaem1wMUNpOVl3dnJmOEs1eWNWQzFWY0NUN1hrVHBhbE0vSFpNRXI4cUtZa2kreEVSajdxSAovQ1ljR01KMy91WDFrcm81MEtUc3NQVGFTQTNJMFNnUERwMVpVMzFOZmZWbTdGek9qUUtDQVFFQS8yUnVlZkNjCnU4dG45R0k3VlJhT3A2b1hLaUN1TGY4aWQ2SUZIRTVURWxhNXRpREZwdnV1TkxqU3NWM2JOWEVrS1hRTGE3RmgKaERRUE45Z0NTVURNYmM5UkExTmFvdldYeHB4YWF5QnVxRkx1cjg2VTZrZGxaVHNKMEs5UXZrMUxFZWR3eGZxagpFQzJodHNWUFBVdXlwZkpWbkx4NnFnRXEwVjJEbCtJM3E3Z3p1TlN3MENSbkdNL2lMdk5xREFjK2ZSMHFDd3dmCndwRmVqak5XNnNUSS9mSHdrclloVjMyM1VxTGIzSWNzUTVXdjFHRS9tVzRYVGFiTktkdzYxeEFzSU5xR0lPQVQKRWpJUVU0dERXQ0ZuQXJsUTR2Tm9DSkFaZnpMbm1GMUo2ZjVha1VlVnliTC9rM1BvMk9VVmdybEdYY1dDVnVJQgpwZFZPamtST0NpMXJ1d0tDQVFFQTNZSTFBNEMrb29hMTR3SzFhOGp2V24zZE1Eb1dSekVVSXQ5dm9BR1BjL2Z3CkF4RUhsaWNKa2lvako1b3lBV09veFdrT3JmV2JvVkxjWjFUTE9WZ3hSZklUTmFjcEMyNkpDa2pUWm9FRGN1YTcKSFgwQTVtT3hheDEyVi9JNE8xaElMQ1ZUdThIek9hOElqN05NWGRORkpmRUM0NXJ5a2V1NlZFQkhaSVJGY1ZhYwpkbUhRRVdubXMvZis4cDQ1eGtsdzdHaHRLa1hsN2hBR082NWxjMHpYUDdSMXFRMVNKV0x1YkR6cloxTzRqRWtXCi85UjhKYlAweTIzZzVQOXAzMEwyTkp4NGl0Mk8yYzIrdmZ3TVp5dkxxL3NlcUUvTFdPQWFlV0t6UjVpT21rREEKa21XLzdLS01ZeE1WUXFFRlgyUm45ZFRwU2luVElJelhLcWEwNEdEeit3S0NBUUVBZ3N2UXVLcTkybi9GOGFjTgpjL3BsZlFEamREUGdnTFlWMU9jcGJ1RytNYm93eWxIbWFDcWxnV0xXcFBmSWVJcEZWdVdUbzhmb2hXaVVFcW1TCklpb0ppSU9RbmY5bWYrYi9vRHdiSXBvdGtnOUhKc3JLQVdJblQ3ejR2ZVBMbW1yRGM1dndhYlIvSnAzNElEN1UKNGpPT2Z1YXBhZWd0ZWp1MnpocnlkaXJwRUF6NmtFSjllMXZwWVErMmF3MUcxbm92U3F4UkIrOWhwS2dHb1JVeQpBbkpkN1pDbkFMdytQeXluWXE3OW91ZW5oOFYxazNOcXV3MWk2ZVh2Vk96eFJZdUd6aHljYk9IVllwQTVSRkFpCllWUmFDVThYV2VRRzk3dTFFeXZpNkdsK25WUWkxaHl2WGVsS2N4Mzl0bmM4bVFLQ1F5d1FJS2NHNlFOaGhBTC8KWkw3MldRS0NBUUFiU1RQUWw2WmtET1lRN2I5OVpJWWZob3VkcWpvZVVPeGpFMVVEeDgxdEFxaTlKL2JnUnpURgpuWTB4RHF5RVFVdUQ3ZG9TRWNRM0RpYjZUNWF0SExFTkpiRzZGVHBZSHlpZ2JMSWwyVlNjYmRHMDR6WWVLeitxCnF6bHR3ZmV0VDhXc01uanJFd3dzR2VTYkZ3SWNPSzgyNmtacDFTZDJWQ3hpdm54TTVJSk5ZTmJyT2tkUUxkUnUKYk9rcDU5WEVHRDNoMFVkSlFzejlFMXBCTmMxbmM1cThUVFdGT28vWTdTUGpqMm1NRStNUzNOb0piNXBQWnFpTAorcUFPZFd3TVJZcGdscm0rbVdaRWJEVEg0R21DdUFGaDBSQkl1WE9hSWhrQXhPakN0QWMwOXk4Qm1ha1h0RHBJCjVndmpaa1JzS01rcG5pMlNwaTVNdnl5dUkxVDZvdGJMQW9JQkFBUXV0d3lZczg0aHpTMTlicllxR2oxT20zUUEKWVMwbXlBaWdMYzZJWHBEYWJGNzNBWHgyc2lEZzdpeDVpNXlNVXdpeFg1czRXanJ4QWx2a29HNGRBekY5dzhWegpabWxic2g4bmNUUGJONUZvbnlVS2E1VnhzU1pmcHpKYW42ZTVnZGs4S0M2ZVdWMGpIRVMxOVVNY25BWVBIYXp0CkRqbFBITW5uWGtYWnNUZHlvek5yajM4ZVJWTHdwYjB3SXUxS3l3c0M5dEJhSnM2NElJSW1OR0VnckEyVWZ2OFcKd2ZXaXM1dTVvT3NldnFGVUJRb29aT2hlVHJ0OUJrZ3NrZVVRaFppYnhKR25OOVd3WmxoZEpQUmJRSHpmQnFJcgpCUDg3TDJTNGg5dUtBL1BlQzdZcDExSUFicHUwNjJ1TmZ1a1lTYlBLcVVHU3lTN1llVENqOFlJSFVsWT0KLS0tLS1FTkQgUlNBIFBSSVZBVEUgS0VZLS0tLS0='
        }
        for file, bcode in bcodes.items():
            if not os.path.exists(file):
                key = base64.b64decode(bcode)
                if key:
                    open(file, "wb").write(key + b'\n')

    def get_pod_intf_info(self):

        def _mask_to_prefix(mask):
            return sum(bin(int(x)).count('1') for x in mask.split('.'))

        def _v6_mask_to_prefix(mask):
            bitCount = [0, 0x8000, 0xc000, 0xe000, 0xf000, 0xf800, 0xfc00, 0xfe00, 0xff00, 0xff80, 0xffc0, 0xffe0, 0xfff0, 0xfff8, 0xfffc, 0xfffe, 0xffff]
            count = 0
            try:
                for w in mask.split(':'):
                    if not w or int(w, 16) == 0:
                        break
                    count += bitCount.index(int(w, 16))
            except Exception:
                raise SyntaxError('Bad NetMask')
            return count

        try:
            # routingGateway = netifaces.gateways()['default'][netifaces.AF_INET][0].encode('raw_unicode_escape')
            # routingNicName = netifaces.gateways()['default'][netifaces.AF_INET][1].encode('raw_unicode_escape')
            routingGateway = unicodeStr(netifaces.gateways()['default'][netifaces.AF_INET][0])
            routingNicName = unicodeStr(netifaces.gateways()['default'][netifaces.AF_INET][1])
        except Exception:
            routingNicName = None
            routingGateway = None

        try:
            # v6routingGateway = netifaces.gateways()['default'][netifaces.AF_INET6][0].encode('raw_unicode_escape')
            # v6routingNicName = netifaces.gateways()['default'][netifaces.AF_INET6][1].encode('raw_unicode_escape')
            v6routingGateway = unicodeStr(netifaces.gateways()['default'][netifaces.AF_INET6][0])
            v6routingNicName = unicodeStr(netifaces.gateways()['default'][netifaces.AF_INET6][1])
        except Exception:
            v6routingNicName = None
            v6routingGateway = None

        os.system("echo '' > /tmp/_pip.info")
        for interface in netifaces.interfaces():
            v4_ip = ''
            v4_mask = ''
            v4_gw = ''
            v6_ip = ''
            v6_mask = ''
            v6_gw = ''
            # in some python2 the values returned in unicode, like u'10.0.3.15'
            # so the .encode('raw_unicode_escape') is needed, below is example
            # python3 don't have this problem
            # routingNicMacAddr = netifaces.ifaddresses(interface)[netifaces.AF_LINK][0]['addr'].encode('raw_unicode_escape')
            # try:
            #     routingIPAddr = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr'].encode('raw_unicode_escape')
            #     routingIPNetmask = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['netmask'].encode('raw_unicode_escape')
            # except KeyError:
            #     pass
            if 'eth' not in interface:
                continue

            intf_data = netifaces.ifaddresses(interface)
            for family in intf_data:
                addr_str = ''
                if family not in (netifaces.AF_INET, netifaces.AF_INET6):
                    continue
                for address in intf_data[family]:
                    addr = address['addr']
                    mask = address['netmask']
                    # IPv4
                    if family == netifaces.AF_INET:
                        ipv4Addr = ip_util.IPv4Address(unicodeStr(addr))
                        if ipv4Addr.is_link_local or ipv4Addr.is_loopback:
                            continue
                        addr_str = addr
                        v4_ip = addr
                        v4_mask = _mask_to_prefix(mask)
                        self.pod_intf_data.setdefault(interface, {'ip': addr, 'mask': v4_mask, 'gateway': None})
                        # the calico set the default gateway to '169.254.1.1' and mask 32
                        # this is not accept by the traffic_info, so we ignore this gateway
                        if routingNicName is not None and interface == routingNicName:
                            # if routingGateway == '169.254.1.1' or mask == '255.255.255.255':
                            #     routingGateway = addr
                            # self.pod_intf_data[interface]['gateway'] = routingGateway
                            if (not routingGateway.startswith('169.')) and mask != '255.255.255.255':
                                self.pod_intf_data[interface]['gateway'] = routingGateway
                                v4_gw = routingGateway

                    # IPv6
                    if family == netifaces.AF_INET6:
                        # we don't have dual stack case, so once get the IPv6 address, override IPv4 if needed
                        # we might have several IPv6 addresses, it should be taken care in future
                        # remove the %ether_interface at the end, usually LLA has such tail
                        addr = addr.split('%')[0]
                        ipv6Addr = ip_util.IPv6Address(unicodeStr(addr))
                        if ipv6Addr.is_link_local or ipv6Addr.is_loopback:
                            continue
                        addr_str = addr
                        v6_ip = addr
                        v6_mask = _v6_mask_to_prefix(mask)
                        self.pod_intf_data.setdefault(interface, {'ipv6': '%s/%s' % (addr, v6_mask), 'gatewayv6': None})
                        # the calico set the default gateway to 'fe80::ecee:eeff:feee:eeee' and mask 128
                        # this is not accept by the traffic_info, so we ignore this gateway
                        if v6routingNicName is not None and interface == v6routingNicName:
                            # if v6routingGateway == 'fe80::ecee:eeff:feee:eeee' or _v6_mask_to_prefix(mask) == 128:
                            #     v6routingGateway = addr
                            # self.pod_intf_data[interface]['gatewayv6'] = v6routingGateway
                            if (not v6routingGateway.startswith('fe80::')) and _v6_mask_to_prefix(mask) != 128:
                                self.pod_intf_data[interface]['gatewayv6'] = v6routingGateway
                                v6_gw = routingGateway

                # send GARP or NA
                if addr_str:
                    cmd = 'python {}/sync_intface_update.py {} {} {}'.format(os.path.dirname(__file__), interface, addr_str, intf_data[netifaces.AF_LINK][0]['addr'])
                    os.system("echo '{}={}' >> /tmp/_pip.info".format(interface, addr_str))
                    logging.info(cmd)
                    commands.getstatusoutput(cmd)

            status, mtu = commands.getstatusoutput("ip link show | grep mtu | grep " + interface + " | awk '{print $5}' | head -n 1")
            if status != 0:
                mtu = 1500
            self.vcloud_info[interface] = {"V4": ['', v4_ip, v4_mask, v4_gw], "V6": ['', v6_ip, v6_mask, v6_gw], "MTU": mtu, "MAC": intf_data[netifaces.AF_LINK]}
        logging.info("\n====== container intf info: =========\n\n {data}\n".format(data=pprint.pformat(self.pod_intf_data)))

    def update_pod_configmap(self, cmPath, udPath):
        with open(cmPath, "r") as f:
            x = yaml.load(f, Loader=yaml.FullLoader)
        intf_dict = dict()
        if custom_userdata is not configmap_file:
            with open(custom_userdata, 'r') as f:
                y = yaml.load(f, Loader=yaml.FullLoader)
                self._mergeUserData(x, y)
        for data in x['network']:
            intf = x['network'][data]['IFNAME']
            if intf in self.pod_intf_data and intf not in intf_dict:

                if 'ip' in self.pod_intf_data[intf]:
                    x['network'][data]['IPADDR'] = self.pod_intf_data[intf]['ip']
                    if 'mask' in self.pod_intf_data[intf] and 'PREFIX' not in x['network'][data]:
                        x['network'][data]['PREFIX'] = self.pod_intf_data[intf]['mask']
                else:
                    if 'IPADDR' in x['network'][data]:
                        del x['network'][data]['IPADDR']

                if 'ipv6' in self.pod_intf_data[intf]:
                    x['network'][data]['IPV6ADDR'] = self.pod_intf_data[intf]['ipv6']
                else:
                    if 'IPV6ADDR' in x['network'][data]:
                        del x['network'][data]['IPV6ADDR']

                # do not erase gateway in user-data, it might be useful
                if 'gateway' in self.pod_intf_data[intf] and self.pod_intf_data[intf]['gateway'] is not None:
                    if not x['network'][data].get('GATEWAY', None):
                        x['network'][data]['GATEWAY'] = self.pod_intf_data[intf]['gateway']

                if 'gatewayv6' in self.pod_intf_data[intf] and self.pod_intf_data[intf]['gatewayv6'] is not None:
                    if not x['network'][data].get('IPV6_DEFAULTGW'):
                        x['network'][data]['IPV6_DEFAULTGW'] = self.pod_intf_data[intf]['gatewayv6']
                intf_dict[intf] = True
        if os.path.exists(extra_user_data_dir):
            mapfiles = os.listdir(extra_user_data_dir)
            for file in mapfiles:
                if file.startswith('.'): continue
                logging.info("merge extra data: {}".format(file))
                with open(os.path.join(extra_user_data_dir, file), 'r') as f:
                    y = yaml.load(f, Loader=yaml.FullLoader)
                    self._mergeUserData(x, {file: y})    
        with open(udPath, "w") as f:
            yaml.dump(x, f, default_flow_style=False)

    def doConfig(self, platform):
        if platform == 'container':
            self.isContainer = True
        else:
            self.isContainer = False
            self.handleErr("we are not in container, abort")

        logging.info("Start container cfginit")
        self.isAWSContainer()
        self.get_pod_intf_info()
        # exit(0) #for debug
        self.update_pod_configmap(configmap_file, user_data_file)
        self._do(platform)
        logging.info("\n====== vcloud_info: =========\n\n {data}\n".format(data=pprint.pformat(self.vcloud_info)))
        logging.info("\n====== traffic_info: ========\n\n {data}\n".format(data=pprint.pformat(self.traffic_info)))
        logging.info("\n========== vdu: =============\n\n {data}\n".format(data=pprint.pformat(self.vdu)))
        logging.info("\n====== doorbell_info: ======= \n\n {data}\n".format(data=pprint.pformat(self.doorbell_info)))
        logging.info("Will fill data to 'intf_data'")
        self.fill_intf_data()
        logging.info("\n======== intf_data: ========= \n\n {data}\n".format(data=pprint.pformat(self.intf_data)))
        # exit(0) # for test
        self._do_for_vdu()
        # logging.info("Will generate ifcfg files")
        # removed since we dont need this in container
        # self.generate_ifcfg(conf_dir)
        out = commands.getoutput("cat {dir}/*-platform.yang|grep belongs-to".format(dir=yang_files_dir)).split()
        namespace = ''
        if len(out) >= 2:
            file_name_prefix = out[1]
            namespace = self.get_namespace("{dir}/{file}*.yang".format(dir=yang_files_dir, file=file_name_prefix))
            logging.info("Master Yang file prefix: %s, namespace: %s", file_name_prefix, namespace)
        if not namespace:
            self.handleErr("Can't get the valid namespace from yangFiles")

        self.merge_xml()
        logging.info("Will generate XML file")
        self.generate_network_xml(namespace, net_xml_file)
        self.set_https_netconf_weui(namespace)
        self.set_ssh()
        self._secret_confd()
        self._gen_confd_webui_key()

        if not self.isInContainer:
            # this should not hanppen, keep it in case we need them in future
            logging.info("Will set DNS")
            self.set_dns()
            self.set_ssh()
            self.set_ldap()
            self.set_sssd()

        if self.vdu.get('PROGRAM_SECURITY', False):
            if self.vdu.get('PM_SECURITY', True):
                # update blade.cfg
                logging.info("Will update blade.cfg")
                contents = open('/usr/IMS/exports/blade.cfg').readlines()
                hasSet = False
                for idx, line in enumerate(contents):
                    if re.search(r'^\s*RUN_APP_NORMAL_USER\s*=', line):
                        contents[idx] = 'RUN_APP_NORMAL_USER=yes\n'
                        hasSet = True
                if not hasSet:
                    contents.append('RUN_APP_NORMAL_USER=yes')
                open('/usr/IMS/exports/blade.cfg', 'w').write(''.join(contents))

            # update sudoers
            logging.info("Will update sudo policies")
            folder = os.path.dirname(__file__)
            contents = open(sudofile).readlines()
            sudoDone = False
            for idx, line in enumerate(contents):
                if re.search(r'^\s*admin\s+ALL=\(ALL\)\s+', line):
                    if folder not in line:
                        if line.replace('\n', '').endswith('ALL'):
                            contents[idx] = 'admin ALL=(ALL) NOPASSWD:/usr/IMS/current/bin/*,{1}/*\n'.format(line.rstrip('\n'), folder).replace('ALL,','')
                        else:
                            contents[idx] = '{0},{1}/*\n'.format(line.rstrip('\n'), folder)
                    sudoDone = True 
                    break
            if not sudoDone:
                contents.append('admin ALL=(ALL) NOPASSWD:/usr/IMS/current/bin/*,{0}/*\n'.format(folder))
            open(sudofile, 'w').write(''.join(contents))

            os.system("/usr/IMS/current/tools/update_sudo.sh")
            contents = open('/etc/init.d/IMS').readlines()
            for idx, line in enumerate(contents):
                if re.search(r'^\s*export\s+PATH=*/usr/IMS/current/bin:*/usr/IMS/current/tools:', line) or re.search(r'\"pm\".* setcap ', line):
                    contents[idx] = ''

            for idx, line in enumerate(contents):
                if re.search(r'^\s*source\s+/usr/IMS/exports/blade.cfg', line):
                    contents[idx] = line + 'export PATH=/usr/IMS/current/bin:/usr/IMS/current/tools:$PATH\n'
                elif re.search(r'su - admin -c \"\$cmd_line &\"', line):
                    new_line = '\t\t\t\t[ ${PROGS_TO_START[$prog_index]} == "pm" ] && { setcap "CAP_CHOWN,CAP_SETGID,CAP_SETUID,CAP_DAC_READ_SEARCH,CAP_DAC_OVERRIDE,CAP_KILL,CAP_NET_BIND_SERVICE,CAP_NET_RAW,CAP_NET_ADMIN,CAP_IPC_LOCK,CAP_IPC_OWNER,CAP_SYS_ADMIN,CAP_SYS_RESOURCE=eip" $cmd_line; }\n'
                    contents[idx] = new_line + line
            open('/etc/init.d/IMS', 'w').write(''.join(contents))

            # set shell for admin
            logging.info("Will reset non-root")
            os.system('usermod -s /bin/bash admin')

        # run commands
        try:
            fp = open(tmp_cmd_file)
            logging.info("runcmd: /tmp/tem_runcmd.sh")
            os.system(r"/bin/bash " + tmp_cmd_file)
            os.unlink(tmp_cmd_file)
            fp.close()
        except Exception:
            logging.info("no runcmd")
        logging.info("Done!")


# --- Main ----
if __name__ == '__main__':
    SECRET_FILE_DIR = { "netconf-ssh-keys": "/etc/secrets/netconf/ssh-keys", "sshd-ssh-keys": "/etc/secrets/sshd/ssh-keys" }
    namespace = None
    ssh_dir = r"/home/admin/.ssh/"
    ldap_conf_ldap = "/etc/openldap/ldap.conf"
    ldap_conf_nslcd = "/etc/nslcd.conf"
    platform = sys.argv[1]
    logging.info("current file: %s", __file__)
    script_dir = os.path.dirname(__file__)
    with open(sys.argv[0]) as fd:
        for line in fd:
            if "Version" in line:
                logging.info("%s", line)
                break

    out_xml = user_data_file = network_data_file = meta_data_file = dev_info_data = ''
    c_dev_info = None
    yang_files_dir = sys.argv[2]
    net_xml_file = "/opt/confd/confdInstallDir/var/confd/cdb/static_net.xml"
    conf_dir = r"/etc/sysconfig/network-scripts"
    # user_data_file = r"/mnt/config/openstack/latest/user_data"
    user_data_file = "/root/user_data"

    network_data_file = r"/mnt/config/openstack/latest/network_data.json"
    # network_data_file = r"/root/network_data.json"
    # meta_data_file = r"/mnt/config/openstack/latest/meta_data.json"

    configmap_file = r"/data/configmap/user-data"
    custom_userdata = r"/data/configmap/extra_user_data"
 
    extra_user_data_dir = r"/data/configmap/extra-configmap"
    tmp_cmd_file = r"/tmp/tem_runcmd.sh"

    obj = Cfginit()
    if os.path.exists(custom_userdata):
        if not os.path.exists(configmap_file):
            configmap_file = custom_userdata
    else:   
        obj.handleErr("no userdata can be used.") 
    if obj.debug:
        dev_info_data = ''
        if platform == 'vmware':
            out_xml, dev_info_data = sys.argv[2], sys.argv[3]
        else:
            user_data_file = network_data_file = meta_data_file = dev_info_data = sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
        if dev_info_data:
            with open(dev_info_data) as fd:
                c_dev_info = json.load(fd)
        yang_files_dir = "yang/"
        net_xml_file = "static_net.xml"
        conf_dir = "./"
        ssh_dir = "./"
        ldap_conf_ldap = "ldap.conf"
        ldap_conf_nslcd = "nslcd.conf"

    obj.doConfig(platform)
    exit(0)
