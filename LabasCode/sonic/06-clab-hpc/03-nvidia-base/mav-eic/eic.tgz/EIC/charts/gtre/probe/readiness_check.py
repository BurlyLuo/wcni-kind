#!/usr/bin/env python

# version: 0.3.15

import json
import os
import sys
import re
import logging
import logging.handlers
import pprint
import netifaces
import threading
import base64
import time


if sys.version.startswith("3."):
    import subprocess as commands
else:
    import commands

try:
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        filename="/data/storage/log/readyprobe_check.log",
        filemode="w",
    )
except Exception as e:
    pprint.pprint(e)
    exit(-1)

vnf_type = ""
is_active = False
logger = None


class ReadinessLog:
    @staticmethod
    def info(msg):
        logger.info("{}".format(msg))
    @staticmethod
    def warn(msg):
        logger.warn("{}".format(msg))
    @staticmethod
    def error(msg):
        logger.error("{}".format(msg))


def setup_logger():
    """
    Set up the logger, set the log level to DEBUG, and add a rotating file handler to the logger.
    The log file is rotated every 10M and only keep 2 log files at most.
    :return: None
    """
    logger = logging.getLogger("ReadinessLog")
    logger.setLevel(logging.DEBUG)
    handle = logging.handlers.RotatingFileHandler(
        filename="/data/storage/log/readyprobe_check.log",
        maxBytes=1024 * 1024 * 10,
        backupCount=1
    )
    formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', datefmt="%Y-%m-%d %H:%M:%S")
    handle.setFormatter(formatter)
    logger.addHandler(handle)
    return logger


def _run_cli_cmd(cmd):
    ReadinessLog.info("  run confd cli cmd: {}".format(cmd))
    stat, out = commands.getstatusoutput("echo -e '{}' | cli".format(cmd))
    if stat:
        ReadinessLog.error(" run the cli command failed.")
        return []
    lines = out.split("\n")
    start = end = 0
    for i, line in enumerate(lines):
        if "---" in line:
            start = i + 1
        elif "match" in line:
            start = i + 1
        if "[ok]" in line:
            end = i

    ReadinessLog.info("  output: {}".format(pprint.pformat(lines[start:end], indent=2)))
    return lines[start:end]

def check_ims_status():
    """
    Check IMS status
    :return: None
    """
    global vnf_type
    global is_active
    vnf_type = _run_cli_cmd("show table sys platform product")[0].split()[1]
    ReadinessLog.info("check IMS status: (vnf type: {})".format(vnf_type))
    stat, out = commands.getstatusoutput(
        '/usr/IMS/current/bin/readShm | grep "vnfcHAMode" | grep STANDBY'
    )
    if stat == 0:
        ReadinessLog.info("  output: {}".format(out))
        return

    if vnf_type == "SM":
        stat, out = commands.getstatusoutput(
            '/usr/IMS/current/bin/readShm | grep vnfcState |grep -E "InitSuccess|Configured"'
        )
        ReadinessLog.info("  output: {}".format(out))
        if stat != 0:
            exit(1)
    else:
        stat, out = commands.getstatusoutput(
            '/usr/IMS/current/bin/readShm | grep -E "Process State|LCM Event"|grep -E "STATE_INS_ACTIVE|Stopping|Deactivating|Stop Success"'
        )
        ReadinessLog.info("  output: {}".format(out))
        if stat != 0:
            exit(1)
    is_active = True


def check_corefiles():
    """
    Checking core file generation
    If a corefile is generated after cfginit starts, the check will fail
    :return: None
    """
    ReadinessLog.info("check Core files")
    x_mtime = os.stat("/var/log/cfginit.log").st_mtime
    files = os.listdir("/data/storage/corefiles/")
    for file in files:
        file = os.path.join("/data/storage/corefiles/", file)
        if os.stat(file).st_mtime > x_mtime:
            ReadinessLog.error(" find a core file: {}".format(file))
            exit(1)


def check_ips_and_routes():
    """
    Verify configured external IP addresses are assigned and routes configured
    :return: None
    """
    ReadinessLog.info("check ips and routes")
    ext_ip_info = {}
    ext_rule_info = {}
    ext_route_info = {}
    for line in _run_cli_cmd("set screen length 2000\nshow table sys platform ext_ip"):
        items = line.split()
        traffic, ipaddr, mask, intf, ip_type = (
            items[0],
            items[1],
            items[2],
            items[3],
            items[4],
        )
        if "EXT_IP_VIRTUAL" == ip_type or "EXT_IP_PHYSICAL" == ip_type:
            stat, _ = commands.getstatusoutput(
                'ip a s {} | grep -q "{}/{}"'.format(intf, ipaddr, mask)
            )
            if stat:
                ReadinessLog.error(
                    " the ip '{}/{}' is not added on '{}'".format(ipaddr, mask, intf)
                )
                exit(2)
        ext_ip_info[traffic] = (ipaddr, mask, intf)
    for line in _run_cli_cmd("show table sys platform ext_dynamic_route"):
        items = line.split()
        dest, mask, gateway, intf, rule_name = (
            items[1],
            items[2],
            items[3],
            items[4],
            items[5],
        )
        ext_route_info[rule_name] = (dest, mask, gateway, intf)
    for line in _run_cli_cmd("show table sys platform ext_rule"):
        items = line.split()
        rule_name, traffic, rule_id = items[0], items[1], items[4]
        ext_rule_info[rule_name] = (rule_id, traffic)
    ReadinessLog.info("  ext_ip: {}".format(ext_ip_info))
    ReadinessLog.info("  ext_rule: {}".format(ext_rule_info))
    ReadinessLog.info("  ext_route: {}".format(ext_route_info))
    for rule_name, (dest, mask, gateway, dev) in ext_route_info.items():
        if dev == "eth0":
            continue
        ReadinessLog.info("  rule name: {}".format(rule_name))
        rule_id, traffic = ext_rule_info[rule_name]
        ReadinessLog.info("  rule id: {}".format(rule_id))
        src, _, intf = ext_ip_info[traffic]
        current_route = commands.getoutput("ip r s table {}".format(rule_id))
        if ":" in src:
            current_route = commands.getoutput("ip -6 r s table {}".format(rule_id))
        ReadinessLog.info("  route: {}".format(current_route))
        if mask == "0" and (dest == "0.0.0.0" or dest == "::0"):
            if not re.match("default .*dev {} ".format(dev), current_route):
                ReadinessLog.error(
                    " cannot find the default route on table '{}'".format(rule_id)
                )
                exit(2)
        else:
            if not re.match("{}/{} .*dev {} ".format(dest, mask, dev), current_route):
                ReadinessLog.error(
                    " cannot find the route {}/{} device {} on table '{}'".format(
                        dest, mask, dev, rule_id
                    )
                )
                exit(2)


def send_grap():
    data = []
    filename = (
        "/data/_pip.info" if os.path.exists("/data/_pip.info") else "/tmp/_pip.info"
    )
    with open(filename) as fd:
        data = list(map(lambda x: x.replace("\n", "").split("="), fd.readlines()))

    def send(intf, ipaddr):
        mac = netifaces.ifaddresses(intf)[netifaces.AF_LINK][0]["addr"]
        cmd = "python /usr/IMS/current/tools/sync_intface_update.py {} {} {}".format(
            intf, ipaddr, mac
        )
        import getpass

        if getpass.getuser() == "admin":
            cmd = "sudo " + cmd
        ReadinessLog.info(cmd)
        commands.getoutput(cmd)

    for item in data:
        if len(item) == 2:
            t = threading.Thread(target=send, args=(item[0], item[1]))
            t.start()


def _format_etcd_data(json_data):
    """
    Decode etcd data in JSON format
    """
    ReadinessLog.info("  decoding etcd data")
    kvs_list = json.loads(json_data).get("kvs")

    def _etcd_map(x):
        key = str(base64.b64decode(x.get("key")).decode("utf8"))
        value_str = str(base64.b64decode(x.get("value")).decode("utf8"))
        if value_str.startswith("{"):
            index = value_str.rindex("}") + 1
            return {key: value_str[:index]}
        else:
            return {key: value_str}

    data = list(map(_etcd_map, kvs_list))
    return data


def _format_confd_data(data, fields, key_idx, subkey):
    """
    Parses confd data into a dict object.
    """
    res = {}
    for line in data:
        contentList = line.split()
        key = contentList[key_idx]
        value = dict(
            filter(
                lambda x: x[0] is not None,
                zip(
                    map(lambda x: x[0], fields),
                    map(lambda x: contentList[x[1]], fields),
                ),
            )
        )
        if key in res:
            res[key][str(value[subkey])] = value
        else:
            res[key] = {str(value[subkey]): value}

    return res


def _get_info_from_etcd(start, end):
    """
    Get data from the etcd server
    """
    ReadinessLog.info("  fetching etcd data")
    data = '{{"key": "{}", "range_end": "{}"}}'.format(
        base64.b64encode(start.encode("utf-8")).decode("utf-8"),
        base64.b64encode(end.encode("utf-8")).decode("utf-8"),
    )
    if sys.version.startswith("2.7"):
        import httplib

        conn = httplib.HTTPConnection(
            host="sm-service", port=2379, strict=False, timeout=30
        )
        conn.request(
            method="POST",
            url="/v3/kv/range",
            body=data,
            headers={"Content-Type": "application/json"},
        )
        return _format_etcd_data(conn.getresponse().read())
    else:
        import urllib.request

        req = urllib.request.Request(
            url="http://sm-service:2379/v3/kv/range",
            data=data.encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        return _format_etcd_data(urllib.request.urlopen(req).read().decode("utf8"))

    # for test
    # file = "data.json"
    # return _format_etcd_data(open(file).read())


def _comp_datas(src_data, dst_data):
    """
    Compare the data in the src_data and dst_data
    to determine that the data for the former is the same in the latter.
    """
    global vnf_type
    ReadinessLog.info("  start comparing the contents of the two datas")
    for k, dst_dic_value in dst_data.items():
        if k in src_data:
            src_dic_value = src_data[k]
            for idx, value in dst_dic_value.items():
                if idx in src_dic_value:
                    desc_keys = set(list(value.keys()))
                    src_keys = set(list(src_dic_value[idx].keys()))
                    keys = src_keys & desc_keys
                    for key in keys:
                        if str(value[key]) != str(src_dic_value[idx][key]):
                            ReadinessLog.error(
                                " src: src[{}][{}] = {}".format(idx, key, value[key])
                            )
                            ReadinessLog.error(
                                " dest: dest[{}][{}] = {}".format(
                                    idx, key, src_dic_value[idx][key]
                                )
                            )
                            exit(4)
                else:
                    ReadinessLog.error(
                        " can not found the data about {} -> {} in confd".format(k, idx)
                    )
                    exit(4)
        else:
            ReadinessLog.error(" can not found the data about {} in confd".format(k))
            exit(4)


def _compare_helper(
    etcd_data, cmd, etcd_key, fields, key_field, key_idx, subkey, skip_cond={}
):
    """
    A helper that provides more flexible options to determine the behavior of the comparison
    """
    cli_output = _run_cli_cmd(cmd)
    # for test
    # cli_output = open("confd_demo.txt").readlines()

    etcd_filter_list = list(
        map(
            lambda x: list(x.values())[0],
            filter(lambda y: list(y.keys())[0].startswith(etcd_key), etcd_data),
        )
    )
    etcd_peer_vnf = {}
    skip_keys = list(skip_cond.keys())
    for item in etcd_filter_list:
        if isinstance(item, str):
            index = item.rindex("}") + 1
            item = json.loads(item[:index])
        if [1 for skip in skip_keys if item.get(skip) == skip_cond[skip]]:
            continue
        if key_field not in item:
            ReadinessLog.warn(
                " can not found the key '{}'".format(key_field)
                + " in the data '{}' in etcd".format(item)
                + " -> skip this data"
            )
            continue
        key = str(item.get(key_field))
        if key in etcd_peer_vnf:
            etcd_peer_vnf[key][str(item[subkey])] = item
        else:
            etcd_peer_vnf[key] = {str(item[subkey]): item}
    confd_peer_vnf = _format_confd_data(cli_output, fields, key_idx, subkey)
    _comp_datas(etcd_peer_vnf, confd_peer_vnf)


def check_between_etcd_and_confd():
    """
    Audit local peer-vnf/peer-ip tables in confd vs. etcd entries in SM
    :return: None
    """
    global vnf_type
    if vnf_type == "SM":
        return
    ReadinessLog.info("audit local peer-vnf/peer-ip tables in confd vs. etcd entries in SM")
    etcd_data = _get_info_from_etcd("/a", "/z")
    leader_data = list(
        filter(lambda x: list(x.keys())[0] == "/cluster-mgmt/leader", etcd_data)
    )[0].get("/cluster-mgmt/leader")
    if isinstance(leader_data, str) and leader_data.startswith("{"):
        index = leader_data.rindex("}") + 1
        leader_data = json.loads(leader_data[:index])
    nf_id = leader_data.get("nf-id")
    ReadinessLog.info("  namespace: {}".format(nf_id))
    ReadinessLog.info("  check peer_vnf.")
    cmd = "set screen length 2000\nshow table sys platform peer_vnf"
    fields = [
        ("logical-component-id", 0),
        ("nf-id", 1),
        ("site-id", 2),
        ("service-type", 3),
        ("status", 4),
        ("health-status", 5),
        ("weight", -1),
    ]
    _compare_helper(
        etcd_data,
        cmd,
        "/sys-mgmt/components/{}/instance/".format(nf_id),
        fields,
        "logical-component-id",
        0,
        "logical-component-id",
        {"status": "VNF_STATUS_STANDBY"},
    )

    ReadinessLog.info("  check peer_ip.")
    cmd = "set screen length 2000\nshow table sys platform peer_ip"
    fields = [("id", 0), ("name", 1), ("ip", 2), ("logical-component-id", -1)]
    _compare_helper(
        etcd_data,
        cmd,
        "/sys-mgmt/components/{}/service-ip/".format(nf_id),
        fields,
        "ip",
        2,
        "logical-component-id",
    )


def check_emxrouter():
    """
    For each emxRouter peer ip, check if at least one TCP connection is established
    :return: None
    """
    ReadinessLog.info("verify emxRouter peer TCP connections stats")
    confd_cli_out = _run_cli_cmd(
        r"set screen length 2000\nshow table sys platform ext_ip | match emxrouter"
    )
    if not confd_cli_out:
        return
    confd_cli_out = _run_cli_cmd(
        r"set screen length 2000\nshow table sys platform peer_ip | match emxrouter"
    )
    netstat_out = commands.getoutput("sudo netstat -natpW").split("\n")

    filter_out = filter(
        lambda x: 9966 <= int(x.group(2)) <= 9997 if x else None,
        map(lambda x: re.match(r".*\s+.*:\d+\s+(.*):(\d+) ", x), netstat_out),
    )
    netstat_out_set = set(map(lambda x: x.group(1), filter_out))
    for line in confd_cli_out:
        ip = line.split()[2]
        if ip not in netstat_out_set:
            ReadinessLog.error(
                " there is not established peer tcp connection for ip '{}'".format(ip)
            )
            exit(5)


def check_replication():
    import glob

    rprobes = glob.glob("/usr/IMS/current/bin/rprobe_*")
    for rpobe in rprobes:
        ReadinessLog.info(" perform the rprobe '{}'".format(rpobe))
        stat, out = commands.getstatusoutput(rpobe)
        if stat != 0:
            ReadinessLog.error(" failed to perform the rprobe '{}': {}".format(rpobe, out))
            exit(6)


if __name__ == "__main__":
    logger = setup_logger()
    default_features = "ips_and_routes,etcd_and_confd,emxrouter,send_grap"
    check_list = "{}, {}".format(
        default_features, os.getenv("readiness_checklist") or ""
    ).split(",")
    check_list = list(map(lambda x: x.strip(), check_list))
    features = {
        e.replace("-", "").replace("+", ""): (False if e.startswith("-") else True)
        for e in check_list
    }
    try:
        if features.get("replication", False):
            check_replication()
        uptime = commands.getoutput("uptime -s")
        if os.path.exists("/tmp/_readiness_stat"):
            # if the content of /tmp/_readiness_stat is the same as uptime, the script will exit 0.
            if open("/tmp/_readiness_stat").read() == uptime:
                exit(0)
        check_ims_status()
        if is_active:
            if features.get("corefiles", False):
                check_corefiles()
            if features.get("ips_and_routes", False):
                if vnf_type != "SM":
                    check_ips_and_routes()
            if features.get("etcd_and_confd", False):
                check_between_etcd_and_confd()
            if features.get("emxrouter", False):
                check_emxrouter()
        if features.get("send_grap", False):
            send_grap()
        ready_delay_time = int(os.getenv("readinessDelay", 0))
        if ready_delay_time > 0:
            if not os.path.exists("/tmp/_readiness_delay"):
                open("/tmp/_readiness_delay", "w").write(str(time.time()))
            ready_time_str = open("/tmp/_readiness_delay").read()
            difftime = time.time() - float(ready_time_str) 
            if difftime < ready_delay_time:
                ReadinessLog.warn("ready delay: {}s".format(difftime))
                exit(200)
        ReadinessLog.info("Success!")
        open("/tmp/_readiness_stat", "w").write(uptime)
    except Exception as e:
        ReadinessLog.error(e)
        exit(-1)
    exit(0)
