#! /bin/bash
while :; do 
  if /bin/sh -c /usr/IMS/current/bin/readShm|grep "vnfcType"|grep -qi "SM"; then
    if /bin/sh -c /usr/IMS/current/bin/readShm|grep "vnfcState"|grep -qi "InitSuccess";then
        echo "IMS is InitSuccess" > /tmp/readShm-output.log
        break
    fi
  else
    if /bin/sh -c /usr/IMS/current/bin/readShm|grep "Process State"|grep -qi "STATE_INS_ACTIVE";then
        echo "IMS is InService" > /tmp/readShm-output.log
        break
    fi
  fi
done
